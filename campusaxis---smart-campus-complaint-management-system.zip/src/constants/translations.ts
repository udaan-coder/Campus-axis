export type Language = 'en' | 'hi';

export interface Translations {
  // Brand & Nav
  brandTitle: string;
  brandTagline: string;
  navOverview: string;
  navStudentPortal: string;
  navAdminHub: string;
  navAnalytics: string;
  navTrackIssue: string;
  navReportIssue: string;
  navReport: string;
  navNotifications: string;
  navClearAll: string;
  navNoNotifications: string;
  navSignIn: string;
  navStudentLogin: string;
  navAdminLogin: string;
  navLogout: string;
  navLoggedInAs: string;

  // Landing Page
  heroBadge: string;
  heroHeadingLine1: string;
  heroHeadingLine2: string;
  heroHeadingLine3: string;
  heroSubtitle: string;
  heroCtaReport: string;
  heroCtaExplore: string;
  heroCtaTrack: string;
  statsTotalComplaints: string;
  statsPendingComplaints: string;
  statsInProgress: string;
  statsResolvedComplaints: string;
  statsResolutionRate: string;
  statsAvgResolutionTime: string;

  // Features Section
  featuresHeading: string;
  featuresSubheading: string;
  feature1Title: string;
  feature1Desc: string;
  feature2Title: string;
  feature2Desc: string;
  feature3Title: string;
  feature3Desc: string;
  feature4Title: string;
  feature4Desc: string;

  // How it works
  howHeading: string;
  howSubheading: string;
  howStep1Title: string;
  howStep1Desc: string;
  howStep2Title: string;
  howStep2Desc: string;
  howStep3Title: string;
  howStep3Desc: string;
  howStep4Title: string;
  howStep4Desc: string;

  // Categories (all 15)
  catInternet: string;
  catClassroom: string;
  catHostel: string;
  catLab: string;
  catLibrary: string;
  catCanteen: string;
  catCleanliness: string;
  catWaterPower: string;
  catInfra: string;
  catAdmin: string;
  catSecurity: string;
  catSports: string;
  catTransport: string;
  catMedical: string;
  catOther: string;

  // Urgency & Priority
  urgencyCritical: string;
  urgencyHigh: string;
  urgencyMedium: string;
  urgencyLow: string;
  priorityScore: string;
  priorityLabel: string;
  priorityQueue: string;
  priorityEngine: string;
  reasonForPrioritization: string;

  // Statuses
  statusRaised: string;
  statusInProgress: string;
  statusResolved: string;

  // Student Portal
  studentDashboardTitle: string;
  studentDashboardSubtitle: string;
  tabOverview: string;
  tabSubmitComplaint: string;
  tabMyComplaints: string;
  tabTrackComplaint: string;
  tabNotifications: string;
  tabProfileSettings: string;
  studentSubmitTitle: string;
  studentSubmitSubtitle: string;
  fieldCategory: string;
  fieldSelectCategory: string;
  fieldCustomTitle: string;
  fieldComplaintTitle: string;
  fieldDescription: string;
  fieldLocation: string;
  fieldBlockRoom: string;
  fieldUrgency: string;
  fieldAffectedScale: string;
  fieldSafetyHazard: string;
  fieldSafetyHazardLabel: string;
  fieldAttachImage: string;
  fieldSubmitAnonymous: string;
  btnSubmitComplaint: string;
  btnSubmitting: string;
  livePriorityPreview: string;

  // Empty States
  emptyComplaintsTitle: string;
  emptyComplaintsDesc: string;
  emptyPriorityQueueTitle: string;
  emptyPriorityQueueDesc: string;
  emptyMyComplaintsTitle: string;
  emptyMyComplaintsDesc: string;
  emptyNotificationsTitle: string;
  emptyNotificationsDesc: string;

  // Admin Portal
  adminPortalTitle: string;
  adminPortalSubtitle: string;
  tabSmartQueue: string;
  tabAllComplaints: string;
  adminSearchPlaceholder: string;
  filterAll: string;
  filterCritical: string;
  filterHigh: string;
  filterMedium: string;
  filterLow: string;
  btnOverridePriority: string;
  btnUpdateStatus: string;
  btnAssignDept: string;
  btnManageAdmins: string;
  modalOverrideTitle: string;
  modalOverrideMandatoryReason: string;
  modalOverrideReasonPlaceholder: string;
  btnSaveOverride: string;

  // Auth (Student & Admin)
  authStudentTitle: string;
  authStudentSubtitle: string;
  authStudentLoginTab: string;
  authStudentRegisterTab: string;
  authAdminTitle: string;
  authAdminSubtitle: string;
  authFullName: string;
  authCollegeEmail: string;
  authStudentId: string;
  authDepartment: string;
  authYearSemester: string;
  authPassword: string;
  authConfirmPassword: string;
  authRememberMe: string;
  authForgotPassword: string;
  authDontHaveAccount: string;
  authAlreadyHaveAccount: string;
  authLoginBtn: string;
  authRegisterBtn: string;
  authAdminUsernameOrEmail: string;
  authAdminLoginBtn: string;
  authAdminNoPublicSignUpNote: string;
  authFirstTimeAdminSetup: string;
  authAuthorizationKey: string;
  authInitializeRootAdminBtn: string;
  authPasswordMismatch: string;
  authMustBeLoggedInStudent: string;
  authMustBeLoggedInAdmin: string;
  authLogoutSuccess: string;
  authLoginSuccess: string;
  authRegisterSuccess: string;

  // Common UI
  btnCancel: string;
  btnClose: string;
  btnSave: string;
  btnViewDetails: string;
  btnTrack: string;
  btnReset: string;
  loading: string;
  searchPlaceholder: string;
  footerRights: string;
  footerAddress: string;
  footerHelpline: string;
  languageName: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    // Brand & Nav
    brandTitle: 'CampusAxis',
    brandTagline: 'SATI Vidisha · Smart Complaint Hub',
    navOverview: 'Overview',
    navStudentPortal: 'Student Portal',
    navAdminHub: 'Admin Hub',
    navAnalytics: 'Analytics',
    navTrackIssue: 'Track Issue',
    navReportIssue: 'Report an Issue',
    navReport: 'Report',
    navNotifications: 'Notifications',
    navClearAll: 'Clear all',
    navNoNotifications: 'No new notifications.',
    navSignIn: 'Sign In',
    navStudentLogin: 'Student Sign In',
    navAdminLogin: 'Admin Portal Login',
    navLogout: 'Sign Out',
    navLoggedInAs: 'Signed in as',

    // Landing Page
    heroBadge: 'Smart Campus Resolution Hub · SATI Vidisha',
    heroHeadingLine1: 'Your Campus.',
    heroHeadingLine2: 'Your Voice.',
    heroHeadingLine3: 'Your Better Tomorrow.',
    heroSubtitle: 'A centralized digital platform connecting students with administration. Report any campus problem with smart urgency scoring, transparent tracking, and automated prioritization.',
    heroCtaReport: 'Report an Issue',
    heroCtaExplore: 'Explore Dashboard',
    heroCtaTrack: 'Track Complaint',
    statsTotalComplaints: 'Total Complaints',
    statsPendingComplaints: 'Pending Review',
    statsInProgress: 'Under Resolution',
    statsResolvedComplaints: 'Resolved Complaints',
    statsResolutionRate: 'Resolution Efficiency',
    statsAvgResolutionTime: 'Avg. Resolution Time',

    // Features Section
    featuresHeading: 'Why CampusAxis at SATI Vidisha?',
    featuresSubheading: 'Built specifically to streamline problem escalation, ensure accountability, and deliver verifiable campus improvements.',
    feature1Title: 'Smart Urgency & Priority Queue',
    feature1Desc: 'Automated 5-factor scoring factors category weights, student scale, safety hazards, and pending age to bubble critical issues instantly.',
    feature2Title: '15 Universal Campus Categories',
    feature2Desc: 'From lab equipment and Wi-Fi to cleanliness, food, safety, and an open custom complaint box for any unlisted challenge.',
    feature3Title: 'End-to-End Live Tracking',
    feature3Desc: 'Real-time timeline audits from the moment a ticket is raised through administrative dispatch, inspection remarks, and resolution.',
    feature4Title: 'Student Feedback & Rating',
    feature4Desc: 'Issues are not truly resolved until the reporting student rates the work and verifies satisfaction or requests reopening.',

    // How it works
    howHeading: 'How CampusAxis Resolves Issues',
    howSubheading: 'Four simple steps from student observation to certified campus resolution.',
    howStep1Title: '1. File Complaint with Urgency',
    howStep1Desc: 'Student enters location, details, photos, urgency level, and scope in seconds.',
    howStep2Title: '2. Smart Priority Calculation',
    howStep2Desc: 'Our engine computes weight based on urgency, affected students, safety, and pending hours.',
    howStep3Title: '3. Admin Dispatch & Action',
    howStep3Desc: 'Concerned department is assigned, engineers inspect, and status is logged on the audit timeline.',
    howStep4Title: '4. Resolution & Student Verification',
    howStep4Desc: 'Students verify completion, rate work quality, or request reopening if the issue reoccurs.',

    // Categories (all 15)
    catInternet: 'Internet & Wi-Fi',
    catClassroom: 'Classroom Issues',
    catHostel: 'Hostel Issues',
    catLab: 'Laboratory Issues',
    catLibrary: 'Library Issues',
    catCanteen: 'Canteen & Food',
    catCleanliness: 'Cleanliness & Sanitation',
    catWaterPower: 'Water & Electricity',
    catInfra: 'Campus Infrastructure',
    catAdmin: 'Administration',
    catSecurity: 'Security & Safety',
    catSports: 'Sports & Recreation',
    catTransport: 'Transport & Parking',
    catMedical: 'Medical & Health Facilities',
    catOther: 'Other / Describe Your Own Problem',

    // Urgency & Priority
    urgencyCritical: 'Critical (+4 pts)',
    urgencyHigh: 'High (+3 pts)',
    urgencyMedium: 'Medium (+2 pts)',
    urgencyLow: 'Low (+1 pt)',
    priorityScore: 'Priority Score',
    priorityLabel: 'Priority Tier',
    priorityQueue: 'Smart Priority Queue',
    priorityEngine: 'Smart Urgency Priority Engine',
    reasonForPrioritization: 'Reason for Prioritization',

    // Statuses
    statusRaised: 'Raised',
    statusInProgress: 'In Progress',
    statusResolved: 'Resolved',

    // Student Portal
    studentDashboardTitle: 'Student Complaint & Resolution Hub',
    studentDashboardSubtitle: 'Submit problems across campus, monitor live updates, and verify department resolutions.',
    tabOverview: 'Dashboard Overview',
    tabSubmitComplaint: 'Submit New Complaint',
    tabMyComplaints: 'My Complaints',
    tabTrackComplaint: 'Track Complaint',
    tabNotifications: 'Notifications',
    tabProfileSettings: 'Profile & Settings',
    studentSubmitTitle: 'File a Campus Issue',
    studentSubmitSubtitle: 'Provide clear information so administration can prioritize and dispatch the right department.',
    fieldCategory: 'Complaint Category',
    fieldSelectCategory: '-- Choose a Category --',
    fieldCustomTitle: 'Custom Problem Title',
    fieldComplaintTitle: 'Complaint Title',
    fieldDescription: 'Detailed Description',
    fieldLocation: 'Campus Location / Zone',
    fieldBlockRoom: 'Block / Building / Room (Optional)',
    fieldUrgency: 'Urgency Assessment',
    fieldAffectedScale: 'Number of Students Affected',
    fieldSafetyHazard: 'Safety Hazard Impact',
    fieldSafetyHazardLabel: 'This issue creates an active safety risk (exposed wiring, broken glass, chemical hazard, fire risk)',
    fieldAttachImage: 'Attach Photo Evidence (Optional)',
    fieldSubmitAnonymous: 'Submit Anonymously (Hide my name & enrollment)',
    btnSubmitComplaint: 'Submit Complaint',
    btnSubmitting: 'Registering Complaint...',
    livePriorityPreview: 'Live Priority Engine Calculation Preview',

    // Empty States
    emptyComplaintsTitle: 'No Complaints Found',
    emptyComplaintsDesc: 'No campus complaint records currently match this filter.',
    emptyPriorityQueueTitle: 'Active Priority Queue is Empty',
    emptyPriorityQueueDesc: 'All reported issues have been resolved, or no pending complaints have been filed yet.',
    emptyMyComplaintsTitle: 'You have not submitted any complaints yet',
    emptyMyComplaintsDesc: 'Report campus problems regarding Wi-Fi, labs, classrooms, hostels, or electricity to see them here.',
    emptyNotificationsTitle: 'No Notifications Yet',
    emptyNotificationsDesc: 'You will receive real-time notifications here when complaint statuses or priorities change.',

    // Admin Portal
    adminPortalTitle: 'SATI Administrative Command Center',
    adminPortalSubtitle: 'Smart urgency-driven ticket queue, departmental dispatch, and campus issue resolution.',
    tabSmartQueue: 'Smart Priority Queue',
    tabAllComplaints: 'All Complaints Registry',
    adminSearchPlaceholder: 'Search by ID, title, student, department or location...',
    filterAll: 'All Priorities',
    filterCritical: 'Critical Priority',
    filterHigh: 'High Priority',
    filterMedium: 'Medium Priority',
    filterLow: 'Low Priority',
    btnOverridePriority: 'Manual Override',
    btnUpdateStatus: 'Update Status',
    btnAssignDept: 'Assign Department',
    btnManageAdmins: 'Admin Access Management',
    modalOverrideTitle: 'Manual Priority Override',
    modalOverrideMandatoryReason: 'Mandatory Reason for Override',
    modalOverrideReasonPlaceholder: 'State why this complaint priority is being modified (min. 5 characters)...',
    btnSaveOverride: 'Confirm Priority Override',

    // Auth (Student & Admin)
    authStudentTitle: 'Student Portal Authentication',
    authStudentSubtitle: 'Access your personalized student dashboard, submit issues, and track your complaints.',
    authStudentLoginTab: 'Student Login',
    authStudentRegisterTab: 'Student Registration',
    authAdminTitle: 'Campus Administrator Login',
    authAdminSubtitle: 'Authorized access for SATI department officers, engineers, and administrative committee.',
    authFullName: 'Full Name',
    authCollegeEmail: 'College Email Address',
    authStudentId: 'Student ID / Enrollment Number',
    authDepartment: 'Department / Branch',
    authYearSemester: 'Academic Year / Semester',
    authPassword: 'Password',
    authConfirmPassword: 'Confirm Password',
    authRememberMe: 'Remember Me',
    authForgotPassword: 'Forgot Password?',
    authDontHaveAccount: "Don't have a student account? Sign up now",
    authAlreadyHaveAccount: 'Already registered? Log in here',
    authLoginBtn: 'Log In to Student Portal',
    authRegisterBtn: 'Create Student Account',
    authAdminUsernameOrEmail: 'Admin Email or Username',
    authAdminLoginBtn: 'Authenticate as Administrator',
    authAdminNoPublicSignUpNote: 'Notice: Public administrator registration is restricted. Admin accounts can only be provisioned by authorized SATI authorities.',
    authFirstTimeAdminSetup: 'First-Time Administrator Setup',
    authAuthorizationKey: 'Institutional Authorization Key',
    authInitializeRootAdminBtn: 'Initialize Authorized Root Admin',
    authPasswordMismatch: 'Passwords do not match. Please re-enter carefully.',
    authMustBeLoggedInStudent: 'Please log in with your student credentials to view and manage your complaints.',
    authMustBeLoggedInAdmin: 'Administrator login required to access the Administrative Command Center.',
    authLogoutSuccess: 'You have been logged out successfully.',
    authLoginSuccess: 'Welcome back! Authentication successful.',
    authRegisterSuccess: 'Student account created successfully! You are now logged in.',

    // Common UI
    btnCancel: 'Cancel',
    btnClose: 'Close',
    btnSave: 'Save Changes',
    btnViewDetails: 'View Details',
    btnTrack: 'Track',
    btnReset: 'Reset Filter',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    footerRights: 'Samrat Ashok Technological Institute (SATI), Vidisha (M.P.). All rights reserved.',
    footerAddress: 'Civil Lines, Vidisha, Madhya Pradesh - 464001',
    footerHelpline: 'Campus Maintenance Helpline: +91 7592 250121 | support@satiengg.in',
    languageName: 'English',
  },
  hi: {
    // Brand & Nav
    brandTitle: 'कैंपस एक्सिस',
    brandTagline: 'सती विदिशा · स्मार्ट शिकायत एवं निवारण केंद्र',
    navOverview: 'अवलोकन',
    navStudentPortal: 'छात्र पोर्टल',
    navAdminHub: 'प्रशासन केंद्र',
    navAnalytics: 'एनालिटिक्स',
    navTrackIssue: 'शिकायत ट्रैक करें',
    navReportIssue: 'शिकायत दर्ज करें',
    navReport: 'दर्ज करें',
    navNotifications: 'सूचनाएं',
    navClearAll: 'सभी हटाएं',
    navNoNotifications: 'कोई नई सूचना नहीं है।',
    navSignIn: 'लॉग इन करें',
    navStudentLogin: 'छात्र प्रवेश (लॉग इन)',
    navAdminLogin: 'प्रशासक प्रवेश',
    navLogout: 'लॉग आउट',
    navLoggedInAs: 'लॉग इन उपयोगकर्ता',

    // Landing Page
    heroBadge: 'स्मार्ट परिसर समस्या निवारण केंद्र · सती विदिशा',
    heroHeadingLine1: 'आपका परिसर।',
    heroHeadingLine2: 'आपकी आवाज़।',
    heroHeadingLine3: 'आपका बेहतर कल।',
    heroSubtitle: 'छात्रों और प्रशासन को जोड़ने वाला एक एकीकृत डिजिटल मंच। स्मार्ट तात्कालिकता प्राथमिकता, पारदर्शी ट्रैकिंग और त्वरित निवारण के साथ परिसर की किसी भी समस्या को दर्ज करें।',
    heroCtaReport: 'शिकायत दर्ज करें',
    heroCtaExplore: 'डैशबोर्ड देखें',
    heroCtaTrack: 'शिकायत ट्रैक करें',
    statsTotalComplaints: 'कुल शिकायतें',
    statsPendingComplaints: 'लंबित समीक्षा',
    statsInProgress: 'निवारण प्रगति पर',
    statsResolvedComplaints: 'हल की गई शिकायतें',
    statsResolutionRate: 'निवारण दक्षता',
    statsAvgResolutionTime: 'औसत निवारण समय',

    // Features Section
    featuresHeading: 'सती विदिशा में कैंपस एक्सिस क्यों आवश्यक है?',
    featuresSubheading: 'परिसर की समस्याओं के त्वरित निवारण, पारदर्शिता और जवाबदेही सुनिश्चित करने के लिए विशेष रूप से निर्मित।',
    feature1Title: 'स्मार्ट तात्कालिकता एवं प्राथमिकता कतार',
    feature1Desc: '5-कारकों पर आधारित स्वचालित स्कोरिंग: श्रेणी भार, प्रभावित छात्रों की संख्या, सुरक्षा जोखिम और लंबित समय के आधार पर गंभीर समस्याओं को तुरंत शीर्ष पर लाती है।',
    feature2Title: '15 व्यापक परिसर श्रेणियां',
    feature2Desc: 'प्रयोगशाला उपकरण, वाई-फाई, स्वच्छता, जल-बिजली, भोजन व्यवस्था से लेकर किसी भी अनूठी समस्या हेतु समर्पित कस्टम बॉक्स।',
    feature3Title: 'शुरू से अंत तक लाइव ट्रैकिंग',
    feature3Desc: 'शिकायत दर्ज होने से लेकर विभाग आवंटन, अभियंता निरीक्षण और कार्य पूर्ण होने तक हर चरण का समयबद्ध ऑडिट।',
    feature4Title: 'छात्र सत्यापन एवं रेटिंग',
    feature4Desc: 'समस्या तब तक पूर्णतः हल नहीं मानी जाती जब तक शिकायतकर्ता छात्र कार्य की गुणवत्ता को प्रमाणित और रेट न कर दे।',

    // How it works
    howHeading: 'कैंपस एक्सिस कैसे कार्य करता है?',
    howSubheading: 'छात्र की शिकायत से लेकर प्रमाणित परिसर सुधार तक के चार सरल चरण।',
    howStep1Title: '1. तात्कालिकता के साथ शिकायत दर्ज करें',
    howStep1Desc: 'छात्र स्थान, विवरण, फोटो, तात्कालिकता स्तर और प्रभावित क्षेत्र की जानकारी भरते हैं।',
    howStep2Title: '2. स्मार्ट प्राथमिकता गणना',
    howStep2Desc: 'हमारा इंजन तात्कालिकता, प्रभावित छात्रों, सुरक्षा जोखिम और लंबित घंटों के आधार पर प्राथमिकता स्कोर निकालता है।',
    howStep3Title: '3. प्रशासनिक आवंटन एवं कार्रवाई',
    howStep3Desc: 'संबंधित विभाग को कार्य सौंपा जाता है, तकनीशियन निरीक्षण करते हैं और स्थिति को टाइमलाइन पर दर्ज किया जाता है।',
    howStep4Title: '4. समाधान एवं छात्र संतुष्टि सत्यापन',
    howStep4Desc: 'छात्र कार्य की संतुष्टि की पुष्टि करते हैं, रेटिंग देते हैं या असंतोष होने पर पुनः खोलने का अनुरोध करते हैं।',

    // Categories (all 15)
    catInternet: 'इंटरनेट एवं वाई-फाई',
    catClassroom: 'कक्षा संबंधी समस्याएं',
    catHostel: 'छात्रावास संबंधी समस्याएं',
    catLab: 'प्रयोगशाला संबंधी समस्याएं',
    catLibrary: 'पुस्तकालय संबंधी समस्याएं',
    catCanteen: 'कैंटीन एवं भोजन व्यवस्था',
    catCleanliness: 'स्वच्छता एवं स्वच्छता प्रबंधन',
    catWaterPower: 'जल एवं विद्युत आपूर्ति',
    catInfra: 'परिसर अवसंरचना',
    catAdmin: 'प्रशासनिक कार्य',
    catSecurity: 'सुरक्षा एवं संरक्षा',
    catSports: 'खेलकूद एवं मनोरंजन',
    catTransport: 'परिवहन एवं वाहन पार्किंग',
    catMedical: 'चिकित्सा एवं स्वास्थ्य सेवाएं',
    catOther: 'अन्य / अपनी समस्या विस्तार से लिखें',

    // Urgency & Priority
    urgencyCritical: 'अति आवश्यक / क्रिटिकल (+4 अंक)',
    urgencyHigh: 'उच्च प्राथमिकता (+3 अंक)',
    urgencyMedium: 'मध्यम प्राथमिकता (+2 अंक)',
    urgencyLow: 'सामान्य / कम (+1 अंक)',
    priorityScore: 'प्राथमिकता स्कोर',
    priorityLabel: 'प्राथमिकता स्तर',
    priorityQueue: 'स्मार्ट प्राथमिकता कतार',
    priorityEngine: 'स्मार्ट तात्कालिकता प्राथमिकता इंजन',
    reasonForPrioritization: 'प्राथमिकता का मुख्य कारण',

    // Statuses
    statusRaised: 'दर्ज की गई',
    statusInProgress: 'प्रगति पर',
    statusResolved: 'हल हो चुकी',

    // Student Portal
    studentDashboardTitle: 'छात्र शिकायत एवं निवारण केंद्र',
    studentDashboardSubtitle: 'परिसर की समस्याएं दर्ज करें, वास्तविक समय पर स्थिति ट्रैक करें और समाधान की पुष्टि करें।',
    tabOverview: 'डैशबोर्ड अवलोकन',
    tabSubmitComplaint: 'नई शिकायत दर्ज करें',
    tabMyComplaints: 'मेरी शिकायतें',
    tabTrackComplaint: 'शिकायत ट्रैक करें',
    tabNotifications: 'सूचनाएं',
    tabProfileSettings: 'प्रोफाइल एवं सेटिंग्स',
    studentSubmitTitle: 'परिसर समस्या दर्ज करें',
    studentSubmitSubtitle: 'सटीक जानकारी भरें ताकि प्रशासन सही विभाग को तुरंत भेजकर समस्या का समाधान कर सके।',
    fieldCategory: 'शिकायत की श्रेणी',
    fieldSelectCategory: '-- श्रेणी चुनें --',
    fieldCustomTitle: 'कस्टम समस्या का शीर्षक',
    fieldComplaintTitle: 'समस्या का शीर्षक',
    fieldDescription: 'समस्या का विस्तृत विवरण',
    fieldLocation: 'परिसर में स्थान / क्षेत्र',
    fieldBlockRoom: 'ब्लॉक / भवन / कक्ष संख्या (वैकल्पिक)',
    fieldUrgency: 'तात्कालिकता का स्तर',
    fieldAffectedScale: 'प्रभावित छात्रों की संख्या',
    fieldSafetyHazard: 'सुरक्षा जोखिम का प्रभाव',
    fieldSafetyHazardLabel: 'इस समस्या से प्रत्यक्ष सुरक्षा खतरा है (जैसे खुला बिजली का तार, टूटा कांच, रासायनिक जोखिम, आग का खतरा)',
    fieldAttachImage: 'फोटो साक्ष्य संलग्न करें (वैकल्पिक)',
    fieldSubmitAnonymous: 'गुमनाम रूप से दर्ज करें (नाम एवं नामांकन छिपाएं)',
    btnSubmitComplaint: 'शिकायत जमा करें',
    btnSubmitting: 'शिकायत दर्ज हो रही है...',
    livePriorityPreview: 'लाइव प्राथमिकता इंजन स्कोर पूर्वानुमान',

    // Empty States
    emptyComplaintsTitle: 'कोई शिकायत नहीं मिली',
    emptyComplaintsDesc: 'वर्तमान में इस फ़िल्टर के अनुसार कोई शिकायत रिकॉर्ड उपलब्ध नहीं है।',
    emptyPriorityQueueTitle: 'सक्रिय प्राथमिकता कतार खाली है',
    emptyPriorityQueueDesc: 'सभी दर्ज शिकायतों का निवारण हो चुका है, या कोई लंबित शिकायत दर्ज नहीं है।',
    emptyMyComplaintsTitle: 'आपने अभी तक कोई शिकायत दर्ज नहीं की है',
    emptyMyComplaintsDesc: 'वाई-फाई, प्रयोगशाला, कक्षा, छात्रावास या बिजली संबंधी समस्याएं दर्ज करने पर वे यहां दिखाई देंगी।',
    emptyNotificationsTitle: 'कोई नई सूचना नहीं है',
    emptyNotificationsDesc: 'शिकायत की स्थिति या प्राथमिकता बदलने पर आपको यहां तुरंत सूचनाएं प्राप्त होंगी।',

    // Admin Portal
    adminPortalTitle: 'सती प्रशासनिक नियंत्रण केंद्र',
    adminPortalSubtitle: 'स्मार्ट तात्कालिकता-संचालित प्राथमिकता कतार, विभागीय आवंटन एवं समस्या समाधान।',
    tabSmartQueue: 'स्मार्ट प्राथमिकता कतार',
    tabAllComplaints: 'समस्त शिकायत पंजिका',
    adminSearchPlaceholder: 'आईडी, शीर्षक, छात्र, विभाग या स्थान से खोजें...',
    filterAll: 'सभी प्राथमिकताएं',
    filterCritical: 'अति आवश्यक (क्रिटिकल)',
    filterHigh: 'उच्च प्राथमिकता',
    filterMedium: 'मध्यम प्राथमिकता',
    filterLow: 'सामान्य प्राथमिकता',
    btnOverridePriority: 'मैन्युअल प्राथमिकता बदलें',
    btnUpdateStatus: 'स्थिति अपडेट करें',
    btnAssignDept: 'विभाग सौंपें',
    btnManageAdmins: 'प्रशासक अधिकार प्रबंधन',
    modalOverrideTitle: 'प्राथमिकता का मैन्युअल संशोधन',
    modalOverrideMandatoryReason: 'संशोधन का अनिवार्य कारण',
    modalOverrideReasonPlaceholder: 'प्राथमिकता बदलने का आधिकारिक कारण बताएं (न्यूनतम 5 अक्षर)...',
    btnSaveOverride: 'प्राथमिकता संशोधन सहेजें',

    // Auth (Student & Admin)
    authStudentTitle: 'छात्र पोर्टल प्रमाणीकरण',
    authStudentSubtitle: 'अपने व्यक्तिगत छात्र डैशबोर्ड तक पहुंचने, समस्याएं दर्ज करने और ट्रैक करने के लिए प्रवेश करें।',
    authStudentLoginTab: 'छात्र लॉग इन',
    authStudentRegisterTab: 'छात्र नया पंजीकरण',
    authAdminTitle: 'परिसर प्रशासक लॉग इन',
    authAdminSubtitle: 'सती विभागाध्यक्षों, अभियंताओं एवं प्रशासनिक समिति हेतु अधिकृत सुरक्षित प्रवेश।',
    authFullName: 'पूरा नाम',
    authCollegeEmail: 'कॉलेज ईमेल पता',
    authStudentId: 'छात्र आईडी / नामांकन संख्या (Enrollment No.)',
    authDepartment: 'विभाग / शाखा (Branch)',
    authYearSemester: 'शैक्षणिक वर्ष / सेमेस्टर',
    authPassword: 'पासवर्ड',
    authConfirmPassword: 'पासवर्ड की पुनः पुष्टि करें',
    authRememberMe: 'मुझे याद रखें',
    authForgotPassword: 'पासवर्ड भूल गए?',
    authDontHaveAccount: 'क्या आपका छात्र खाता नहीं है? अभी नया पंजीकरण करें',
    authAlreadyHaveAccount: 'पहले से पंजीकृत हैं? यहां लॉग इन करें',
    authLoginBtn: 'छात्र पोर्टल में लॉग इन करें',
    authRegisterBtn: 'नया छात्र खाता बनाएं',
    authAdminUsernameOrEmail: 'प्रशासक ईमेल या उपयोगकर्ता नाम (Username)',
    authAdminLoginBtn: 'प्रशासक के रूप में प्रवेश करें',
    authAdminNoPublicSignUpNote: 'सूचना: प्रशासक पंजीकरण सार्वजनिक नहीं है। प्रशासक खाते केवल सती कॉलेज प्रशासन द्वारा अधिकृत किए जाते हैं।',
    authFirstTimeAdminSetup: 'प्रथम बार प्रशासक खाता व्यवस्थापन (Setup)',
    authAuthorizationKey: 'संस्थागत प्राधिकरण कुंजी (Authorization Key)',
    authInitializeRootAdminBtn: 'अधिकृत मुख्य प्रशासक खाता बनाएं',
    authPasswordMismatch: 'पासवर्ड मेल नहीं खाते। कृपया पुनः सावधानीपूर्वक दर्ज करें।',
    authMustBeLoggedInStudent: 'अपनी शिकायतों को देखने और दर्ज करने के लिए कृपया छात्र खाते से लॉग इन करें।',
    authMustBeLoggedInAdmin: 'प्रशासनिक नियंत्रण केंद्र तक पहुंचने के लिए प्रशासक प्रमाणीकरण आवश्यक है।',
    authLogoutSuccess: 'आप सफलतापूर्वक लॉग आउट हो गए हैं।',
    authLoginSuccess: 'स्वागत है! प्रमाणीकरण सफल रहा।',
    authRegisterSuccess: 'छात्र खाता सफलतापूर्वक बन गया है! आप लॉग इन हो चुके हैं।',

    // Common UI
    btnCancel: 'रद्द करें',
    btnClose: 'बंद करें',
    btnSave: 'परिवर्तन सहेजें',
    btnViewDetails: 'विस्तृत विवरण देखें',
    btnTrack: 'ट्रैक करें',
    btnReset: 'फ़िल्टर हटाएं',
    loading: 'लोड हो रहा है...',
    searchPlaceholder: 'खोजें...',
    footerRights: 'सम्राट अशोक टेक्नोलॉजिकल इंस्टीट्यूट (सती), विदिशा (म.प्र.)। सर्वाधिकार सुरक्षित।',
    footerAddress: 'सिविल लाइन्स, विदिशा, मध्य प्रदेश - 464001',
    footerHelpline: 'परिसर रखरखाव हेल्पलाइन: +91 7592 250121 | support@satiengg.in',
    languageName: 'हिंदी',
  },
};

export const CATEGORY_MAP_EN_TO_HI: Record<string, string> = {
  'Internet & Wi-Fi': 'इंटरनेट एवं वाई-फाई',
  'Classroom Issues': 'कक्षा संबंधी समस्याएं',
  'Hostel Issues': 'छात्रावास संबंधी समस्याएं',
  'Laboratory Issues': 'प्रयोगशाला संबंधी समस्याएं',
  'Library Issues': 'पुस्तकालय संबंधी समस्याएं',
  'Canteen & Food': 'कैंटीन एवं भोजन व्यवस्था',
  'Cleanliness & Sanitation': 'स्वच्छता एवं स्वच्छता प्रबंधन',
  'Water & Electricity': 'जल एवं विद्युत आपूर्ति',
  'Campus Infrastructure': 'परिसर अवसंरचना',
  'Administration': 'प्रशासनिक कार्य',
  'Security & Safety': 'सुरक्षा एवं संरक्षा',
  'Sports & Recreation': 'खेलकूद एवं मनोरंजन',
  'Transport & Parking': 'परिवहन एवं वाहन पार्किंग',
  'Medical & Health Facilities': 'चिकित्सा एवं स्वास्थ्य सेवाएं',
  'Other / Describe Your Own Problem': 'अन्य / अपनी समस्या विस्तार से लिखें',
};

export const STATUS_MAP_EN_TO_HI: Record<string, string> = {
  'Raised': 'दर्ज की गई',
  'In Progress': 'प्रगति पर',
  'Resolved': 'हल हो चुकी',
};

export const URGENCY_MAP_EN_TO_HI: Record<string, string> = {
  'Critical': 'अति आवश्यक (क्रिटिकल)',
  'High': 'उच्च',
  'Medium': 'मध्यम',
  'Low': 'सामान्य (कम)',
};

export function getTranslatedCategory(cat: string, lang: Language): string {
  if (lang === 'hi') {
    return CATEGORY_MAP_EN_TO_HI[cat] || cat;
  }
  return cat;
}

export function getTranslatedStatus(status: string, lang: Language): string {
  if (lang === 'hi') {
    return STATUS_MAP_EN_TO_HI[status] || status;
  }
  return status;
}

export function getTranslatedUrgency(urgency: string, lang: Language): string {
  if (lang === 'hi') {
    return URGENCY_MAP_EN_TO_HI[urgency] || urgency;
  }
  return urgency;
}
