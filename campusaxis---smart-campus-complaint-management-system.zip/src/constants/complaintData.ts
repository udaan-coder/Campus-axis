import { Complaint, ComplaintCategory, UrgencyLevel, AffectedScale, PriorityBreakdown } from '../types/complaint';

// Real authentic image of SATI Vidisha campus provided by user
export const SATI_CAMPUS_HERO_IMAGE = '/assets/aistudio/Screenshot_2026-11-03_112403_0b357d01.png';

/**
 * Official Baseline Category Weights
 * Mandatory baseline:
 * - Wi-Fi = 2
 * - Hostel = 2
 * - Classroom = 1
 * - Laboratory = 3
 * Documented weights for remaining campus categories based on severity and academic impact.
 */
export const CATEGORY_WEIGHTS: Record<ComplaintCategory, number> = {
  'Internet & Wi-Fi': 2, // Official Baseline
  'Hostel Issues': 2, // Official Baseline
  'Classroom Issues': 1, // Official Baseline
  'Laboratory Issues': 3, // Official Baseline
  'Cleanliness & Sanitation': 2,
  'Water & Electricity': 3,
  'Campus Infrastructure': 2,
  'Administration': 1,
  'Security & Safety': 4,
  'Sports & Recreation': 1,
  'Transport & Parking': 2,
  'Medical & Health Facilities': 4,
  'Library Issues': 1,
  'Canteen & Food': 2,
  'Other / Describe Your Own Problem': 2,
};

export const CAMPUS_LOCATIONS = [
  'Academic Block A (Computer Science & IT)',
  'Academic Block B (Civil & Mechanical)',
  'Academic Block C (Electrical & Electronics)',
  'Central Library & Reading Hall',
  "Boy's Hostel (Aryabhatta Bhawan)",
  "Boy's Hostel (Sir M. Visvesvaraya Bhawan)",
  "Girl's Hostel (Kalpana Chawla Bhawan)",
  'Central Canteen & Cafeteria',
  'Advanced Computing Laboratory',
  'Mechanical & Civil Workshop',
  'Sports Complex & Football Ground',
  'Main Gate & Proctorial Security',
  'Campus Parking Zone',
  'Health Center & Dispensary',
  'Administrative Block & Dean Office',
  'Other Campus Location',
];

export const DEPARTMENTS = [
  'Network & IT Infrastructure Cell',
  'Hostel Administration & Mess Committee',
  'Electrical & Power Maintenance',
  'Estate & Civil Works Division',
  'Sanitation & Housekeeping Wing',
  'Academic Affairs & Classrooms',
  'Lab Technical Support & Instrumentation',
  'Proctorial Board & Campus Security',
  'Canteen Management Committee',
  'Transport & Fleet Cell',
  'Health & Medical Dispensary',
  'Central Library Administration',
  'General Administration',
];

/**
 * Calculate Pending Hours dynamically from submission time
 */
export function getPendingHours(createdAt: string): number {
  const createdTime = new Date(createdAt).getTime();
  const diffMs = Math.max(0, Date.now() - createdTime);
  return Math.floor(diffMs / (1000 * 60 * 60));
}

export const URGENCY_SCORES: Record<UrgencyLevel, number> = {
  Critical: 4,
  High: 3,
  Medium: 2,
  Low: 1,
};

export const AFFECTED_SCORES: Record<AffectedScale, number> = {
  'Individual (1 student)': 0,
  'Room / Bench (2–10 students)': 1,
  'Class / Wing (10–50 students)': 2,
  'Entire Block / Campus (>50 students)': 3,
};

export const SAFETY_HAZARD_BONUS = 3;

/**
 * Smart Multi-Factor Priority Calculation Engine:
 * Computes priority based on:
 * 1. Category Weight (official baseline + campus facilities)
 * 2. Selected Urgency Level (Critical=+4, High=+3, Medium=+2, Low=+1)
 * 3. Time Elapsed / Aging Bonus (floor(Pending Hours / 24))
 * 4. Number of Students Affected (Individual=+0, Room=+1, Class=+2, Campus=+3)
 * 5. Direct Safety Hazard Impact (+3 bonus points)
 * Supports manual administrative overrides with recorded audit reasons.
 */
export function calculatePriorityScore(
  category: ComplaintCategory,
  createdAt: string,
  urgency: UrgencyLevel = 'Medium',
  affectedScale: AffectedScale = 'Individual (1 student)',
  safetyHazard: boolean = false,
  isOverridden: boolean = false,
  overriddenUrgency?: UrgencyLevel,
  overriddenScore?: number
): {
  score: number;
  totalScore: number;
  priorityLabel: UrgencyLevel;
  categoryWeight: number;
  urgencyScore: number;
  pendingHours: number;
  ageDays: number;
  affectedScore: number;
  safetyScore: number;
  explanation: string;
  reason: string;
  breakdown: PriorityBreakdown;
} {
  const categoryWeight = CATEGORY_WEIGHTS[category] ?? 2;
  const pendingHours = getPendingHours(createdAt);
  const ageDays = Math.floor(pendingHours / 24);

  const effectiveUrgency = isOverridden && overriddenUrgency ? overriddenUrgency : urgency;
  const urgencyScore = URGENCY_SCORES[effectiveUrgency] ?? 2;
  const affectedScore = AFFECTED_SCORES[affectedScale] ?? 0;
  const safetyScore = safetyHazard ? SAFETY_HAZARD_BONUS : 0;

  let totalScore = categoryWeight + urgencyScore + ageDays + affectedScore + safetyScore;
  if (isOverridden && typeof overriddenScore === 'number') {
    totalScore = overriddenScore;
  }

  // Determine priority label
  let priorityLabel: UrgencyLevel = 'Low';
  if (effectiveUrgency === 'Critical' || totalScore >= 10) {
    priorityLabel = 'Critical';
  } else if (effectiveUrgency === 'High' || totalScore >= 7) {
    priorityLabel = 'High';
  } else if (effectiveUrgency === 'Medium' || totalScore >= 4) {
    priorityLabel = 'Medium';
  } else {
    priorityLabel = 'Low';
  }

  const reasonParts: string[] = [
    `Category: ${category} (+${categoryWeight})`,
    `Urgency: ${effectiveUrgency} (+${urgencyScore})`,
    `Pending: ${pendingHours}h (+${ageDays} age bonus)`,
  ];
  if (affectedScore > 0) {
    reasonParts.push(`Affected: ${affectedScale} (+${affectedScore})`);
  }
  if (safetyScore > 0) {
    reasonParts.push(`Direct Safety Hazard (+${safetyScore})`);
  }
  if (isOverridden) {
    reasonParts.push(`[Manually Overridden by Admin]`);
  }

  const explanation = `Category (+${categoryWeight}) + Urgency (+${urgencyScore}) + Age (+${ageDays}) + Affected (+${affectedScore}) + Safety (+${safetyScore})`;
  const reason = reasonParts.join(' · ');

  const breakdown: PriorityBreakdown = {
    categoryWeight,
    urgencyScore,
    ageBonus: ageDays,
    affectedScore,
    safetyScore,
    totalScore,
    priorityLabel,
    reason,
  };

  return {
    score: totalScore,
    totalScore,
    priorityLabel,
    categoryWeight,
    urgencyScore,
    pendingHours,
    ageDays,
    affectedScore,
    safetyScore,
    explanation,
    reason,
    breakdown,
  };
}

/**
 * Keyword-based Smart Category Suggestion Engine
 */
export function suggestCategoryFromText(text: string): {
  category: ComplaintCategory | null;
  matchedKeyword: string | null;
  confidence: 'High' | 'Medium' | 'Low';
} {
  const lower = text.toLowerCase();

  const rules: { keywords: string[]; category: ComplaintCategory; confidence: 'High' | 'Medium' }[] = [
    {
      keywords: ['wifi', 'wi-fi', 'internet', 'router', 'lan', 'ethernet', 'bandwidth', 'disconnect', 'slow net', 'network', 'signal'],
      category: 'Internet & Wi-Fi',
      confidence: 'High',
    },
    {
      keywords: ['hostel', 'room', 'bed', 'warden', 'mess', 'roommate', 'corridor', 'dorm', 'geyser', 'almirah'],
      category: 'Hostel Issues',
      confidence: 'High',
    },
    {
      keywords: ['classroom', 'bench', 'blackboard', 'whiteboard', 'desk', 'podium', 'chalk', 'duster', 'lecture hall', 'smartboard'],
      category: 'Classroom Issues',
      confidence: 'High',
    },
    {
      keywords: ['lab', 'laboratory', 'oscilloscope', 'pipette', 'chemical', 'pc hang', 'computer lab', 'trainer kit', 'microscope', 'multimeter'],
      category: 'Laboratory Issues',
      confidence: 'High',
    },
    {
      keywords: ['library', 'book', 'issue card', 'reading room', 'journal', 'librarian', 'catalog', 'reference book', 'shelf'],
      category: 'Library Issues',
      confidence: 'High',
    },
    {
      keywords: ['canteen', 'food', 'snack', 'hygiene', 'dining', 'cafeteria', 'meal', 'tea', 'samosa', 'dirty plate', 'drinking water canteen'],
      category: 'Canteen & Food',
      confidence: 'High',
    },
    {
      keywords: ['clean', 'dustbin', 'garbage', 'trash', 'washroom', 'toilet', 'sanitary', 'smell', 'sweeper', 'debris', 'drain'],
      category: 'Cleanliness & Sanitation',
      confidence: 'High',
    },
    {
      keywords: ['electricity', 'power cut', 'switch', 'socket', 'bulb', 'tube light', 'fan', 'wiring', 'spark', 'short circuit', 'voltage'],
      category: 'Water & Electricity',
      confidence: 'High',
    },
    {
      keywords: ['tap', 'water cooler', 'plumbing', 'pipe', 'leakage', 'overflow', 'no water', 'ro filter', 'tank'],
      category: 'Water & Electricity',
      confidence: 'High',
    },
    {
      keywords: ['road', 'building', 'crack', 'tile', 'roof', 'boundary wall', 'gate', 'railing', 'stairs', 'lift', 'elevator'],
      category: 'Campus Infrastructure',
      confidence: 'High',
    },
    {
      keywords: ['security', 'guard', 'theft', 'stolen', 'unauthorized', 'harassment', 'ragging', 'cctv', 'id card check', 'fight', 'safety'],
      category: 'Security & Safety',
      confidence: 'High',
    },
    {
      keywords: ['sports', 'ground', 'cricket', 'badminton', 'gym', 'football', 'basketball', 'table tennis', 'net broken', 'court'],
      category: 'Sports & Recreation',
      confidence: 'High',
    },
    {
      keywords: ['parking', 'bus', 'vehicle', 'scooter', 'helmet', 'transport', 'college bus', 'traffic', 'driver', 'stand'],
      category: 'Transport & Parking',
      confidence: 'High',
    },
    {
      keywords: ['doctor', 'medical', 'first aid', 'dispensary', 'medicine', 'fever', 'ambulance', 'health', 'nurse', 'bandage'],
      category: 'Medical & Health Facilities',
      confidence: 'High',
    },
    {
      keywords: ['fee', 'scholarship', 'form', 'clerk', 'office', 'certificate', 'dean', 'hod', 'admin', 'marksheet', 'admit card'],
      category: 'Administration',
      confidence: 'Medium',
    },
  ];

  for (const rule of rules) {
    for (const kw of rule.keywords) {
      if (lower.includes(kw)) {
        return { category: rule.category, matchedKeyword: kw, confidence: rule.confidence };
      }
    }
  }

  return { category: null, matchedKeyword: null, confidence: 'Low' };
}

/**
 * Creates timestamps relative to now (e.g. 48 hours ago)
 */
function createRelativeDate(hoursAgo: number): string {
  const date = new Date(Date.now() - hoursAgo * 60 * 60 * 1000);
  return date.toISOString();
}

/**
 * Official 4 sample complaints specified in requirements:
 * C01: Wi-Fi, 48 hours ago, Raised
 * C02: Hostel, 8 hours ago, In Progress
 * C03: Classroom, 72 hours ago, Raised
 * C04: Laboratory, 24 hours ago, Resolved
 * Plus 3 realistic SATI Vidisha sample issues for a comprehensive demonstration
 */
export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'C01',
    title: 'Wi-Fi Connection Dropping Continuously in CS Wing',
    category: 'Internet & Wi-Fi',
    description: 'The Wi-Fi access point in Academic Block A (2nd floor CS lab corridor) keeps dropping every 5 minutes. Students cannot access course repositories or submission portals.',
    location: 'Academic Block A (Computer Science & IT)',
    blockDetail: '2nd Floor Corridor, near Room 204',
    urgency: 'High',
    status: 'Raised',
    createdAt: createRelativeDate(48),
    submittedBy: {
      name: 'Aditya Sharma',
      email: 'aditya.cs23@satiengg.in',
      department: 'Computer Science & Engineering',
      rollNumber: '0108CS221004',
      isAnonymous: false,
    },
    assignedDepartment: 'Network & IT Infrastructure Cell',
    priorityScore: 4, // 2 (Wi-Fi) + floor(48/24 = 2) = 4
    pendingHours: 48,
    categoryWeight: 2,
    imageUrl: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80',
    timeline: [
      {
        id: 't-c01-1',
        status: 'Raised',
        timestamp: createRelativeDate(48),
        actor: 'Aditya Sharma (Student)',
        note: 'Complaint registered via CampusAxis Student Portal.',
      },
    ],
  },
  {
    id: 'C02',
    title: 'Bathroom Water Supply Low Pressure in Aryabhatta Hostel',
    category: 'Hostel Issues',
    description: 'Water pressure in 1st floor bathroom wing B is insufficient in the mornings. Overhead tank booster pump needs inspection.',
    location: "Boy's Hostel (Aryabhatta Bhawan)",
    blockDetail: 'Wing B, 1st Floor Washrooms',
    urgency: 'Medium',
    status: 'In Progress',
    createdAt: createRelativeDate(8),
    submittedBy: {
      name: 'Rohan Verma',
      email: 'rohan.me23@satiengg.in',
      department: 'Mechanical Engineering',
      rollNumber: '0108ME221045',
      isAnonymous: false,
    },
    assignedDepartment: 'Hostel Administration & Mess Committee',
    priorityScore: 2, // 2 (Hostel) + floor(8/24 = 0) = 2
    pendingHours: 8,
    categoryWeight: 2,
    adminRemarks: 'Maintenance team sent to inspect pump pressure and valve line B.',
    timeline: [
      {
        id: 't-c02-1',
        status: 'Raised',
        timestamp: createRelativeDate(8),
        actor: 'Rohan Verma (Student)',
        note: 'Complaint registered with photo evidence.',
      },
      {
        id: 't-c02-2',
        status: 'In Progress',
        timestamp: createRelativeDate(4),
        actor: 'Admin (Hostel Warden Office)',
        note: 'Assigned to plumbing contractor. Inspection scheduled.',
      },
    ],
  },
  {
    id: 'C03',
    title: 'Ceiling Fan Making Hazardous Noise in Lecture Hall LH-102',
    category: 'Classroom Issues',
    description: 'Center ceiling fan wobbles violently and produces loud grinding noise during lectures, making hearing the professor difficult and posing a safety risk.',
    location: 'Academic Block B (Civil & Mechanical)',
    blockDetail: 'Lecture Hall LH-102, Ground Floor',
    urgency: 'High',
    status: 'Raised',
    createdAt: createRelativeDate(72),
    submittedBy: {
      name: 'Pooja Tiwari',
      email: 'pooja.ce23@satiengg.in',
      department: 'Civil Engineering',
      rollNumber: '0108CE221032',
      isAnonymous: false,
    },
    assignedDepartment: 'Electrical & Power Maintenance',
    priorityScore: 4, // 1 (Classroom) + floor(72/24 = 3) = 4 (Tied with C01, but older - 72h vs 48h!)
    pendingHours: 72,
    categoryWeight: 1,
    isEscalated: true,
    escalatedAt: createRelativeDate(12),
    escalationReason: 'Pending past 48 hours threshold without assignment.',
    timeline: [
      {
        id: 't-c03-1',
        status: 'Raised',
        timestamp: createRelativeDate(72),
        actor: 'Pooja Tiwari (Student)',
        note: 'Issue reported for lecture hall LH-102.',
      },
      {
        id: 't-c03-2',
        status: 'Raised',
        timestamp: createRelativeDate(12),
        actor: 'System Escalation Engine',
        note: 'Flagged as escalated due to 72h inactivity.',
      },
    ],
  },
  {
    id: 'C04',
    title: 'Microcontroller Trainer Kits Replaced in Embedded Lab',
    category: 'Laboratory Issues',
    description: '3 8051 microcontroller boards had blown 5V regulators and faulty USB-UART bridges in Lab 3.',
    location: 'Advanced Computing Laboratory',
    blockDetail: 'Lab Bench 4, Advanced Computing Section',
    urgency: 'Medium',
    status: 'Resolved',
    createdAt: createRelativeDate(24),
    resolvedAt: createRelativeDate(4),
    submittedBy: {
      name: 'Nikhil Patel',
      email: 'nikhil.ee23@satiengg.in',
      department: 'Electrical Engineering',
      rollNumber: '0108EE221019',
      isAnonymous: false,
    },
    assignedDepartment: 'Lab Technical Support & Instrumentation',
    priorityScore: 4, // 3 (Laboratory) + floor(24/24 = 1) = 4
    pendingHours: 24,
    categoryWeight: 3,
    adminRemarks: 'Replaced faulty voltage regulator ICs and tested COM communication on all 3 kits.',
    timeline: [
      {
        id: 't-c04-1',
        status: 'Raised',
        timestamp: createRelativeDate(24),
        actor: 'Nikhil Patel (Student)',
        note: 'Reported faulty trainer kits.',
      },
      {
        id: 't-c04-2',
        status: 'In Progress',
        timestamp: createRelativeDate(16),
        actor: 'Lab In-Charge',
        note: 'Kits handed over to instrumentation technician.',
      },
      {
        id: 't-c04-3',
        status: 'Resolved',
        timestamp: createRelativeDate(4),
        actor: 'Lab Technician',
        note: 'Repaired and verified working with sample LED blink code.',
      },
    ],
    feedback: {
      rating: 5,
      comment: 'Promptly repaired before our lab practical exam. Thank you!',
      createdAt: createRelativeDate(2),
    },
  },
  {
    id: 'CC-2026-0005',
    title: 'Flickering High-Mast Light Near Main Gate & Girls Hostel Turn',
    category: 'Security & Safety',
    description: 'The pathway between the main gate and Kalpana Chawla Bhawan is pitch dark after 7:30 PM because the main sodium vapor post lamp is dead.',
    location: 'Main Gate & Proctorial Security',
    blockDetail: 'Curved pathway junction near Garden',
    urgency: 'Critical',
    status: 'In Progress',
    createdAt: createRelativeDate(30),
    submittedBy: {
      name: 'Parul Vishwakarma',
      email: 'parul29bc050@satiengg.in',
      department: 'Computer Science & Engineering',
      rollNumber: '0108CS221050',
      isAnonymous: false,
    },
    assignedDepartment: 'Proctorial Board & Campus Security',
    priorityScore: 5, // 4 (Security) + floor(30/24 = 1) = 5
    pendingHours: 30,
    categoryWeight: 4,
    adminRemarks: 'Security patrol requested temporary floodlights while electrical department procures replacement LED bulb.',
    timeline: [
      {
        id: 't-0005-1',
        status: 'Raised',
        timestamp: createRelativeDate(30),
        actor: 'Parul Vishwakarma (Student)',
        note: 'Urgent security concern reported.',
      },
      {
        id: 't-0005-2',
        status: 'In Progress',
        timestamp: createRelativeDate(18),
        actor: 'Chief Proctor Office',
        note: 'Priority dispatch issued to Electrical Division.',
      },
    ],
  },
  {
    id: 'CC-2026-0006',
    title: 'Special Need for Braille Signage and Wheelchair Ramp Repair',
    category: 'Other / Describe Your Own Problem',
    customCategoryTitle: 'Accessibility & Barrier-Free Campus Facilities',
    description: 'The entrance ramp near the central library has broken edge tiles making wheelchair access dangerous. Also tactile path indicators need repainting.',
    location: 'Central Library & Reading Hall',
    blockDetail: 'North Entrance Ramp',
    urgency: 'Medium',
    status: 'Raised',
    createdAt: createRelativeDate(14),
    submittedBy: {
      name: 'Anonymous Student',
      email: 'student@satiengg.in',
      department: 'Civil Engineering',
      rollNumber: 'HIDDEN',
      isAnonymous: true,
    },
    assignedDepartment: 'Estate & Civil Works Division',
    priorityScore: 2, // 2 (Other) + floor(14/24 = 0) = 2
    pendingHours: 14,
    categoryWeight: 2,
    timeline: [
      {
        id: 't-0006-1',
        status: 'Raised',
        timestamp: createRelativeDate(14),
        actor: 'Anonymous Student',
        note: 'Custom complaint submitted regarding campus accessibility.',
      },
    ],
  },
];
