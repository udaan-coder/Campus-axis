export type UserRole = 'student' | 'admin';

export interface StudentUser {
  id: string;
  fullName: string;
  email: string;
  studentId: string; // Enrollment Number
  department: string;
  yearSemester: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

export type AdminRoleType = 'Super Admin' | 'Department Officer' | 'Dean / Committee';

export interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  username: string;
  department: string;
  adminRole: AdminRoleType;
  passwordHash: string;
  salt: string;
  createdAt: string;
  createdBy?: string;
  isRoot?: boolean;
}

export interface CurrentUserSession {
  id: string;
  role: UserRole;
  fullName: string;
  email: string;
  studentId?: string;
  department?: string;
  yearSemester?: string;
  adminRole?: AdminRoleType;
  token: string;
  loginAt: string;
  rememberMe: boolean;
}
