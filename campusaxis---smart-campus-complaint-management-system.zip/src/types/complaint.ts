export type ComplaintCategory =
  | 'Internet & Wi-Fi'
  | 'Classroom Issues'
  | 'Hostel Issues'
  | 'Laboratory Issues'
  | 'Library Issues'
  | 'Canteen & Food'
  | 'Cleanliness & Sanitation'
  | 'Water & Electricity'
  | 'Campus Infrastructure'
  | 'Administration'
  | 'Security & Safety'
  | 'Sports & Recreation'
  | 'Transport & Parking'
  | 'Medical & Health Facilities'
  | 'Other / Describe Your Own Problem';

export type ComplaintStatus = 'Raised' | 'In Progress' | 'Resolved';

export type UrgencyLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type AffectedScale =
  | 'Individual (1 student)'
  | 'Room / Bench (2–10 students)'
  | 'Class / Wing (10–50 students)'
  | 'Entire Block / Campus (>50 students)';

export interface TimelineEvent {
  id: string;
  status: ComplaintStatus;
  timestamp: string;
  actor: string;
  note: string;
}

export interface ComplaintFeedback {
  rating: number; // 1 to 5
  comment: string;
  createdAt: string;
}

export interface PriorityBreakdown {
  categoryWeight: number;
  urgencyScore: number;
  ageBonus: number;
  affectedScore: number;
  safetyScore: number;
  totalScore: number;
  priorityLabel: UrgencyLevel;
  reason: string;
}

export interface Complaint {
  id: string;
  title: string;
  category: ComplaintCategory;
  customCategoryTitle?: string; // If 'Other / Describe Your Own Problem'
  description: string;
  location: string;
  blockDetail?: string;
  urgency: UrgencyLevel;
  affectedScale?: AffectedScale;
  safetyHazard?: boolean;
  status: ComplaintStatus;
  createdAt: string;
  resolvedAt?: string;
  submittedBy: {
    name: string;
    email: string;
    department: string;
    rollNumber: string;
    isAnonymous: boolean;
  };
  assignedDepartment?: string;
  priorityScore: number;
  priorityLabel?: UrgencyLevel;
  priorityBreakdown?: PriorityBreakdown;
  pendingHours: number;
  categoryWeight: number;
  imageUrl?: string;
  isEscalated?: boolean;
  escalatedAt?: string;
  escalationReason?: string;
  adminRemarks?: string;
  reopenRequested?: boolean;
  reopenReason?: string;
  // Manual Priority Override
  isPriorityOverridden?: boolean;
  overriddenUrgency?: UrgencyLevel;
  overriddenScore?: number;
  priorityOverrideReason?: string;
  priorityOverrideBy?: string;
  priorityOverrideAt?: string;
  timeline: TimelineEvent[];
  feedback?: ComplaintFeedback;
}

export interface NotificationItem {
  id: string;
  complaintId: string;
  title: string;
  message: string;
  type: 'submitted' | 'status_change' | 'escalated' | 'resolved' | 'reopened' | 'priority_override';
  timestamp: string;
  read: boolean;
}
