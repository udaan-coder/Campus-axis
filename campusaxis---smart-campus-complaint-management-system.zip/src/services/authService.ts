import { StudentUser, AdminUser, CurrentUserSession, AdminRoleType } from '../types/auth';

const STORAGE_STUDENTS_KEY = 'campusaxis_students_v1';
const STORAGE_ADMINS_KEY = 'campusaxis_admins_v1';
const STORAGE_SESSION_KEY = 'campusaxis_session_v1';

// Authorized institutional master key for first-time root administrator onboarding
export const SATI_ROOT_ADMIN_SETUP_KEY = 'SATI-ADMIN-2026';

/**
 * Generate a cryptographically secure random salt
 */
function generateSalt(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Hash password securely using SHA-256 via the Web Crypto API
 */
export async function hashPassword(password: string, salt: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(`${salt}:${password}:sati_campusaxis_secure_salt`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Load registered students from persistent LocalStorage
 */
export function getRegisteredStudents(): StudentUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_STUDENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveRegisteredStudents(students: StudentUser[]): void {
  try {
    localStorage.setItem(STORAGE_STUDENTS_KEY, JSON.stringify(students));
  } catch (err) {
    console.error('Failed to save student user records', err);
  }
}

/**
 * Load authorized admins from persistent LocalStorage
 */
export function getAuthorizedAdmins(): AdminUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_ADMINS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveAuthorizedAdmins(admins: AdminUser[]): void {
  try {
    localStorage.setItem(STORAGE_ADMINS_KEY, JSON.stringify(admins));
  } catch (err) {
    console.error('Failed to save admin user records', err);
  }
}

/**
 * Check if at least one authorized administrator has been initialized
 */
export function hasAnyAdmin(): boolean {
  return getAuthorizedAdmins().length > 0;
}

/**
 * Get active session
 */
export function getCurrentSession(): CurrentUserSession | null {
  try {
    // Check localStorage first
    const rawLocal = localStorage.getItem(STORAGE_SESSION_KEY);
    if (rawLocal) return JSON.parse(rawLocal);
    // Fall back to sessionStorage
    const rawSession = sessionStorage.getItem(STORAGE_SESSION_KEY);
    if (rawSession) return JSON.parse(rawSession);
    return null;
  } catch {
    return null;
  }
}

/**
 * Set active session
 */
export function setSession(session: CurrentUserSession, rememberMe: boolean): void {
  try {
    const payload = JSON.stringify(session);
    if (rememberMe) {
      localStorage.setItem(STORAGE_SESSION_KEY, payload);
    } else {
      sessionStorage.setItem(STORAGE_SESSION_KEY, payload);
    }
  } catch (err) {
    console.error('Failed to set session', err);
  }
}

/**
 * Clear session (logout)
 */
export function logout(): void {
  try {
    localStorage.removeItem(STORAGE_SESSION_KEY);
    sessionStorage.removeItem(STORAGE_SESSION_KEY);
  } catch {
    // ignore
  }
}

/**
 * Register a new student
 */
export async function registerStudent(data: {
  fullName: string;
  email: string;
  studentId: string;
  department: string;
  yearSemester: string;
  password: string;
}): Promise<{ success: boolean; error?: string; user?: StudentUser }> {
  const students = getRegisteredStudents();

  // Validate uniqueness
  const cleanEmail = data.email.trim().toLowerCase();
  const cleanStudentId = data.studentId.trim().toUpperCase();

  if (students.some((s) => s.email.toLowerCase() === cleanEmail)) {
    return { success: false, error: 'A student account is already registered with this college email address.' };
  }
  if (students.some((s) => s.studentId.toUpperCase() === cleanStudentId)) {
    return { success: false, error: 'A student account is already registered with this Student ID / Enrollment Number.' };
  }

  const salt = generateSalt();
  const passwordHash = await hashPassword(data.password, salt);

  const newStudent: StudentUser = {
    id: `STU-${Date.now()}`,
    fullName: data.fullName.trim(),
    email: cleanEmail,
    studentId: cleanStudentId,
    department: data.department.trim(),
    yearSemester: data.yearSemester.trim(),
    passwordHash,
    salt,
    createdAt: new Date().toISOString(),
  };

  students.push(newStudent);
  saveRegisteredStudents(students);

  return { success: true, user: newStudent };
}

/**
 * Authenticate Student
 */
export async function loginStudent(
  identifier: string, // Email or Student ID
  password: string,
  rememberMe: boolean = true
): Promise<{ success: boolean; error?: string; session?: CurrentUserSession }> {
  const students = getRegisteredStudents();
  const cleanIdentifier = identifier.trim().toLowerCase();

  const student = students.find(
    (s) => s.email.toLowerCase() === cleanIdentifier || s.studentId.toLowerCase() === cleanIdentifier
  );

  if (!student) {
    return { success: false, error: 'No student account found with this email or Student ID.' };
  }

  const computedHash = await hashPassword(password, student.salt);
  if (computedHash !== student.passwordHash) {
    return { success: false, error: 'Invalid password. Please check your credentials and try again.' };
  }

  const session: CurrentUserSession = {
    id: student.id,
    role: 'student',
    fullName: student.fullName,
    email: student.email,
    studentId: student.studentId,
    department: student.department,
    yearSemester: student.yearSemester,
    token: `tok_stu_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    loginAt: new Date().toISOString(),
    rememberMe,
  };

  setSession(session, rememberMe);
  return { success: true, session };
}

/**
 * Initialize the First Authorized Root Administrator
 */
export async function initializeFirstAdmin(data: {
  fullName: string;
  email: string;
  username: string;
  department: string;
  password: string;
  authorizationKey: string;
}): Promise<{ success: boolean; error?: string; session?: CurrentUserSession }> {
  const admins = getAuthorizedAdmins();
  if (admins.length > 0) {
    return {
      success: false,
      error: 'An authorized administrator already exists. Please login or ask the existing admin to invite you.',
    };
  }

  if (data.authorizationKey.trim() !== SATI_ROOT_ADMIN_SETUP_KEY) {
    return {
      success: false,
      error: `Invalid Institutional Authorization Key. Enter the official SATI master setup key (${SATI_ROOT_ADMIN_SETUP_KEY}).`,
    };
  }

  const salt = generateSalt();
  const passwordHash = await hashPassword(data.password, salt);

  const rootAdmin: AdminUser = {
    id: `ADM-ROOT-${Date.now()}`,
    fullName: data.fullName.trim(),
    email: data.email.trim().toLowerCase(),
    username: data.username.trim().toLowerCase(),
    department: data.department.trim(),
    adminRole: 'Super Admin',
    passwordHash,
    salt,
    createdAt: new Date().toISOString(),
    isRoot: true,
  };

  admins.push(rootAdmin);
  saveAuthorizedAdmins(admins);

  const session: CurrentUserSession = {
    id: rootAdmin.id,
    role: 'admin',
    fullName: rootAdmin.fullName,
    email: rootAdmin.email,
    department: rootAdmin.department,
    adminRole: rootAdmin.adminRole,
    token: `tok_adm_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    loginAt: new Date().toISOString(),
    rememberMe: true,
  };

  setSession(session, true);
  return { success: true, session };
}

/**
 * Authenticate Administrator
 */
export async function loginAdmin(
  identifier: string, // Email or Username
  password: string,
  rememberMe: boolean = true
): Promise<{ success: boolean; error?: string; session?: CurrentUserSession }> {
  const admins = getAuthorizedAdmins();
  const clean = identifier.trim().toLowerCase();

  const admin = admins.find(
    (a) => a.email.toLowerCase() === clean || a.username.toLowerCase() === clean
  );

  if (!admin) {
    return {
      success: false,
      error: 'No administrator account found with this email or username. Note: Admin accounts can only be created by authorized campus authorities.',
    };
  }

  const computedHash = await hashPassword(password, admin.salt);
  if (computedHash !== admin.passwordHash) {
    return { success: false, error: 'Incorrect administrator password.' };
  }

  const session: CurrentUserSession = {
    id: admin.id,
    role: 'admin',
    fullName: admin.fullName,
    email: admin.email,
    department: admin.department,
    adminRole: admin.adminRole,
    token: `tok_adm_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    loginAt: new Date().toISOString(),
    rememberMe,
  };

  setSession(session, rememberMe);
  return { success: true, session };
}

/**
 * Create a new Admin by an existing Authorized Administrator
 */
export async function createAdminByAuthorizedAdmin(
  currentAdminSession: CurrentUserSession,
  newAdmin: {
    fullName: string;
    email: string;
    username: string;
    department: string;
    adminRole: AdminRoleType;
    password: string;
  }
): Promise<{ success: boolean; error?: string; admin?: AdminUser }> {
  if (currentAdminSession.role !== 'admin') {
    return { success: false, error: 'Unauthorized: Only logged-in administrators can create admin accounts.' };
  }

  const admins = getAuthorizedAdmins();
  const cleanEmail = newAdmin.email.trim().toLowerCase();
  const cleanUsername = newAdmin.username.trim().toLowerCase();

  if (admins.some((a) => a.email.toLowerCase() === cleanEmail)) {
    return { success: false, error: 'An admin account is already registered with this email address.' };
  }
  if (admins.some((a) => a.username.toLowerCase() === cleanUsername)) {
    return { success: false, error: 'An admin account is already registered with this username.' };
  }

  const salt = generateSalt();
  const passwordHash = await hashPassword(newAdmin.password, salt);

  const createdAdmin: AdminUser = {
    id: `ADM-${Date.now()}`,
    fullName: newAdmin.fullName.trim(),
    email: cleanEmail,
    username: cleanUsername,
    department: newAdmin.department.trim(),
    adminRole: newAdmin.adminRole,
    passwordHash,
    salt,
    createdAt: new Date().toISOString(),
    createdBy: currentAdminSession.fullName,
  };

  admins.push(createdAdmin);
  saveAuthorizedAdmins(admins);

  return { success: true, admin: createdAdmin };
}

/**
 * Reset student password
 */
export async function resetStudentPassword(
  identifier: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const students = getRegisteredStudents();
  const clean = identifier.trim().toLowerCase();

  const idx = students.findIndex(
    (s) => s.email.toLowerCase() === clean || s.studentId.toLowerCase() === clean
  );

  if (idx === -1) {
    return { success: false, error: 'No student account matches this email or Student ID.' };
  }

  const salt = generateSalt();
  const passwordHash = await hashPassword(newPassword, salt);
  students[idx].salt = salt;
  students[idx].passwordHash = passwordHash;
  saveRegisteredStudents(students);

  return { success: true };
}

/**
 * Reset admin password using master verification key
 */
export async function resetAdminPassword(
  identifier: string,
  newPassword: string,
  authKey: string
): Promise<{ success: boolean; error?: string }> {
  if (authKey.trim() !== SATI_ROOT_ADMIN_SETUP_KEY) {
    return { success: false, error: 'Invalid Institutional Authorization Key for admin password reset.' };
  }

  const admins = getAuthorizedAdmins();
  const clean = identifier.trim().toLowerCase();
  const idx = admins.findIndex(
    (a) => a.email.toLowerCase() === clean || a.username.toLowerCase() === clean
  );

  if (idx === -1) {
    return { success: false, error: 'No administrator account matches this identifier.' };
  }

  const salt = generateSalt();
  const passwordHash = await hashPassword(newPassword, salt);
  admins[idx].salt = salt;
  admins[idx].passwordHash = passwordHash;
  saveAuthorizedAdmins(admins);

  return { success: true };
}
