import { Complaint, NotificationItem } from '../types/complaint';
import { INITIAL_COMPLAINTS, calculatePriorityScore } from '../constants/complaintData';

const COMPLAINTS_KEY = 'campusaxis_complaints_v2';
const NOTIFICATIONS_KEY = 'campusaxis_notifications_v2';

/**
 * Recalculate priority scores and pending hours for a list of complaints
 */
export function recalculateAllScores(complaints: Complaint[]): Complaint[] {
  return complaints.map((complaint) => {
    const calc = calculatePriorityScore(
      complaint.category,
      complaint.createdAt,
      complaint.urgency,
      complaint.affectedScale,
      complaint.safetyHazard,
      complaint.isPriorityOverridden,
      complaint.overriddenUrgency,
      complaint.overriddenScore
    );
    return {
      ...complaint,
      priorityScore: calc.score,
      priorityLabel: calc.priorityLabel,
      pendingHours: calc.pendingHours,
      categoryWeight: calc.categoryWeight,
      priorityBreakdown: {
        categoryWeight: calc.categoryWeight,
        urgencyScore: calc.urgencyScore,
        ageBonus: calc.ageDays,
        affectedScore: calc.affectedScore,
        safetyScore: calc.safetyScore,
        totalScore: calc.score,
        priorityLabel: calc.priorityLabel,
        reason: calc.reason,
      },
    };
  });
}

/**
 * Load complaints from LocalStorage.
 * Initial default state is completely clean and empty (no dummy or sample records).
 */
export function loadComplaints(): Complaint[] {
  try {
    const data = localStorage.getItem(COMPLAINTS_KEY);
    if (data !== null) {
      const parsed: Complaint[] = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return recalculateAllScores(parsed);
      }
    }
  } catch (err) {
    console.warn('Could not read complaints from localStorage', err);
  }

  // Completely clean initial empty state
  saveComplaints([]);
  return [];
}

/**
 * Save complaints to LocalStorage
 */
export function saveComplaints(complaints: Complaint[]): void {
  try {
    localStorage.setItem(COMPLAINTS_KEY, JSON.stringify(complaints));
  } catch (err) {
    console.error('Failed to save complaints to localStorage', err);
  }
}

/**
 * Clear all complaints completely (resets to 0 records)
 */
export function clearAllComplaints(): Complaint[] {
  saveComplaints([]);
  return [];
}

/**
 * Optional: On-demand load official benchmark sample complaints (C01, C02, C03, C04)
 * for demonstration purposes only if triggered by admin.
 */
export function loadOfficialBenchmarkSamples(): Complaint[] {
  const seeded = recalculateAllScores(INITIAL_COMPLAINTS);
  saveComplaints(seeded);
  return seeded;
}

/**
 * Get all unresolved complaints sorted by:
 * 1. Priority score DESC
 * 2. Older complaint first (createdAt ASC)
 * Resolved complaints are strictly excluded.
 */
export function getAllPriorityQueue(complaints: Complaint[]): Complaint[] {
  const unresolved = complaints.filter((c) => c.status !== 'Resolved');
  return unresolved.sort((a, b) => {
    if (b.priorityScore !== a.priorityScore) {
      return b.priorityScore - a.priorityScore;
    }
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });
}

/**
 * Get top N unresolved complaints
 */
export function getTopPriorityQueue(complaints: Complaint[], limit = 3): Complaint[] {
  return getAllPriorityQueue(complaints).slice(0, limit);
}

/**
 * Load notifications.
 * Initial default state is completely clean and empty.
 */
export function loadNotifications(): NotificationItem[] {
  try {
    const data = localStorage.getItem(NOTIFICATIONS_KEY);
    if (data !== null) {
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load notifications', err);
  }

  // Completely clean initial empty state
  saveNotifications([]);
  return [];
}

export function saveNotifications(notifications: NotificationItem[]): void {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch (err) {
    console.error('Failed to save notifications', err);
  }
}

/**
 * Export complaints data to CSV
 */
export function exportComplaintsToCSV(complaints: Complaint[]): void {
  const headers = [
    'Complaint ID',
    'Title',
    'Category',
    'Location',
    'Block Detail',
    'Status',
    'Urgency',
    'Priority Score',
    'Pending Hours',
    'Created At',
    'Resolved At',
    'Assigned Department',
    'Is Anonymous',
    'Submitted By',
    'Rating',
  ];

  const rows = complaints.map((c) => [
    `"${c.id}"`,
    `"${c.title.replace(/"/g, '""')}"`,
    `"${c.category === 'Other / Describe Your Own Problem' && c.customCategoryTitle ? `Custom: ${c.customCategoryTitle}` : c.category}"`,
    `"${c.location.replace(/"/g, '""')}"`,
    `"${(c.blockDetail || '').replace(/"/g, '""')}"`,
    `"${c.status}"`,
    `"${c.urgency}"`,
    c.priorityScore,
    c.pendingHours,
    `"${c.createdAt}"`,
    `"${c.resolvedAt || ''}"`,
    `"${(c.assignedDepartment || 'Unassigned').replace(/"/g, '""')}"`,
    c.submittedBy.isAnonymous ? 'Yes' : 'No',
    `"${c.submittedBy.isAnonymous ? 'Hidden' : c.submittedBy.name}"`,
    c.feedback?.rating ?? 'N/A',
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `CampusAxis_SATI_Complaints_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
