import React, { useState, useEffect } from 'react';
import { Complaint, NotificationItem } from './types/complaint';
import { CurrentUserSession } from './types/auth';
import {
  loadComplaints,
  saveComplaints,
  clearAllComplaints,
  loadOfficialBenchmarkSamples,
  loadNotifications,
  saveNotifications,
  recalculateAllScores,
} from './services/storage';
import { getCurrentSession, logout as authLogout } from './services/authService';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { StudentPortal } from './components/StudentPortal';
import { AdminPortal } from './components/AdminPortal';
import { AdminLoginView } from './components/AdminLoginView';
import { StudentAuthModal } from './components/StudentAuthModal';
import { AdminManagementModal } from './components/AdminManagementModal';
import { AnalyticsView } from './components/AnalyticsView';
import { TrackModal } from './components/TrackModal';
import { ComplaintDetailsModal } from './components/ComplaintDetailsModal';

function CampusAxisMain() {
  const { t, language } = useLanguage();

  // Clear any legacy test data from previous builds if present
  useEffect(() => {
    try {
      if (localStorage.getItem('campusaxis_complaints_v1')) {
        localStorage.removeItem('campusaxis_complaints_v1');
      }
      if (localStorage.getItem('campusaxis_notifications_v1')) {
        localStorage.removeItem('campusaxis_notifications_v1');
      }
    } catch {
      // safe fallback
    }
  }, []);

  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('campusaxis_dark_mode');
      if (saved !== null) return saved === 'true';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  // Apply dark mode class to <html>
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    try {
      localStorage.setItem('campusaxis_dark_mode', String(isDarkMode));
    } catch {
      // safe fallback
    }
  }, [isDarkMode]);

  // Main View Navigation State
  const [currentView, setCurrentView] = useState<'landing' | 'student' | 'admin' | 'analytics'>('landing');
  const [studentInitialTab, setStudentInitialTab] = useState<'overview' | 'submit' | 'my-complaints' | 'track' | 'notifications' | 'profile'>('overview');

  // Authentication State
  const [currentUserSession, setCurrentUserSession] = useState<CurrentUserSession | null>(() => getCurrentSession());
  const [isStudentAuthOpen, setIsStudentAuthOpen] = useState(false);
  const [studentAuthMode, setStudentAuthMode] = useState<'login' | 'register'>('login');
  const [isAdminManagementOpen, setIsAdminManagementOpen] = useState(false);

  // Complaints State
  const [complaints, setComplaints] = useState<Complaint[]>(() => loadComplaints());

  // Notifications State
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => loadNotifications());

  // Modal States
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [trackModalInitialId, setTrackModalInitialId] = useState('');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [isDetailsAdminMode, setIsDetailsAdminMode] = useState(false);

  // Recalculate pending hours and priority scores periodically (every 60s)
  useEffect(() => {
    const interval = setInterval(() => {
      setComplaints((prev) => {
        const recalculated = recalculateAllScores(prev);
        saveComplaints(recalculated);
        return recalculated;
      });
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  // Helper to add in-app notification
  const addNotification = (
    complaintId: string,
    title: string,
    message: string,
    type: NotificationItem['type']
  ) => {
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      complaintId,
      title,
      message,
      type,
      timestamp: new Date().toISOString(),
      read: false,
    };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    saveNotifications(updated);
  };

  // Add new complaint (from Student Portal)
  const handleAddComplaint = (newComplaint: Complaint) => {
    const updated = [newComplaint, ...complaints];
    setComplaints(updated);
    saveComplaints(updated);

    addNotification(
      newComplaint.id,
      language === 'hi' ? 'नई शिकायत दर्ज की गई' : 'New Complaint Registered',
      `${newComplaint.title} (${newComplaint.category}) - ${t.priorityScore}: ${newComplaint.priorityScore}`,
      'submitted'
    );
  };

  // Update existing complaint (from Admin Portal or Details Modal)
  const handleUpdateComplaint = (updatedComplaint: Complaint) => {
    const prevComplaint = complaints.find((c) => c.id === updatedComplaint.id);

    const updatedList = complaints.map((c) =>
      c.id === updatedComplaint.id ? updatedComplaint : c
    );
    setComplaints(updatedList);
    saveComplaints(updatedList);

    // If modal is open for this complaint, update it too
    if (selectedComplaint && selectedComplaint.id === updatedComplaint.id) {
      setSelectedComplaint(updatedComplaint);
    }

    // Trigger notification if status changed
    if (prevComplaint && prevComplaint.status !== updatedComplaint.status) {
      if (updatedComplaint.status === 'Resolved') {
        addNotification(
          updatedComplaint.id,
          language === 'hi' ? 'शिकायत का निवारण पूर्ण' : 'Complaint Resolved',
          language === 'hi'
            ? `शिकायत #${updatedComplaint.id} को हल के रूप में चिह्नित किया गया है।`
            : `Issue #${updatedComplaint.id} has been marked as Resolved.`,
          'resolved'
        );
      } else {
        addNotification(
          updatedComplaint.id,
          `${language === 'hi' ? 'स्थिति' : 'Status'}: ${updatedComplaint.status}`,
          language === 'hi'
            ? `शिकायत #${updatedComplaint.id} की स्थिति "${updatedComplaint.status}" पर अपडेट हुई।`
            : `Issue #${updatedComplaint.id} updated to ${updatedComplaint.status}.`,
          'status_change'
        );
      }
    }

    // If escalated
    if (!prevComplaint?.isEscalated && updatedComplaint.isEscalated) {
      addNotification(
        updatedComplaint.id,
        language === 'hi' ? 'प्राथमिकता पर अग्रसारित' : 'Issue Escalated',
        language === 'hi'
          ? `शिकायत #${updatedComplaint.id} को उच्च प्राथमिकता समिति को अग्रसारित किया गया है।`
          : `Complaint #${updatedComplaint.id} has been flagged for priority escalation.`,
        'escalated'
      );
    }
  };

  // Clear All Complaint Records (Reset to 0)
  const handleClearAllData = () => {
    const cleared = clearAllComplaints();
    setComplaints(cleared);
    setNotifications([]);
    saveNotifications([]);
  };

  // Load official benchmark samples on demand
  const handleLoadBenchmarkSamples = () => {
    const loaded = loadOfficialBenchmarkSamples();
    setComplaints(loaded);
    addNotification(
      'SYSTEM',
      language === 'hi' ? 'मानक परीक्षण नमूने लोड किए गए' : 'Benchmark Samples Loaded',
      language === 'hi'
        ? 'परीक्षण हेतु आधिकारिक शिकायतें C01, C02, C03, C04 लोड की गईं।'
        : 'Official complaints C01, C02, C03, and C04 loaded for testing.',
      'status_change'
    );
  };

  // Quick Tracking Trigger
  const handleOpenTrackModalWithId = (id: string) => {
    setTrackModalInitialId(id);
    setIsTrackModalOpen(true);
  };

  // Open Details Modal
  const handleSelectComplaintForInspection = (complaint: Complaint, asAdmin = false) => {
    setSelectedComplaint(complaint);
    setIsDetailsAdminMode(asAdmin || (currentView === 'admin' && currentUserSession?.role === 'admin'));
  };

  // Notification actions
  const handleMarkNotifRead = (id: string) => {
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updated);
    saveNotifications(updated);
  };

  const handleClearAllNotifs = () => {
    setNotifications([]);
    saveNotifications([]);
  };

  // Auth Handlers
  const handleOpenStudentAuth = (mode: 'login' | 'register' = 'login') => {
    setStudentAuthMode(mode);
    setIsStudentAuthOpen(true);
  };

  const handleOpenAdminLogin = () => {
    setCurrentView('admin');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = () => {
    authLogout();
    setCurrentUserSession(null);
    if (currentView === 'admin') {
      setCurrentView('landing');
    }
  };

  const handleLoginSuccess = (session: CurrentUserSession) => {
    setCurrentUserSession(session);
    if (session.role === 'admin') {
      setCurrentView('admin');
    } else {
      setCurrentView('student');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Global Navigation Bar */}
      <Navbar
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenTrackModal={() => handleOpenTrackModalWithId('')}
        onOpenSubmitComplaint={() => {
          setCurrentView('student');
          setStudentInitialTab('submit');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        notifications={notifications}
        onMarkNotificationAsRead={handleMarkNotifRead}
        onClearAllNotifications={handleClearAllNotifs}
        currentUserSession={currentUserSession}
        onOpenStudentAuth={handleOpenStudentAuth}
        onOpenAdminLogin={handleOpenAdminLogin}
        onLogout={handleLogout}
      />

      {/* Main View Port */}
      <main className="flex-1">
        {/* 1. LANDING PAGE VIEW */}
        {currentView === 'landing' && (
          <LandingPage
            complaints={complaints}
            onNavigateToStudent={() => {
              setCurrentView('student');
              setStudentInitialTab('submit');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToAdmin={() => {
              setCurrentView('admin');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToAnalytics={() => {
              setCurrentView('analytics');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenTrackModalWithId={handleOpenTrackModalWithId}
            onOpenStudentAuth={handleOpenStudentAuth}
            onOpenAdminLogin={handleOpenAdminLogin}
          />
        )}

        {/* 2. STUDENT PORTAL VIEW */}
        {currentView === 'student' && (
          <StudentPortal
            complaints={complaints}
            onAddComplaint={handleAddComplaint}
            onOpenTrackModalWithId={handleOpenTrackModalWithId}
            onSelectComplaint={(c) => handleSelectComplaintForInspection(c, false)}
            initialTab={studentInitialTab}
            currentUserSession={currentUserSession}
            onOpenAuthModal={() => handleOpenStudentAuth('login')}
          />
        )}

        {/* 3. ADMIN PORTAL VIEW WITH STRICT ROLE PROTECTION */}
        {currentView === 'admin' && (
          currentUserSession?.role === 'admin' ? (
            <AdminPortal
              complaints={complaints}
              onUpdateComplaint={handleUpdateComplaint}
              onClearAllData={handleClearAllData}
              onLoadBenchmarkSamples={handleLoadBenchmarkSamples}
              onAddQuickDemoComplaint={() => {}}
              onSelectComplaint={(c) => handleSelectComplaintForInspection(c, true)}
              onOpenTrackModalWithId={handleOpenTrackModalWithId}
              currentUserSession={currentUserSession}
              onOpenAdminManagement={() => setIsAdminManagementOpen(true)}
            />
          ) : (
            <AdminLoginView
              onLoginSuccess={handleLoginSuccess}
              onBackToHome={() => setCurrentView('landing')}
            />
          )
        )}

        {/* 4. ANALYTICS & REPORTS VIEW */}
        {currentView === 'analytics' && (
          <AnalyticsView complaints={complaints} />
        )}
      </main>

      {/* Student Authentication Modal */}
      <StudentAuthModal
        isOpen={isStudentAuthOpen}
        onClose={() => setIsStudentAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialMode={studentAuthMode}
      />

      {/* Authorized Admin Provisioning Management Modal */}
      {currentUserSession?.role === 'admin' && (
        <AdminManagementModal
          isOpen={isAdminManagementOpen}
          onClose={() => setIsAdminManagementOpen(false)}
          currentAdminSession={currentUserSession}
        />
      )}

      {/* Quick Track Modal */}
      <TrackModal
        isOpen={isTrackModalOpen}
        onClose={() => setIsTrackModalOpen(false)}
        complaints={complaints}
        initialComplaintId={trackModalInitialId}
        onSelectComplaint={(c) => {
          setIsTrackModalOpen(false);
          handleSelectComplaintForInspection(c, false);
        }}
      />

      {/* Full Complaint Details & Dispatch Modal */}
      <ComplaintDetailsModal
        isOpen={Boolean(selectedComplaint)}
        complaint={selectedComplaint}
        onClose={() => setSelectedComplaint(null)}
        isAdmin={isDetailsAdminMode}
        onUpdateComplaint={handleUpdateComplaint}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <CampusAxisMain />
    </LanguageProvider>
  );
}
