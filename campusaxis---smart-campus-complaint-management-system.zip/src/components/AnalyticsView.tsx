import React from 'react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Building,
  MapPin,
  Download,
  PieChart as PieIcon,
  Inbox,
} from 'lucide-react';
import { Complaint } from '../types/complaint';
import { exportComplaintsToCSV } from '../services/storage';

interface AnalyticsViewProps {
  complaints: Complaint[];
}

const PALETTE = [
  '#2563EB', // Blue
  '#0D9488', // Teal
  '#D97706', // Amber
  '#DC2626', // Red
  '#7C3AED', // Violet
  '#059669', // Emerald
  '#EA580C', // Orange
  '#4F46E5', // Indigo
  '#DB2777', // Pink
  '#475569', // Slate
];

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ complaints }) => {
  // 1. Category Distribution
  const categoryCountMap: Record<string, number> = {};
  complaints.forEach((c) => {
    const key = c.category === 'Other / Describe Your Own Problem' ? 'Custom Problem' : c.category;
    categoryCountMap[key] = (categoryCountMap[key] || 0) + 1;
  });
  const categoryData = Object.entries(categoryCountMap)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // 2. Status Distribution (Pending vs In Progress vs Resolved)
  const statusData = [
    { name: 'Raised (Pending)', count: complaints.filter((c) => c.status === 'Raised').length, fill: '#2563EB' },
    { name: 'In Progress', count: complaints.filter((c) => c.status === 'In Progress').length, fill: '#D97706' },
    { name: 'Resolved', count: complaints.filter((c) => c.status === 'Resolved').length, fill: '#16A34A' },
  ];

  // 3. Location Hotspots
  const locationCountMap: Record<string, number> = {};
  complaints.forEach((c) => {
    const shortLocation = c.location.split('(')[0].trim();
    locationCountMap[shortLocation] = (locationCountMap[shortLocation] || 0) + 1;
  });
  const locationData = Object.entries(locationCountMap)
    .map(([location, count]) => ({ location, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // 4. Department Performance (Assigned vs Resolved)
  const deptMap: Record<string, { total: number; resolved: number }> = {};
  complaints.forEach((c) => {
    const dept = c.assignedDepartment || 'Unassigned';
    if (!deptMap[dept]) deptMap[dept] = { total: 0, resolved: 0 };
    deptMap[dept].total += 1;
    if (c.status === 'Resolved') deptMap[dept].resolved += 1;
  });
  const departmentData = Object.entries(deptMap)
    .map(([department, data]) => ({
      department: department.length > 20 ? `${department.slice(0, 18)}...` : department,
      fullName: department,
      total: data.total,
      resolved: data.resolved,
      pending: data.total - data.resolved,
    }))
    .slice(0, 6);

  // Summary Metrics
  const total = complaints.length;
  const resolved = complaints.filter((c) => c.status === 'Resolved').length;
  const resolutionRate = total > 0 ? Math.round((resolved / total) * 100) : 0;
  const escalatedCount = complaints.filter((c) => c.isEscalated).length;

  const resolvedWithTime = complaints.filter((c) => c.status === 'Resolved' && c.resolvedAt);
  const avgTurnaroundHours =
    resolvedWithTime.length > 0
      ? (
          resolvedWithTime.reduce((sum, c) => {
            const diff = new Date(c.resolvedAt!).getTime() - new Date(c.createdAt).getTime();
            return sum + Math.max(1, Math.floor(diff / (1000 * 60 * 60)));
          }, 0) / resolvedWithTime.length
        ).toFixed(1)
      : '0.0';

  const hasData = total > 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>SATI Vidisha Campus Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Campus Analytics & Resolution Reports
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Comprehensive breakdown of grievance categories, departmental SLAs, and campus hotspots.
          </p>
        </div>
        <button
          onClick={() => exportComplaintsToCSV(complaints)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 shadow-sm"
        >
          <Download className="w-3.5 h-3.5" />
          Export Report (CSV)
        </button>
      </div>

      {/* Top 4 Summary Metrics (All 0 when empty) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Total Logged
          </span>
          <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono mt-1">
            {total}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Across 15 campus domains</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
            Resolution Efficiency
          </span>
          <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono mt-1">
            {resolutionRate}%
          </div>
          <p className="text-[11px] text-slate-500 mt-1">{resolved} resolved successfully</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
            Avg Turnaround Time
          </span>
          <div className="text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-mono mt-1">
            {avgTurnaroundHours}h
          </div>
          <p className="text-[11px] text-slate-500 mt-1">From Raised to Verified Fix</p>
        </div>

        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
          <span className="text-xs font-bold uppercase tracking-wider text-red-600 dark:text-red-400">
            Escalation Rate
          </span>
          <div className="text-3xl font-extrabold text-red-600 dark:text-red-400 font-mono mt-1">
            {escalatedCount}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Flagged past 48h threshold</p>
        </div>
      </div>

      {/* Row 1: Category Distribution & Status Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Pie Chart */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              Category-Wise Complaint Distribution
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Breakdown of issues logged by domain
            </p>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    innerRadius={45}
                    dataKey="value"
                    label={({ name, percent }: { name?: string; percent?: number }) =>
                      `${name ?? ''} (${((percent ?? 0) * 100).toFixed(0)}%)`
                    }
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={PALETTE[index % PALETTE.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-slate-400">
                <PieIcon className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-xs">No complaint categories recorded yet.</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Submit tickets to view distribution.</p>
              </div>
            )}
          </div>
        </div>

        {/* Status Pipeline Chart */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              Complaint Pipeline Status
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Pending vs. In Progress vs. Resolved volume
            </p>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            {hasData ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statusData}>
                  <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} />
                  <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-slate-400">
                <Inbox className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-xs">No status pipeline data available.</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Status stages will plot here as tickets are filed.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Row 2: Location Hotspots & Department Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Location Hotspots */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <div className="mb-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              Frequently Reported Campus Locations
            </h3>
            <p className="text-xs text-slate-500">
              SATI Vidisha facility hotspots requiring infrastructure attention
            </p>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            {locationData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={locationData} layout="vertical">
                  <XAxis type="number" stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <YAxis type="category" dataKey="location" stroke="#94A3B8" fontSize={11} width={130} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" fill="#3B82F6" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-slate-400">
                <MapPin className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-xs">No location records reported yet.</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Campus location hotspots will track here.</p>
              </div>
            )}
          </div>
        </div>

        {/* Department Workload & Resolution */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <div className="mb-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
              Department Performance & Workload
            </h3>
            <p className="text-xs text-slate-500">
              Resolved vs. Pending tickets by campus division
            </p>
          </div>
          <div className="h-64 w-full flex items-center justify-center">
            {departmentData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentData}>
                  <XAxis dataKey="department" stroke="#94A3B8" fontSize={10} />
                  <YAxis stroke="#94A3B8" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0F172A',
                      borderRadius: '8px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Bar dataKey="resolved" name="Resolved" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="pending" name="Pending / In Progress" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-slate-400">
                <Building className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="text-xs">No department workload records yet.</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Departmental SLA statistics will show here.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
