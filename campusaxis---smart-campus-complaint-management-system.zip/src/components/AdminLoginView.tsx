import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  KeyRound,
  Building2,
  ArrowRight,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import {
  loginAdmin,
  hasAnyAdmin,
  initializeFirstAdmin,
  resetAdminPassword,
  SATI_ROOT_ADMIN_SETUP_KEY,
} from '../services/authService';
import { CurrentUserSession } from '../types/auth';
import { DEPARTMENTS } from '../constants/complaintData';

interface AdminLoginViewProps {
  onLoginSuccess: (session: CurrentUserSession) => void;
  onBackToHome: () => void;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({
  onLoginSuccess,
  onBackToHome,
}) => {
  const { t, language } = useLanguage();
  const [hasAdmins, setHasAdmins] = useState(() => hasAnyAdmin());
  const [viewMode, setViewMode] = useState<'login' | 'first-time-setup' | 'forgot'>(() =>
    hasAnyAdmin() ? 'login' : 'first-time-setup'
  );

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // First-time root setup form state
  const [setupFullName, setSetupFullName] = useState('');
  const [setupEmail, setSetupEmail] = useState('');
  const [setupUsername, setSetupUsername] = useState('admin.sati');
  const [setupDepartment, setSetupDepartment] = useState('Central Administration & Director Office');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupConfirmPassword, setSetupConfirmPassword] = useState('');
  const [setupAuthKey, setSetupAuthKey] = useState(SATI_ROOT_ADMIN_SETUP_KEY);
  const [showSetupPassword, setShowSetupPassword] = useState(false);

  // Forgot password form state
  const [forgotIdentifier, setForgotIdentifier] = useState('');
  const [forgotAuthKey, setForgotAuthKey] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');

  // Status states
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    setHasAdmins(hasAnyAdmin());
  }, []);

  const resetFormAlerts = () => {
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormAlerts();

    if (!loginIdentifier.trim() || !loginPassword) {
      setErrorMsg(language === 'hi' ? 'कृपया उपयोगकर्ता नाम/ईमेल और पासवर्ड भरें।' : 'Please enter both username/email and password.');
      return;
    }

    setLoading(true);
    try {
      const res = await loginAdmin(loginIdentifier, loginPassword, rememberMe);
      if (!res.success || !res.session) {
        setErrorMsg(res.error || (language === 'hi' ? 'प्रमाणीकरण विफल रहा।' : 'Authentication failed.'));
      } else {
        setSuccessMsg(t.authLoginSuccess);
        setTimeout(() => {
          onLoginSuccess(res.session!);
        }, 500);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleFirstTimeSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormAlerts();

    if (!setupFullName.trim() || !setupEmail.trim() || !setupUsername.trim() || !setupPassword) {
      setErrorMsg(language === 'hi' ? 'कृपया सभी आवश्यक फ़ील्ड भरें।' : 'Please fill in all required setup fields.');
      return;
    }

    if (setupPassword.length < 6) {
      setErrorMsg(language === 'hi' ? 'पासवर्ड में कम से कम 6 अक्षर होने चाहिए।' : 'Password must be at least 6 characters.');
      return;
    }

    if (setupPassword !== setupConfirmPassword) {
      setErrorMsg(t.authPasswordMismatch);
      return;
    }

    setLoading(true);
    try {
      const res = await initializeFirstAdmin({
        fullName: setupFullName,
        email: setupEmail,
        username: setupUsername,
        department: setupDepartment,
        password: setupPassword,
        authorizationKey: setupAuthKey,
      });

      if (!res.success || !res.session) {
        setErrorMsg(res.error || (language === 'hi' ? 'प्रशासक खाता व्यवस्थापन विफल रहा।' : 'Admin initialization failed.'));
      } else {
        setHasAdmins(true);
        setSuccessMsg(language === 'hi' ? 'मुख्य प्रशासक खाता सफलतापूर्वक प्रारंभ हुआ! प्रवेश हो रहा है...' : 'Root Administrator initialized! Logging in...');
        setTimeout(() => {
          onLoginSuccess(res.session!);
        }, 700);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAdminForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormAlerts();

    if (!forgotIdentifier.trim() || !forgotAuthKey.trim() || !forgotNewPassword) {
      setErrorMsg(language === 'hi' ? 'कृपया सभी फ़ील्ड भरें।' : 'Please fill in all fields.');
      return;
    }

    if (forgotNewPassword.length < 6) {
      setErrorMsg(language === 'hi' ? 'पासवर्ड में कम से कम 6 अक्षर होने चाहिए।' : 'Password must be at least 6 characters.');
      return;
    }

    if (forgotNewPassword !== forgotConfirmPassword) {
      setErrorMsg(t.authPasswordMismatch);
      return;
    }

    setLoading(true);
    try {
      const res = await resetAdminPassword(forgotIdentifier, forgotNewPassword, forgotAuthKey);
      if (!res.success) {
        setErrorMsg(res.error || (language === 'hi' ? 'पासवर्ड रीसेट विफल रहा।' : 'Password reset failed.'));
      } else {
        setSuccessMsg(language === 'hi' ? 'प्रशासक पासवर्ड सफलतापूर्वक बदला गया। अब लॉग इन करें।' : 'Admin password reset successfully! Please sign in.');
        setTimeout(() => {
          setViewMode('login');
          setLoginIdentifier(forgotIdentifier);
        }, 1200);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[82vh] flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8 bg-slate-50 dark:bg-slate-950">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-6 bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white relative">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 font-mono">
              SATI-ADMIN-OPS
            </span>
          </div>

          <h2 className="text-xl font-extrabold tracking-tight">{t.authAdminTitle}</h2>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">{t.authAdminSubtitle}</p>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          {/* Alerts */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}
          {successMsg && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* 1. ADMIN LOGIN */}
          {viewMode === 'login' && (
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t.authAdminUsernameOrEmail}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="e.g. admin.sati or admin@satiengg.in"
                    required
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    {t.authPassword}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setViewMode('forgot');
                      resetFormAlerts();
                    }}
                    className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline cursor-pointer"
                  >
                    {t.authForgotPassword}
                  </button>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    className="w-full pl-9 pr-10 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-600 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 dark:border-slate-700"
                  />
                  <span className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                    {t.authRememberMe}
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 text-white rounded-xl text-sm font-bold shadow-md shadow-blue-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {loading ? t.loading : t.authAdminLoginBtn}
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Security Policy Notice */}
              <div className="p-3 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 rounded-xl flex items-start gap-2.5 text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <span>{t.authAdminNoPublicSignUpNote}</span>
              </div>

              {/* If no admin accounts exist yet, show option to initialize */}
              {!hasAdmins && (
                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setViewMode('first-time-setup');
                      resetFormAlerts();
                    }}
                    className="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer flex items-center justify-center gap-1.5 w-full"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    {t.authFirstTimeAdminSetup}
                  </button>
                </div>
              )}
            </form>
          )}

          {/* 2. FIRST TIME AUTHORIZED ROOT SETUP */}
          {viewMode === 'first-time-setup' && (
            <form onSubmit={handleFirstTimeSetup} className="space-y-3.5">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-xl text-xs text-amber-900 dark:text-amber-300 leading-relaxed">
                <p className="font-bold flex items-center gap-1.5 mb-1">
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  {t.authFirstTimeAdminSetup}
                </p>
                {language === 'hi'
                  ? 'परिसर व्यवस्थापक की प्राथमिक स्थापना हेतु सती अधिकृत संस्थागत मास्टर कुंजी (SATI-ADMIN-2026) का उपयोग करें।'
                  : 'Establish the primary root administrator account using the authorized SATI institutional master key (SATI-ADMIN-2026).'}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.authAuthorizationKey} <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={setupAuthKey}
                    onChange={(e) => setSetupAuthKey(e.target.value)}
                    placeholder="SATI-ADMIN-2026"
                    required
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-indigo-700 dark:text-indigo-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authFullName} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={setupFullName}
                    onChange={(e) => setSetupFullName(e.target.value)}
                    placeholder="e.g. Dr. R.K. Verma"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authCollegeEmail} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={setupEmail}
                    onChange={(e) => setSetupEmail(e.target.value)}
                    placeholder="admin@satiengg.in"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Username <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={setupUsername}
                    onChange={(e) => setSetupUsername(e.target.value)}
                    placeholder="admin.sati"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authDepartment}
                  </label>
                  <input
                    type="text"
                    value={setupDepartment}
                    onChange={(e) => setSetupDepartment(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authPassword} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    value={setupPassword}
                    onChange={(e) => setSetupPassword(e.target.value)}
                    placeholder="Min. 6 chars"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authConfirmPassword} <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type={showSetupPassword ? 'text' : 'password'}
                    value={setupConfirmPassword}
                    onChange={(e) => setSetupConfirmPassword(e.target.value)}
                    placeholder="Confirm password"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                {hasAdmins && (
                  <button
                    type="button"
                    onClick={() => {
                      setViewMode('login');
                      resetFormAlerts();
                    }}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    {t.btnCancel}
                  </button>
                )}
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-2 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all cursor-pointer disabled:opacity-60"
                >
                  {loading ? t.loading : t.authInitializeRootAdminBtn}
                </button>
              </div>
            </form>
          )}

          {/* 3. FORGOT PASSWORD */}
          {viewMode === 'forgot' && (
            <form onSubmit={handleAdminForgotSubmit} className="space-y-3.5">
              <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-300">
                {language === 'hi'
                  ? 'व्यवस्थापक पासवर्ड रीसेट करने के लिए संस्थागत प्राधिकरण कुंजी आवश्यक है।'
                  : 'Institutional master authorization key required to reset administrative credentials.'}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.authAdminUsernameOrEmail}
                </label>
                <input
                  type="text"
                  value={forgotIdentifier}
                  onChange={(e) => setForgotIdentifier(e.target.value)}
                  placeholder="admin.sati or admin@satiengg.in"
                  required
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.authAuthorizationKey}
                </label>
                <input
                  type="text"
                  value={forgotAuthKey}
                  onChange={(e) => setForgotAuthKey(e.target.value)}
                  placeholder="SATI-ADMIN-2026"
                  required
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'hi' ? 'नया पासवर्ड' : 'New Password'}
                  </label>
                  <input
                    type="password"
                    value={forgotNewPassword}
                    onChange={(e) => setForgotNewPassword(e.target.value)}
                    placeholder="Min. 6 chars"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.authConfirmPassword}
                  </label>
                  <input
                    type="password"
                    value={forgotConfirmPassword}
                    onChange={(e) => setForgotConfirmPassword(e.target.value)}
                    placeholder="Confirm password"
                    required
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setViewMode('login');
                    resetFormAlerts();
                  }}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {t.btnCancel}
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold cursor-pointer disabled:opacity-60"
                >
                  {loading ? t.loading : (language === 'hi' ? 'पासवर्ड रीसेट करें' : 'Reset Password')}
                </button>
              </div>
            </form>
          )}

          {/* Back to Home Button */}
          <div className="pt-3 text-center border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onBackToHome}
              className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 font-semibold cursor-pointer"
            >
              ← {language === 'hi' ? 'मुख्य पृष्ठ (होम) पर वापस जाएं' : 'Back to CampusAxis Home'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
