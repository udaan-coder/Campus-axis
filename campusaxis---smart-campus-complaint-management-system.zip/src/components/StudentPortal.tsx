import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  PlusCircle,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  Sparkles,
  MapPin,
  Camera,
  EyeOff,
  Send,
  Building,
  User,
  Star,
  ExternalLink,
  ChevronRight,
  Shield,
  FileText,
  RotateCcw,
  Info,
} from 'lucide-react';
import {
  Complaint,
  ComplaintCategory,
  UrgencyLevel,
  AffectedScale,
} from '../types/complaint';
import {
  CAMPUS_LOCATIONS,
  suggestCategoryFromText,
  calculatePriorityScore,
} from '../constants/complaintData';
import { CurrentUserSession } from '../types/auth';
import { useLanguage } from '../context/LanguageContext';
import {
  getTranslatedCategory,
  getTranslatedStatus,
  getTranslatedUrgency,
} from '../constants/translations';

interface StudentPortalProps {
  complaints: Complaint[];
  onAddComplaint: (complaint: Complaint) => void;
  onOpenTrackModalWithId: (id: string) => void;
  onSelectComplaint: (complaint: Complaint) => void;
  initialTab?: 'overview' | 'submit' | 'my-complaints' | 'track' | 'notifications' | 'profile';
  currentUserSession?: CurrentUserSession | null;
  onOpenAuthModal?: () => void;
}

const CATEGORIES_LIST: ComplaintCategory[] = [
  'Internet & Wi-Fi',
  'Classroom Issues',
  'Hostel Issues',
  'Laboratory Issues',
  'Library Issues',
  'Canteen & Food',
  'Cleanliness & Sanitation',
  'Water & Electricity',
  'Campus Infrastructure',
  'Administration',
  'Security & Safety',
  'Sports & Recreation',
  'Transport & Parking',
  'Medical & Health Facilities',
  'Other / Describe Your Own Problem',
];

// Sample campus issue images that students can pick easily or upload their own
const SAMPLE_EVIDENCE_PHOTOS = [
  { name: 'Wi-Fi Router Blink', url: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=800&q=80' },
  { name: 'Water Leakage', url: 'https://images.unsplash.com/photo-1585338107529-13afc5f02586?auto=format&fit=crop&w=800&q=80' },
  { name: 'Lab Hardware', url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=800&q=80' },
  { name: 'Damaged Pavement', url: 'https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?auto=format&fit=crop&w=800&q=80' },
];

export const StudentPortal: React.FC<StudentPortalProps> = ({
  complaints,
  onAddComplaint,
  onOpenTrackModalWithId,
  onSelectComplaint,
  initialTab = 'overview',
  currentUserSession,
  onOpenAuthModal,
}) => {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'overview' | 'submit' | 'my-complaints' | 'track' | 'notifications' | 'profile'>(initialTab);

  // Form State
  const [category, setCategory] = useState<ComplaintCategory>('Internet & Wi-Fi');
  const [customCategoryTitle, setCustomCategoryTitle] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState(CAMPUS_LOCATIONS[0]);
  const [customLocationText, setCustomLocationText] = useState('');
  const [blockDetail, setBlockDetail] = useState('');
  const [urgency, setUrgency] = useState<UrgencyLevel>('Medium');
  const [affectedScale, setAffectedScale] = useState<AffectedScale>('Individual (1 student)');
  const [safetyHazard, setSafetyHazard] = useState<boolean>(false);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [imageFileName, setImageFileName] = useState('');

  // Smart suggestions & Duplicate detection state
  const [suggestedCategory, setSuggestedCategory] = useState<{
    category: ComplaintCategory | null;
    matchedKeyword: string | null;
    confidence: 'High' | 'Medium' | 'Low';
  }>({ category: null, matchedKeyword: null, confidence: 'Low' });

  const [duplicateWarning, setDuplicateWarning] = useState<Complaint | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitSuccessId, setSubmitSuccessId] = useState<string | null>(null);

  // Filter & Search in "My Complaints"
  const [statusFilter, setStatusFilter] = useState<'all' | 'Raised' | 'In Progress' | 'Resolved'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Track tab state
  const [trackingInputId, setTrackingInputId] = useState('');

  // Dynamic Student Profile based on active authentication
  const activeStudent = currentUserSession && currentUserSession.role === 'student'
    ? {
        name: currentUserSession.fullName,
        email: currentUserSession.email,
        department: currentUserSession.department || 'Computer Science & Engineering',
        rollNumber: currentUserSession.studentId || '0108CS221050',
        semester: currentUserSession.yearSemester || 'Student Member',
        isLoggedIn: true,
      }
    : {
        name: 'Parul Vishwakarma',
        email: 'parul29bc050@satiengg.in',
        department: 'Computer Science & Engineering',
        rollNumber: '0108CS221050',
        semester: '6th Semester, B.Tech',
        isLoggedIn: false,
      };

  // Sync initialTab if prop changes
  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // Run Smart Category Suggestion and Duplicate Detection on text change
  useEffect(() => {
    const combinedText = `${title} ${description}`;
    if (combinedText.trim().length > 6) {
      // 1. Suggest Category
      const suggestion = suggestCategoryFromText(combinedText);
      if (suggestion.category && suggestion.category !== category) {
        setSuggestedCategory(suggestion);
      } else {
        setSuggestedCategory({ category: null, matchedKeyword: null, confidence: 'Low' });
      }

      // 2. Duplicate Detection
      const match = complaints.find((c) => {
        if (c.status === 'Resolved') return false;
        const matchesCategory = c.category === category;
        const words = title.toLowerCase().split(/\s+/).filter((w) => w.length > 3);
        const hasKeywordMatch = words.some((w) => c.title.toLowerCase().includes(w));
        return matchesCategory && hasKeywordMatch;
      });
      setDuplicateWarning(match || null);
    } else {
      setSuggestedCategory({ category: null, matchedKeyword: null, confidence: 'Low' });
      setDuplicateWarning(null);
    }
  }, [title, description, category, complaints]);

  // Handle Local File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('File size exceeds 5MB limit.');
        return;
      }
      setImageFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!title.trim()) errors.title = 'Please enter a concise complaint title.';
    if (!description.trim()) errors.description = 'Please describe the problem in detail.';
    if (description.trim().length < 15) errors.description = 'Please provide at least 15 characters of detail.';
    if (category === 'Other / Describe Your Own Problem' && !customCategoryTitle.trim()) {
      errors.customCategoryTitle = 'Please specify a title for your custom problem.';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    setFormErrors({});

    // Generate unique complaint ID: CC-2026-XXXX
    const nextNum = complaints.length + 1;
    const padded = String(nextNum).padStart(4, '0');
    const newId = `CC-2026-${padded}`;
    const nowIso = new Date().toISOString();

    const finalLocation = location === 'Other Campus Location' && customLocationText.trim()
      ? `Other: ${customLocationText.trim()}`
      : location;

    const calc = calculatePriorityScore(
      category,
      nowIso,
      urgency,
      affectedScale,
      safetyHazard
    );

    const newComplaint: Complaint = {
      id: newId,
      title: title.trim(),
      category,
      customCategoryTitle: category === 'Other / Describe Your Own Problem' ? customCategoryTitle.trim() : undefined,
      description: description.trim(),
      location: finalLocation,
      blockDetail: blockDetail.trim() || undefined,
      urgency,
      affectedScale,
      safetyHazard,
      status: 'Raised',
      createdAt: nowIso,
      submittedBy: {
        name: isAnonymous ? 'Anonymous Student' : activeStudent.name,
        email: isAnonymous ? 'anonymous@satiengg.in' : activeStudent.email,
        department: activeStudent.department,
        rollNumber: isAnonymous ? 'HIDDEN' : activeStudent.rollNumber,
        isAnonymous,
      },
      priorityScore: calc.score,
      priorityLabel: calc.priorityLabel,
      priorityBreakdown: {
        categoryWeight: calc.categoryWeight,
        urgencyScore: calc.urgencyScore,
        ageBonus: calc.ageDays,
        affectedScore: calc.affectedScore,
        safetyScore: calc.safetyScore,
        totalScore: calc.score,
        priorityLabel: calc.priorityLabel,
        reason: calc.reason,
      },
      pendingHours: 0,
      categoryWeight: calc.categoryWeight,
      imageUrl: imageUrl || undefined,
      timeline: [
        {
          id: `t-${Date.now()}`,
          status: 'Raised',
          timestamp: nowIso,
          actor: isAnonymous ? 'Anonymous Student' : `${activeStudent.name} (${activeStudent.rollNumber})`,
          note: `Complaint registered in ${category} (${urgency} urgency). Smart Priority Score: ${calc.score} (${calc.priorityLabel} Priority). Reason: ${calc.reason}.`,
        },
      ],
    };

    onAddComplaint(newComplaint);
    setSubmitSuccessId(newId);

    // Fire Confetti!
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // safe fallback
    }

    // Reset Form
    setTitle('');
    setDescription('');
    setCustomCategoryTitle('');
    setBlockDetail('');
    setCustomLocationText('');
    setUrgency('Medium');
    setAffectedScale('Individual (1 student)');
    setSafetyHazard(false);
    setImageUrl('');
    setImageFileName('');
    setIsAnonymous(false);
  };

  // Student Metrics
  const totalComplaints = complaints.length;
  const pendingCount = complaints.filter((c) => c.status === 'Raised').length;
  const inProgressCount = complaints.filter((c) => c.status === 'In Progress').length;
  const resolvedCount = complaints.filter((c) => c.status === 'Resolved').length;

  // Filtered Complaints for My Complaints tab (personalizing if student is logged in)
  const filteredComplaints = complaints.filter((c) => {
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        c.id.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Welcome Strip & Student Identity Card */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white rounded-2xl p-6 mb-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-blue-200 mb-1">
              <span>{language === 'hi' ? 'सती विदिशा छात्र पोर्टल' : 'SATI Vidisha Student Portal'}</span>
              <span>·</span>
              <span>{language === 'hi' ? 'शैक्षणिक वर्ष 2026' : 'Academic Year 2026'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {language === 'hi' ? `स्वागत है, ${activeStudent.name}` : `Welcome, ${activeStudent.name}`}
            </h1>
            <p className="text-xs sm:text-sm text-blue-100 mt-1">
              {activeStudent.department} · {language === 'hi' ? 'नामांकन' : 'Roll'}: {activeStudent.rollNumber} {activeStudent.semester ? `· ${activeStudent.semester}` : ''}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!activeStudent.isLoggedIn && onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="px-4 py-2.5 bg-blue-500/30 hover:bg-blue-500/50 text-white border border-blue-300/40 rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shrink-0"
              >
                {t.navStudentLogin}
              </button>
            )}
            <button
              onClick={() => {
                setSubmitSuccessId(null);
                setActiveTab('submit');
              }}
              className="px-4 py-2.5 bg-white text-blue-900 hover:bg-blue-50 font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer shrink-0"
            >
              <PlusCircle className="w-4 h-4 text-blue-600" />
              {t.tabSubmitComplaint}
            </button>
            <button
              onClick={() => setActiveTab('my-complaints')}
              className="px-4 py-2.5 bg-blue-700/60 hover:bg-blue-700 text-white border border-blue-400/30 rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shrink-0"
            >
              {t.tabMyComplaints} ({totalComplaints})
            </button>
          </div>
        </div>
      </div>

      {/* Student Navigation Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {t.tabOverview}
        </button>
        <button
          onClick={() => {
            setSubmitSuccessId(null);
            setActiveTab('submit');
          }}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'submit'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          {t.tabSubmitComplaint}
        </button>
        <button
          onClick={() => setActiveTab('my-complaints')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            activeTab === 'my-complaints'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {t.tabMyComplaints} ({totalComplaints})
        </button>
        <button
          onClick={() => setActiveTab('track')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'track'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          {t.tabTrackComplaint}
        </button>
      </div>

      {/* ===================== TAB 1: OVERVIEW ===================== */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  {t.statsTotalComplaints}
                </span>
                <FileText className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-3xl font-extrabold text-slate-900 dark:text-white font-mono">
                {totalComplaints}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Logged across all campus cells</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Pending (Raised)
                </span>
                <Clock className="w-4 h-4 text-blue-500" />
              </div>
              <div className="text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">
                {pendingCount}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Awaiting department inspection</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  In Progress
                </span>
                <AlertTriangle className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-mono">
                {inProgressCount}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Technicians actively on-site</p>
            </div>

            <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Resolved
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                {resolvedCount}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Verified and completed</p>
            </div>
          </div>

          {/* Recent Complaints Banner */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Recent Complaints Logged
                </h3>
                <p className="text-xs text-slate-500">
                  Real-time status updates and priority rankings
                </p>
              </div>
              <button
                onClick={() => setActiveTab('my-complaints')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                View all ({totalComplaints}) <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {complaints.length === 0 ? (
                <div className="text-center py-10 px-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                    No Complaints Filed Yet
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
                    CampusAxis is ready to record and track your grievances. Facing an issue in classrooms, hostels, laboratories, or Wi-Fi? Submit a ticket to alert campus administrators.
                  </p>
                  <button
                    onClick={() => setActiveTab('submit')}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer inline-flex items-center gap-1.5 shadow-xs"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    File Your First Complaint
                  </button>
                </div>
              ) : (
                complaints.slice(0, 4).map((c) => (
                  <div
                    key={c.id}
                    onClick={() => onSelectComplaint(c)}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/40 px-2 rounded-xl transition-colors cursor-pointer"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded">
                          {c.id}
                        </span>
                        <span className="text-xs text-slate-500">{c.category}</span>
                        <span className="text-slate-300 dark:text-slate-700">·</span>
                        <span className="text-xs text-slate-500">{c.location}</span>
                      </div>
                      <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                        {c.title}
                      </h4>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-xs text-slate-500 font-mono">
                        Priority: <strong>{c.priorityScore}</strong>
                      </span>
                      <span
                        className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                          c.status === 'Resolved'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : c.status === 'In Progress'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                        }`}
                      >
                        {c.status}
                      </span>
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 2: SUBMIT COMPLAINT FORM ===================== */}
      {activeTab === 'submit' && (
        <div className="max-w-3xl mx-auto">
          {submitSuccessId ? (
            <div className="bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-900/60 rounded-2xl p-8 text-center shadow-lg space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                Complaint Submitted Successfully!
              </h2>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl inline-block font-mono text-sm">
                Reference ID: <strong className="text-blue-600 dark:text-blue-400">{submitSuccessId}</strong>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto leading-relaxed">
                Your issue has been logged into the SATI Vidisha priority queue. The system has calculated the mathematical priority score and dispatched an alert to the responsible campus department.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
                <button
                  onClick={() => onOpenTrackModalWithId(submitSuccessId)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Track This Complaint Now
                </button>
                <button
                  onClick={() => setSubmitSuccessId(null)}
                  className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Submit Another Issue
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-sm">
              <div className="border-b border-slate-100 dark:border-slate-800 pb-4 mb-6">
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  Report a Campus Problem
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Fill in the details below. Our smart engine will suggest categories, inspect for duplicates, and calculate priority mathematically.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* 1. Category Selection (15 categories) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                    1. Select Complaint Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ComplaintCategory)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  >
                    {CATEGORIES_LIST.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat} {cat === 'Other / Describe Your Own Problem' ? '★ (Custom Problem)' : ''}
                      </option>
                    ))}
                  </select>

                  {/* Smart Category Suggestion Badge */}
                  {suggestedCategory.category && suggestedCategory.category !== category && (
                    <div className="mt-2.5 p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl text-xs flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
                        <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>
                          Smart Suggestion: Detected keyword "<strong>{suggestedCategory.matchedKeyword}</strong>". Switch category to "<strong>{suggestedCategory.category}</strong>"?
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setCategory(suggestedCategory.category!);
                          setSuggestedCategory({ category: null, matchedKeyword: null, confidence: 'Low' });
                        }}
                        className="px-2.5 py-1 bg-amber-600 text-white rounded-lg font-bold text-[11px] shrink-0 hover:bg-amber-700 transition-colors cursor-pointer"
                      >
                        Apply
                      </button>
                    </div>
                  )}
                </div>

                {/* SPECIAL CUSTOM COMPLAINT DEDICATED FIELDS (when "Other" selected) */}
                {category === 'Other / Describe Your Own Problem' && (
                  <div className="p-4 bg-blue-50/70 dark:bg-blue-950/30 border-2 border-blue-300 dark:border-blue-900 rounded-xl space-y-3 animate-in fade-in duration-150">
                    <div className="flex items-center gap-2 text-xs font-bold text-blue-900 dark:text-blue-300">
                      <Info className="w-4 h-4 text-blue-600" />
                      Custom Problem Mode Enabled
                    </div>
                    <p className="text-xs text-blue-800 dark:text-blue-200">
                      You are not restricted to predefined categories. Name your custom problem domain below. College administrators will review and assign the appropriate department.
                    </p>
                    <div>
                      <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200 mb-1">
                        Custom Problem Title / Subject *
                      </label>
                      <input
                        type="text"
                        value={customCategoryTitle}
                        onChange={(e) => setCustomCategoryTitle(e.target.value)}
                        placeholder="e.g. Accessibility ramp repair, Braille signage, stray animal control..."
                        className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-blue-300 dark:border-blue-800 rounded-lg text-xs"
                      />
                      {formErrors.customCategoryTitle && (
                        <p className="text-xs text-red-600 mt-1">{formErrors.customCategoryTitle}</p>
                      )}
                    </div>
                  </div>
                )}

                {/* 2. Complaint Title */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    2. Complaint Title *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., Wi-Fi disconnected in Lab 204 / Broken fan in LH-102..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                  {formErrors.title && (
                    <p className="text-xs text-red-600 mt-1">{formErrors.title}</p>
                  )}
                </div>

                {/* Duplicate Complaint Warning Notice */}
                {duplicateWarning && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-xl text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block font-semibold">Potential Duplicate Warning:</strong>
                      A similar active complaint was found: <strong className="font-mono text-blue-600 dark:text-blue-400">#{duplicateWarning.id}</strong> ("{duplicateWarning.title}"). You may still proceed with your submission if your issue is distinct.
                    </div>
                  </div>
                )}

                {/* 3. Detailed Description */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    3. Detailed Description *
                  </label>
                  <textarea
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Please explain the problem thoroughly: What is broken? When did it start? How does it affect students?"
                    className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none leading-relaxed"
                  />
                  {formErrors.description && (
                    <p className="text-xs text-red-600 mt-1">{formErrors.description}</p>
                  )}
                </div>

                {/* 4. Campus Location Mapping */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                      4. Campus Location *
                    </label>
                    <select
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    >
                      {CAMPUS_LOCATIONS.map((loc) => (
                        <option key={loc} value={loc}>
                          {loc}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                      Block / Room / Wing Detail (Optional)
                    </label>
                    <input
                      type="text"
                      value={blockDetail}
                      onChange={(e) => setBlockDetail(e.target.value)}
                      placeholder="e.g., Room 204, 2nd Floor, Wing B..."
                      className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>
                </div>

                {location === 'Other Campus Location' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Specify Other Location:
                    </label>
                    <input
                      type="text"
                      value={customLocationText}
                      onChange={(e) => setCustomLocationText(e.target.value)}
                      placeholder="Specify landmark or campus area..."
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs"
                    />
                  </div>
                )}

                {/* 5. Urgency Selection (Requirement 1 & 2) */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                      5. Urgency Level *
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Factor 2 of 5 in Priority Engine
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(
                      [
                        { level: 'Critical' as UrgencyLevel, pts: '+4', color: 'bg-red-600 border-red-600 text-white', desc: 'Emergency / Halt' },
                        { level: 'High' as UrgencyLevel, pts: '+3', color: 'bg-orange-500 border-orange-500 text-white', desc: 'Severe disruption' },
                        { level: 'Medium' as UrgencyLevel, pts: '+2', color: 'bg-blue-600 border-blue-600 text-white', desc: 'Normal inconvenience' },
                        { level: 'Low' as UrgencyLevel, pts: '+1', color: 'bg-slate-700 border-slate-700 text-white', desc: 'Minor / Cosmetic' },
                      ]
                    ).map(({ level, pts, color, desc }) => (
                      <button
                        key={level}
                        type="button"
                        onClick={() => setUrgency(level)}
                        className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                          urgency === level
                            ? `${color} shadow-sm ring-2 ring-offset-2 ring-blue-500/30`
                            : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900'
                        }`}
                      >
                        <div className="flex items-center justify-between font-bold text-xs mb-0.5">
                          <span>{level}</span>
                          <span className="font-mono text-[10px] opacity-90">{pts} pts</span>
                        </div>
                        <div className="text-[10px] opacity-80 truncate">{desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 6. Number of Students Affected (Requirement 2) */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                      6. Number of Students Affected *
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Factor 4 of 5 in Priority Engine
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {(
                      [
                        { scale: 'Individual (1 student)' as AffectedScale, pts: '+0 pts', desc: 'Affects only my own desk/seat' },
                        { scale: 'Room / Bench (2–10 students)' as AffectedScale, pts: '+1 pt', desc: 'Roommates, lab group, or table' },
                        { scale: 'Class / Wing (10–50 students)' as AffectedScale, pts: '+2 pts', desc: 'Full batch, hostel wing, or lecture hall' },
                        { scale: 'Entire Block / Campus (>50 students)' as AffectedScale, pts: '+3 pts', desc: 'Academic block, dining hall, or campus-wide' },
                      ]
                    ).map(({ scale, pts, desc }) => (
                      <button
                        key={scale}
                        type="button"
                        onClick={() => setAffectedScale(scale)}
                        className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                          affectedScale === scale
                            ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-600 text-blue-900 dark:text-blue-200 ring-1 ring-blue-600'
                            : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900'
                        }`}
                      >
                        <div className="flex items-center justify-between font-bold text-xs mb-0.5">
                          <span>{scale}</span>
                          <span className="font-mono text-[10px] text-blue-600 dark:text-blue-400 font-bold">{pts}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">{desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 7. Direct Safety Impact (Requirement 2) */}
                <div className="p-3.5 bg-red-50/60 dark:bg-red-950/25 border border-red-200 dark:border-red-900/60 rounded-xl flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="safety-hazard-check"
                    checked={safetyHazard}
                    onChange={(e) => setSafetyHazard(e.target.checked)}
                    className="w-4 h-4 text-red-600 rounded cursor-pointer mt-0.5 accent-red-600"
                  />
                  <div className="flex-1">
                    <label
                      htmlFor="safety-hazard-check"
                      className="text-xs font-bold text-red-950 dark:text-red-300 flex items-center justify-between gap-1.5 cursor-pointer"
                    >
                      <span className="flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                        Direct Physical or Safety Hazard Impact
                      </span>
                      <span className="text-[10px] font-mono font-extrabold bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 px-2 py-0.5 rounded">
                        +3 pts
                      </span>
                    </label>
                    <p className="text-[11px] text-red-800/80 dark:text-red-300/80 mt-0.5 leading-relaxed">
                      Check if this problem involves electrical spark/shock risk, gas leakage, exposed wiring, structural fall hazard, sharp metal, or security danger.
                    </p>
                  </div>
                </div>

                {/* 6. Photo Evidence Upload */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Camera className="w-3.5 h-3.5 text-blue-600" />
                    6. Image Evidence (Optional)
                  </label>

                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row items-center gap-3">
                      <label className="w-full sm:w-auto px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold cursor-pointer border border-slate-200 dark:border-slate-700 text-center">
                        <span>Browse Local Image</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                      <span className="text-xs text-slate-400">or pick a sample photo:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {SAMPLE_EVIDENCE_PHOTOS.map((sample) => (
                          <button
                            key={sample.name}
                            type="button"
                            onClick={() => {
                              setImageUrl(sample.url);
                              setImageFileName(sample.name);
                            }}
                            className="text-[11px] px-2 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded hover:bg-blue-50 dark:hover:bg-slate-700 cursor-pointer"
                          >
                            {sample.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {imageUrl && (
                      <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-48 bg-slate-900/10 flex items-center justify-center p-2">
                        <img
                          src={imageUrl}
                          alt="Preview"
                          className="max-h-44 object-contain rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setImageUrl('');
                            setImageFileName('');
                          }}
                          className="absolute top-3 right-3 px-2 py-1 bg-red-600 text-white rounded text-xs font-bold hover:bg-red-700 cursor-pointer shadow-sm"
                        >
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* 7. Anonymous Reporting Toggle */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="anonymous-check"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded cursor-pointer mt-0.5"
                  />
                  <div>
                    <label
                      htmlFor="anonymous-check"
                      className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5 cursor-pointer"
                    >
                      <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                      Submit Anonymously (Identity Protected)
                    </label>
                    <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                      Your name, email, and roll number will be hidden on public complaint lists and student trackers. Only authorized administrators retain audit logs for security.
                    </p>
                  </div>
                </div>

                {/* Live Smart Priority Engine Calculation Card */}
                {(() => {
                  const preview = calculatePriorityScore(
                    category,
                    new Date().toISOString(),
                    urgency,
                    affectedScale,
                    safetyHazard
                  );
                  return (
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-900 dark:to-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-blue-900 dark:text-blue-300 flex items-center gap-1.5 uppercase tracking-wider">
                          <Sparkles className="w-4 h-4 text-blue-600" />
                          Smart Priority Engine (Live Preview)
                        </span>
                        <div className="flex items-center gap-2">
                          <span
                            className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                              preview.priorityLabel === 'Critical'
                                ? 'bg-red-600 text-white'
                                : preview.priorityLabel === 'High'
                                ? 'bg-orange-500 text-white'
                                : preview.priorityLabel === 'Medium'
                                ? 'bg-blue-600 text-white'
                                : 'bg-slate-700 text-white'
                            }`}
                          >
                            {preview.priorityLabel} Priority
                          </span>
                          <span className="font-mono text-sm font-extrabold text-blue-700 dark:text-blue-400 bg-white dark:bg-slate-950 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-800">
                            Score: {preview.score}
                          </span>
                        </div>
                      </div>
                      <p className="text-[11px] text-blue-950/80 dark:text-blue-200/80 font-mono">
                        Formula: Category ({preview.categoryWeight}) + Urgency ({preview.urgencyScore}) + Affected ({preview.affectedScore}) + Safety ({preview.safetyScore}) = {preview.score}
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        * Time-elapsed aging bonus (+1 per 24h) will dynamically accrue post-submission until resolved.
                      </p>
                    </div>
                  );
                })()}

                {/* Submit Action */}
                <div className="pt-4 flex items-center justify-between border-t border-slate-100 dark:border-slate-800">
                  <div className="text-xs text-slate-500">
                    Reporter: {isAnonymous ? 'Anonymous' : activeStudent.name} ({activeStudent.rollNumber})
                  </div>
                  <button
                    type="submit"
                    className="px-7 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    Submit Complaint
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* ===================== TAB 3: MY COMPLAINTS ===================== */}
      {activeTab === 'my-complaints' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
            {/* Filter buttons */}
            <div className="flex items-center gap-1 overflow-x-auto">
              {(['all', 'Raised', 'In Progress', 'Resolved'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    statusFilter === status
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {status === 'all' ? 'All Complaints' : status}
                </button>
              ))}
            </div>

            {/* Search within complaints */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search complaints..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>
          </div>

          {/* Complaints List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredComplaints.length === 0 ? (
              <div className="col-span-2 text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                <FileText className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
                  No Complaints Found
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  Try adjusting your filter or search query.
                </p>
              </div>
            ) : (
              filteredComplaints.map((c) => (
                <div
                  key={c.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:border-blue-400 dark:hover:border-blue-600 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-900">
                          {c.id}
                        </span>
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                            c.status === 'Resolved'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : c.status === 'In Progress'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          }`}
                        >
                          {c.status}
                        </span>
                        {c.isEscalated && (
                          <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.5 rounded font-bold">
                            Escalated
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-slate-500 font-mono">
                        Priority: <strong>{c.priorityScore}</strong>
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1.5 line-clamp-1">
                      {c.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 line-clamp-2 leading-relaxed">
                      {c.description}
                    </p>

                    <div className="text-[11px] text-slate-500 space-y-1 mb-4">
                      <div className="flex items-center gap-1.5 truncate">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{c.location}</span>
                      </div>
                      <div className="flex items-center gap-1.5 truncate">
                        <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">Assigned: {c.assignedDepartment || 'Pending Assignment'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <button
                      onClick={() => onOpenTrackModalWithId(c.id)}
                      className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      Track Timeline
                    </button>
                    <button
                      onClick={() => onSelectComplaint(c)}
                      className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ===================== TAB 4: TRACK COMPLAINT ===================== */}
      {activeTab === 'track' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs text-center">
          <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Track Any Campus Issue
          </h2>
          <p className="text-xs text-slate-500 mb-6 max-w-sm mx-auto">
            Enter your reference ID to inspect real-time inspection updates, technician notes, and department assignments.
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (trackingInputId.trim()) {
                onOpenTrackModalWithId(trackingInputId.trim());
              }
            }}
            className="flex gap-2 mb-4"
          >
            <input
              type="text"
              value={trackingInputId}
              onChange={(e) => setTrackingInputId(e.target.value)}
              placeholder="e.g. C01, C03, CC-2026-0005..."
              className="flex-1 px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs sm:text-sm cursor-pointer shadow-sm"
            >
              Search
            </button>
          </form>

          <div className="text-xs text-slate-400">
            Quick Try: {['C01', 'C02', 'C03', 'C04'].map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => onOpenTrackModalWithId(id)}
                className="ml-2 font-mono text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                {id}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
