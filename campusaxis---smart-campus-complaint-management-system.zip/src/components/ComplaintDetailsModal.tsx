import React, { useState } from 'react';
import {
  X,
  MapPin,
  Clock,
  Shield,
  Building,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Send,
  RotateCcw,
  Star,
  ExternalLink,
  MessageSquare,
  Flame,
  Users,
  Zap,
  Sliders,
  ShieldAlert,
} from 'lucide-react';
import { Complaint, ComplaintStatus, UrgencyLevel } from '../types/complaint';
import { DEPARTMENTS, calculatePriorityScore } from '../constants/complaintData';
import { useLanguage } from '../context/LanguageContext';
import { getTranslatedCategory, getTranslatedStatus } from '../constants/translations';

interface ComplaintDetailsModalProps {
  complaint: Complaint | null;
  isOpen: boolean;
  onClose: () => void;
  isAdmin?: boolean;
  onUpdateComplaint?: (updated: Complaint) => void;
}

export const ComplaintDetailsModal: React.FC<ComplaintDetailsModalProps> = ({
  complaint,
  isOpen,
  onClose,
  isAdmin = false,
  onUpdateComplaint,
}) => {
  const { t, language } = useLanguage();
  if (!isOpen || !complaint) return null;

  // Admin edit states
  const [selectedStatus, setSelectedStatus] = useState<ComplaintStatus>(complaint.status);
  const [selectedDept, setSelectedDept] = useState(complaint.assignedDepartment || '');
  const [adminRemarkText, setAdminRemarkText] = useState(complaint.adminRemarks || '');
  const [isEscalatedState, setIsEscalatedState] = useState(Boolean(complaint.isEscalated));
  const [escalationReasonText, setEscalationReasonText] = useState(complaint.escalationReason || '');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Admin Priority Override states
  const [enablePriorityOverride, setEnablePriorityOverride] = useState(Boolean(complaint.isPriorityOverridden));
  const [targetUrgencyOverride, setTargetUrgencyOverride] = useState<UrgencyLevel>(
    complaint.overriddenUrgency || complaint.urgency || 'High'
  );
  const [priorityOverrideReasonText, setPriorityOverrideReasonText] = useState(
    complaint.priorityOverrideReason || ''
  );
  const [overrideError, setOverrideError] = useState('');

  // Student action states
  const [rating, setRating] = useState(complaint.feedback?.rating || 5);
  const [feedbackComment, setFeedbackComment] = useState(complaint.feedback?.comment || '');
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false);
  const [showReopenInput, setShowReopenInput] = useState(false);
  const [reopenReasonText, setReopenReasonText] = useState('');

  // Handle Admin Save
  const handleAdminSave = () => {
    if (!onUpdateComplaint) return;

    // Validate mandatory reason if priority override is active
    if (enablePriorityOverride) {
      if (!priorityOverrideReasonText.trim() || priorityOverrideReasonText.trim().length < 5) {
        setOverrideError('Mandatory reason required (at least 5 characters) for manual priority override.');
        return;
      }
    }
    setOverrideError('');

    const newTimeline = [...complaint.timeline];

    // Priority recalculation based on override or automatic factors
    const priorityCalc = calculatePriorityScore(
      complaint.category,
      complaint.createdAt,
      enablePriorityOverride ? targetUrgencyOverride : complaint.urgency,
      complaint.affectedScale,
      complaint.safetyHazard,
      enablePriorityOverride,
      targetUrgencyOverride
    );

    // If priority override state changed, record timeline
    if (enablePriorityOverride && (!complaint.isPriorityOverridden || complaint.overriddenUrgency !== targetUrgencyOverride || complaint.priorityOverrideReason !== priorityOverrideReasonText.trim())) {
      newTimeline.push({
        id: `t-prio-${Date.now()}`,
        status: selectedStatus,
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher (SATI Operations)',
        note: `Priority manually overridden to "${priorityCalc.priorityLabel}" (Score: ${priorityCalc.score}). Mandatory reason: "${priorityOverrideReasonText.trim()}"`,
      });
    } else if (!enablePriorityOverride && complaint.isPriorityOverridden) {
      newTimeline.push({
        id: `t-prio-rst-${Date.now()}`,
        status: selectedStatus,
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher (SATI Operations)',
        note: `Manual priority override removed. Reverted to automatic smart score (${priorityCalc.score} - ${priorityCalc.priorityLabel}).`,
      });
    }

    // If status changed, record timeline
    if (selectedStatus !== complaint.status) {
      newTimeline.push({
        id: `t-${Date.now()}`,
        status: selectedStatus,
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher (SATI Operations)',
        note: `Status updated to "${selectedStatus}". ${adminRemarkText ? `Remark: "${adminRemarkText}"` : ''}`,
      });
    } else if (adminRemarkText && adminRemarkText !== complaint.adminRemarks) {
      newTimeline.push({
        id: `t-${Date.now()}`,
        status: complaint.status,
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher',
        note: `Remark added: "${adminRemarkText}"`,
      });
    }

    const updated: Complaint = {
      ...complaint,
      status: selectedStatus,
      assignedDepartment: selectedDept || undefined,
      adminRemarks: adminRemarkText || undefined,
      isEscalated: isEscalatedState,
      escalatedAt: isEscalatedState ? (complaint.escalatedAt || new Date().toISOString()) : undefined,
      escalationReason: isEscalatedState ? escalationReasonText : undefined,
      resolvedAt: selectedStatus === 'Resolved' && !complaint.resolvedAt ? new Date().toISOString() : (selectedStatus !== 'Resolved' ? undefined : complaint.resolvedAt),
      // Smart Priority Engine fields
      priorityScore: priorityCalc.score,
      priorityLabel: priorityCalc.priorityLabel,
      priorityBreakdown: priorityCalc.breakdown,
      isPriorityOverridden: enablePriorityOverride,
      overriddenUrgency: enablePriorityOverride ? targetUrgencyOverride : undefined,
      overriddenScore: enablePriorityOverride ? priorityCalc.score : undefined,
      priorityOverrideReason: enablePriorityOverride ? priorityOverrideReasonText.trim() : undefined,
      priorityOverrideBy: enablePriorityOverride ? (complaint.priorityOverrideBy || 'SATI Administrator') : undefined,
      priorityOverrideAt: enablePriorityOverride ? (complaint.priorityOverrideAt || new Date().toISOString()) : undefined,
      timeline: newTimeline,
    };

    onUpdateComplaint(updated);
    setSaveSuccessMsg('Complaint details and dispatch updated successfully.');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  // Handle Student Feedback
  const handleStudentFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onUpdateComplaint) return;
    setIsSubmittingFeedback(true);

    const updated: Complaint = {
      ...complaint,
      feedback: {
        rating,
        comment: feedbackComment || 'Resolution verified by student.',
        createdAt: new Date().toISOString(),
      },
      timeline: [
        ...complaint.timeline,
        {
          id: `t-fb-${Date.now()}`,
          status: complaint.status,
          timestamp: new Date().toISOString(),
          actor: `${complaint.submittedBy.isAnonymous ? 'Anonymous Student' : complaint.submittedBy.name}`,
          note: `Student submitted ${rating}-star feedback: "${feedbackComment || 'Verified'}"`,
        },
      ],
    };

    onUpdateComplaint(updated);
    setIsSubmittingFeedback(false);
    setSaveSuccessMsg('Thank you for rating this resolution!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  // Handle Student Reopen Request
  const handleStudentReopen = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reopenReasonText.trim() || !onUpdateComplaint) return;

    const updated: Complaint = {
      ...complaint,
      status: 'In Progress',
      reopenRequested: true,
      reopenReason: reopenReasonText,
      timeline: [
        ...complaint.timeline,
        {
          id: `t-ro-${Date.now()}`,
          status: 'In Progress',
          timestamp: new Date().toISOString(),
          actor: `${complaint.submittedBy.isAnonymous ? 'Student' : complaint.submittedBy.name} (Reopen Request)`,
          note: `Reopened complaint: "${reopenReasonText}"`,
        },
      ],
    };

    onUpdateComplaint(updated);
    setShowReopenInput(false);
    setSaveSuccessMsg('Complaint reopened. Department notified for re-inspection.');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <span className="font-mono font-bold text-sm bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 px-3 py-1 rounded-md border border-blue-200 dark:border-blue-900">
              {complaint.id}
            </span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                    complaint.status === 'Resolved'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : complaint.status === 'In Progress'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                  }`}
                >
                  {complaint.status}
                </span>

                {/* Priority Label Badge */}
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                    complaint.priorityLabel === 'Critical'
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 ring-1 ring-rose-400/40'
                      : complaint.priorityLabel === 'High'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 ring-1 ring-amber-400/40'
                      : complaint.priorityLabel === 'Medium'
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300 ring-1 ring-blue-400/40'
                      : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 ring-1 ring-slate-400/30'
                  }`}
                >
                  <Zap className="w-3 h-3" />
                  {complaint.priorityLabel || 'Medium'} Priority ({complaint.priorityScore} pts)
                </span>

                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    complaint.urgency === 'Critical'
                      ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                      : complaint.urgency === 'High'
                      ? 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300'
                      : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  {complaint.urgency} Urgency
                </span>

                {complaint.isPriorityOverridden && (
                  <span className="text-xs bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ring-1 ring-purple-400/40">
                    <Sliders className="w-3 h-3" /> Admin Overridden
                  </span>
                )}

                {complaint.isEscalated && (
                  <span className="text-xs bg-red-600 text-white px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                    <Flame className="w-3 h-3" /> Escalated
                  </span>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Success Banner */}
          {saveSuccessMsg && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 rounded-xl text-xs font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              {saveSuccessMsg}
            </div>
          )}

          {/* Title & Core Details */}
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 leading-snug">
              {complaint.title}
            </h3>
            {complaint.customCategoryTitle && (
              <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 mb-2">
                Custom Problem Title: {complaint.customCategoryTitle}
              </div>
            )}
            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              {complaint.description}
            </p>
          </div>

          {/* Attached Image Evidence (if any) */}
          {complaint.imageUrl && (
            <div>
              <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
                <ExternalLink className="w-3.5 h-3.5 text-blue-500" />
                Image Evidence Attached
              </h5>
              <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-64 bg-slate-900/5 flex items-center justify-center">
                <img
                  src={complaint.imageUrl}
                  alt={complaint.title}
                  className="w-full h-full object-cover max-h-64 hover:scale-105 transition-transform duration-300"
                />
              </div>
            </div>
          )}

          {/* Smart Urgency-Based Priority Engine Calculation & Reason */}
          <div className="p-4 bg-gradient-to-br from-blue-50/80 via-indigo-50/50 to-slate-50 dark:from-blue-950/40 dark:via-indigo-950/30 dark:to-slate-900/40 border border-blue-200 dark:border-blue-900/70 rounded-xl space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                  Smart Urgency-Based Priority Calculation
                </span>
                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    complaint.priorityLabel === 'Critical'
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                      : complaint.priorityLabel === 'High'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      : complaint.priorityLabel === 'Medium'
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                      : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  {complaint.priorityLabel || 'Medium'} Priority
                </span>
              </div>
              <div className="font-mono text-sm font-extrabold text-indigo-700 dark:text-indigo-300 bg-white dark:bg-slate-900 px-3 py-1 rounded-lg border border-indigo-200 dark:border-indigo-800 shadow-xs">
                Score: {complaint.priorityScore} pts
              </div>
            </div>

            {/* Admin Override Alert if present */}
            {complaint.isPriorityOverridden && (
              <div className="p-2.5 bg-purple-50 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800 rounded-lg text-xs space-y-1">
                <div className="font-bold text-purple-900 dark:text-purple-200 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-purple-600" />
                  Manual Admin Priority Override Active
                </div>
                <p className="text-purple-800 dark:text-purple-300 text-[11px]">
                  <strong>Reason:</strong> "{complaint.priorityOverrideReason}"
                </p>
                <p className="text-[10px] text-purple-600 dark:text-purple-400">
                  Overridden by {complaint.priorityOverrideBy || 'Administrator'}{' '}
                  {complaint.priorityOverrideAt ? `on ${new Date(complaint.priorityOverrideAt).toLocaleDateString()}` : ''}
                </p>
              </div>
            )}

            {/* 5-Factor Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 text-center">
              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">1. Category</div>
                <div className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate mt-0.5" title={complaint.category}>
                  {complaint.category}
                </div>
                <div className="text-[11px] font-mono text-blue-600 dark:text-blue-400 font-bold">
                  +{complaint.priorityBreakdown?.categoryWeight ?? complaint.categoryWeight} pts
                </div>
              </div>

              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">2. Urgency</div>
                <div className="font-bold text-xs text-slate-800 dark:text-slate-200 mt-0.5">
                  {complaint.urgency}
                </div>
                <div className="text-[11px] font-mono text-indigo-600 dark:text-indigo-400 font-bold">
                  +{complaint.priorityBreakdown?.urgencyScore ?? 2} pts
                </div>
              </div>

              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">3. Age Elapsed</div>
                <div className="font-bold text-xs text-slate-800 dark:text-slate-200 mt-0.5">
                  {complaint.pendingHours}h
                </div>
                <div className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-bold">
                  +{complaint.priorityBreakdown?.ageBonus ?? Math.floor(complaint.pendingHours / 24)} pts
                </div>
              </div>

              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">4. Affected</div>
                <div className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate mt-0.5" title={complaint.affectedScale || 'Individual'}>
                  {complaint.affectedScale || 'Individual'}
                </div>
                <div className="text-[11px] font-mono text-purple-600 dark:text-purple-400 font-bold">
                  +{complaint.priorityBreakdown?.affectedScore ?? 0} pts
                </div>
              </div>

              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-800 col-span-2 sm:col-span-1">
                <div className="text-[10px] text-slate-500 uppercase font-semibold">5. Safety</div>
                <div className="font-bold text-xs text-slate-800 dark:text-slate-200 mt-0.5">
                  {complaint.safetyHazard ? 'Hazard Flag' : 'Standard'}
                </div>
                <div className={`text-[11px] font-mono font-bold ${complaint.safetyHazard ? 'text-red-600 dark:text-red-400' : 'text-slate-400'}`}>
                  +{complaint.priorityBreakdown?.safetyScore ?? (complaint.safetyHazard ? 3 : 0)} pts
                </div>
              </div>
            </div>

            {/* Explanation & Reason for Prioritization */}
            <div className="p-2.5 bg-white/70 dark:bg-slate-900/60 rounded-lg border border-slate-200/70 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300">
              <span className="font-semibold text-slate-900 dark:text-white">Reason for Prioritization: </span>
              {complaint.priorityBreakdown?.reason || (
                `Calculated from ${complaint.category} baseline (${complaint.categoryWeight} pts), ${complaint.urgency} urgency, ${complaint.pendingHours}h age, and safety assessment.`
              )}
            </div>
          </div>

          {/* Meta Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
              <div className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                Location Details
              </div>
              <div className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                <span>{complaint.location}</span>
              </div>
              {complaint.blockDetail && (
                <div className="text-slate-500 pl-6">Room/Block: {complaint.blockDetail}</div>
              )}
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
              <div className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                Reporter Details
              </div>
              <div className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200">
                <Shield className="w-4 h-4 text-slate-500 shrink-0" />
                <span>
                  {complaint.submittedBy.isAnonymous ? 'Anonymous Student (Identity Masked)' : complaint.submittedBy.name}
                </span>
              </div>
              <div className="text-slate-500 pl-6">
                {complaint.submittedBy.isAnonymous
                  ? 'Restricted by privacy policy'
                  : `${complaint.submittedBy.department} · ${complaint.submittedBy.rollNumber}`}
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
              <div className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                Department Handled
              </div>
              <div className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200">
                <Building className="w-4 h-4 text-slate-500 shrink-0" />
                <span>{complaint.assignedDepartment || 'Pending Assignment'}</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5">
              <div className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                Filing Date & Time
              </div>
              <div className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200">
                <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
                <span className="font-mono">
                  {new Date(complaint.createdAt).toLocaleString('en-IN', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  })}
                </span>
              </div>
            </div>
          </div>

          {/* Timeline Audit History */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">
              Complete Status History Timeline
            </h5>
            <div className="relative pl-6 space-y-4 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-200 dark:before:bg-slate-800">
              {complaint.timeline.map((event, idx) => (
                <div key={event.id || idx} className="relative">
                  <div
                    className={`absolute -left-6 top-1 w-6 h-6 rounded-full flex items-center justify-center text-xs ring-4 ring-white dark:ring-slate-900 ${
                      event.status === 'Resolved'
                        ? 'bg-emerald-600 text-white'
                        : event.status === 'In Progress'
                        ? 'bg-amber-500 text-white'
                        : 'bg-blue-600 text-white'
                    }`}
                  >
                    {event.status === 'Resolved' ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : (
                      <Clock className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {event.status}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {new Date(event.timestamp).toLocaleString('en-IN', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{event.note}</p>
                    <div className="text-[11px] text-slate-400 mt-1">Logged by: {event.actor}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Student Feedback Display */}
          {complaint.feedback && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-xl">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300">
                  Student Verification & Rating
                </span>
                <div className="flex text-amber-500">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${star <= complaint.feedback!.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-xs text-emerald-800 dark:text-emerald-200 italic">
                "{complaint.feedback.comment}"
              </p>
            </div>
          )}

          {/* Student Actions: Rate & Reopen (if viewing as Student on Resolved issue) */}
          {!isAdmin && complaint.status === 'Resolved' && (
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
              {!complaint.feedback ? (
                <form onSubmit={handleStudentFeedbackSubmit} className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200">
                    Was this issue resolved to your satisfaction?
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500">Rate resolution:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setRating(s)}
                          className="p-1 hover:scale-110 transition-transform cursor-pointer"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              s <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <input
                    type="text"
                    value={feedbackComment}
                    onChange={(e) => setFeedbackComment(e.target.value)}
                    placeholder="Optional feedback: e.g. 'Repaired on time, works perfectly.'"
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingFeedback}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" /> Submit Rating
                  </button>
                </form>
              ) : null}

              {/* Reopen Feature */}
              <div>
                {!showReopenInput ? (
                  <button
                    type="button"
                    onClick={() => setShowReopenInput(true)}
                    className="text-xs text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1.5 font-medium cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Problem persisting? Request to Reopen this complaint
                  </button>
                ) : (
                  <form onSubmit={handleStudentReopen} className="p-3 bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900 rounded-lg space-y-2">
                    <label className="text-xs font-bold text-rose-800 dark:text-rose-300 block">
                      Reason for Reopening:
                    </label>
                    <textarea
                      rows={2}
                      value={reopenReasonText}
                      onChange={(e) => setReopenReasonText(e.target.value)}
                      placeholder="Explain why the issue is still active or how it reoccurred..."
                      className="w-full p-2 text-xs bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-800 rounded-lg"
                      required
                    />
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        Confirm Reopen
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowReopenInput(false)}
                        className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}

          {/* Admin Control Panel (when viewed by Admin) */}
          {isAdmin && (
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border-2 border-dashed border-blue-300 dark:border-blue-900 rounded-xl space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-blue-800 dark:text-blue-300 flex items-center gap-2">
                <Building className="w-4 h-4 text-blue-600" />
                Administrative Dispatch & Status Control
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Status Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Update Status
                  </label>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value as ComplaintStatus)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium"
                  >
                    <option value="Raised">Raised</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>

                {/* Department Assign */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Assigned Department
                  </label>
                  <select
                    value={selectedDept}
                    onChange={(e) => setSelectedDept(e.target.value)}
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-medium"
                  >
                    <option value="">-- Unassigned --</option>
                    {DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Smart Priority Manual Override Section */}
              <div className="p-3.5 bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/60 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-purple-600" />
                      Smart Priority Manual Override
                    </div>
                    <p className="text-[11px] text-purple-700 dark:text-purple-400">
                      Override automatic score rank (e.g., VIP inspection, recurring outage, emergency safety).
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enablePriorityOverride}
                      onChange={(e) => {
                        setEnablePriorityOverride(e.target.checked);
                        if (!e.target.checked) setOverrideError('');
                      }}
                      className="w-4 h-4 text-purple-600 rounded cursor-pointer"
                    />
                    <span className="ml-2 text-xs font-semibold text-purple-900 dark:text-purple-300">
                      {enablePriorityOverride ? 'Active' : 'Disabled'}
                    </span>
                  </label>
                </div>

                {enablePriorityOverride && (
                  <div className="space-y-2.5 pt-1">
                    <div>
                      <label className="block text-xs font-semibold text-purple-900 dark:text-purple-300 mb-1">
                        Override Priority Target
                      </label>
                      <div className="grid grid-cols-4 gap-2">
                        {(['Critical', 'High', 'Medium', 'Low'] as UrgencyLevel[]).map((lvl) => (
                          <button
                            key={lvl}
                            type="button"
                            onClick={() => setTargetUrgencyOverride(lvl)}
                            className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                              targetUrgencyOverride === lvl
                                ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-purple-300'
                            }`}
                          >
                            {lvl}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-purple-900 dark:text-purple-300 mb-1">
                        Mandatory Override Justification Reason <span className="text-rose-500">*</span>
                      </label>
                      <textarea
                        rows={2}
                        value={priorityOverrideReasonText}
                        onChange={(e) => {
                          setPriorityOverrideReasonText(e.target.value);
                          if (e.target.value.trim().length >= 5) setOverrideError('');
                        }}
                        placeholder="State why this complaint's priority is being manually modified..."
                        className="w-full p-2 bg-white dark:bg-slate-900 border border-purple-200 dark:border-purple-800 rounded-lg text-xs"
                      />
                      {overrideError && (
                        <p className="text-[11px] text-rose-600 dark:text-rose-400 font-semibold mt-1">
                          {overrideError}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Remarks */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                  Official Admin Remark / Technical Inspection Note
                </label>
                <textarea
                  rows={2}
                  value={adminRemarkText}
                  onChange={(e) => setAdminRemarkText(e.target.value)}
                  placeholder="e.g. Technician dispatched, parts ordered, or work completed..."
                  className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                />
              </div>

              {/* Escalation Toggle */}
              <div className="p-3 bg-red-50/50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/60 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-red-900 dark:text-red-300 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    Escalate to High Priority / Dean Committee
                  </div>
                  <p className="text-[11px] text-red-700 dark:text-red-400">
                    Flag this issue for emergency oversight or long-pending breach.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={isEscalatedState}
                  onChange={(e) => setIsEscalatedState(e.target.checked)}
                  className="w-4 h-4 text-red-600 rounded cursor-pointer"
                />
              </div>

              {isEscalatedState && (
                <div>
                  <label className="block text-xs font-semibold text-red-800 dark:text-red-300 mb-1">
                    Escalation Reason
                  </label>
                  <input
                    type="text"
                    value={escalationReasonText}
                    onChange={(e) => setEscalationReasonText(e.target.value)}
                    placeholder="Reason for escalation..."
                    className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-red-200 dark:border-red-800 rounded-lg text-xs"
                  />
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleAdminSave}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-sm flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Save Changes & Log Audit
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-mono">
            ID: {complaint.id} · Ref: SATI-AXIS-{complaint.id}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
