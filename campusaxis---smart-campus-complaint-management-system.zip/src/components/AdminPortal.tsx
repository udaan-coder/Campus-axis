import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Filter,
  Download,
  AlertTriangle,
  Clock,
  CheckCircle2,
  RefreshCw,
  Plus,
  Building,
  User,
  ArrowUpDown,
  Flame,
  MoreVertical,
  ExternalLink,
  Tag,
  MapPin,
  EyeOff,
  Star,
  Zap,
  Sliders,
  Check,
  X,
  Sparkles,
  Users,
} from 'lucide-react';
import {
  Complaint,
  ComplaintCategory,
  ComplaintStatus,
  UrgencyLevel,
} from '../types/complaint';
import {
  DEPARTMENTS,
  CAMPUS_LOCATIONS,
  calculatePriorityScore,
} from '../constants/complaintData';
import { exportComplaintsToCSV, getAllPriorityQueue } from '../services/storage';
import { CurrentUserSession } from '../types/auth';
import { useLanguage } from '../context/LanguageContext';
import {
  getTranslatedCategory,
  getTranslatedStatus,
  getTranslatedUrgency,
} from '../constants/translations';

interface AdminPortalProps {
  complaints: Complaint[];
  onUpdateComplaint: (complaint: Complaint) => void;
  onClearAllData: () => void;
  onLoadBenchmarkSamples: () => void;
  onAddQuickDemoComplaint: () => void;
  onSelectComplaint: (complaint: Complaint) => void;
  onOpenTrackModalWithId: (id: string) => void;
  currentUserSession?: CurrentUserSession | null;
  onOpenAdminManagement?: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  complaints,
  onUpdateComplaint,
  onClearAllData,
  onLoadBenchmarkSamples,
  onAddQuickDemoComplaint,
  onSelectComplaint,
  onOpenTrackModalWithId,
  currentUserSession,
  onOpenAdminManagement,
}) => {
  const { t, language } = useLanguage();

  // View mode: 'queue' (Smart Priority Queue) or 'table' (All Complaints Table)
  const [adminViewMode, setAdminViewMode] = useState<'queue' | 'table'>('queue');

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<'all' | UrgencyLevel>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'priority' | 'newest' | 'oldest'>('priority');

  // Feedback notifications
  const [statusNotification, setStatusNotification] = useState<string>('');

  // Manual Override State for a specific complaint
  const [overrideModalComplaint, setOverrideModalComplaint] = useState<Complaint | null>(null);
  const [overrideUrgency, setOverrideUrgency] = useState<UrgencyLevel>('Critical');
  const [overrideReason, setOverrideReason] = useState<string>('');
  const [overrideError, setOverrideError] = useState<string>('');

  // 1. Smart Priority Queue:
  // Resolved complaints MUST NEVER appear in the active priority queue.
  // Sorted automatically from highest to lowest priority score; tie-broken by older complaint first.
  const allUnresolvedQueue = getAllPriorityQueue(complaints);

  // Filter the Priority Queue by priority level and search
  const filteredPriorityQueue = allUnresolvedQueue.filter((c) => {
    // Priority filter (Critical, High, Medium, Low)
    if (priorityFilter !== 'all') {
      const currentLabel = c.priorityLabel || c.urgency;
      if (currentLabel !== priorityFilter) return false;
    }
    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        c.id.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q) ||
        (!c.submittedBy.isAnonymous && c.submittedBy.name.toLowerCase().includes(q)) ||
        (c.assignedDepartment && c.assignedDepartment.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  // Overall Statistics
  const totalCount = complaints.length;
  const pendingCount = complaints.filter((c) => c.status === 'Raised').length;
  const inProgressCount = complaints.filter((c) => c.status === 'In Progress').length;
  const resolvedCount = complaints.filter((c) => c.status === 'Resolved').length;
  const criticalCount = complaints.filter(
    (c) => (c.priorityLabel === 'Critical' || c.urgency === 'Critical') && c.status !== 'Resolved'
  ).length;

  // Average Resolution Time in hours for resolved complaints (0 when no resolved issues exist)
  const resolvedWithTime = complaints.filter((c) => c.status === 'Resolved' && c.resolvedAt);
  const avgResolutionHours =
    resolvedWithTime.length > 0
      ? Math.round(
          resolvedWithTime.reduce((sum, c) => {
            const diff = new Date(c.resolvedAt!).getTime() - new Date(c.createdAt).getTime();
            return sum + Math.max(1, Math.floor(diff / (1000 * 60 * 60)));
          }, 0) / resolvedWithTime.length
        )
      : 0;

  // Filter complaints for Table Registry
  const filteredTableComplaints = complaints.filter((c) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        c.id.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q) ||
        (!c.submittedBy.isAnonymous && c.submittedBy.name.toLowerCase().includes(q)) ||
        (c.assignedDepartment && c.assignedDepartment.toLowerCase().includes(q));
      if (!match) return false;
    }
    if (priorityFilter !== 'all') {
      const currentLabel = c.priorityLabel || c.urgency;
      if (currentLabel !== priorityFilter) return false;
    }
    if (selectedCategory !== 'all' && c.category !== selectedCategory) return false;
    if (selectedStatus !== 'all' && c.status !== selectedStatus) return false;
    if (selectedDept !== 'all') {
      if (selectedDept === 'unassigned') {
        if (c.assignedDepartment) return false;
      } else if (c.assignedDepartment !== selectedDept) {
        return false;
      }
    }
    return true;
  });

  // Sort complaints for Table Registry
  const sortedTableComplaints = [...filteredTableComplaints].sort((a, b) => {
    if (sortBy === 'priority') {
      if (b.priorityScore !== a.priorityScore) {
        return b.priorityScore - a.priorityScore;
      }
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    }
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });

  // Handle Quick Status Change
  const handleQuickStatusChange = (complaint: Complaint, newStatus: ComplaintStatus) => {
    if (newStatus === complaint.status) return;

    const newTimeline = [...complaint.timeline];
    newTimeline.push({
      id: `t-admin-${Date.now()}`,
      status: newStatus,
      timestamp: new Date().toISOString(),
      actor: 'Admin Dispatcher',
      note: `Status updated to ${newStatus}.`,
    });

    const updated: Complaint = {
      ...complaint,
      status: newStatus,
      resolvedAt: newStatus === 'Resolved' && !complaint.resolvedAt ? new Date().toISOString() : complaint.resolvedAt,
      timeline: newTimeline,
    };

    onUpdateComplaint(updated);
    setStatusNotification(`Updated ${complaint.id} to ${newStatus}`);
    setTimeout(() => setStatusNotification(''), 3000);
  };

  // Handle Quick Department Change
  const handleQuickDeptChange = (complaint: Complaint, dept: string) => {
    const updated: Complaint = {
      ...complaint,
      assignedDepartment: dept || undefined,
    };
    onUpdateComplaint(updated);
    setStatusNotification(`Assigned ${complaint.id} to ${dept}`);
    setTimeout(() => setStatusNotification(''), 3000);
  };

  // Handle Manual Priority Override Confirmation (Requirement 8)
  const handleConfirmPriorityOverride = (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideModalComplaint) return;

    if (!overrideReason.trim()) {
      setOverrideError('A mandatory reason is required to manually override priority.');
      return;
    }
    if (overrideReason.trim().length < 5) {
      setOverrideError('Please provide a substantive reason (at least 5 characters).');
      return;
    }
    setOverrideError('');

    // Recompute with overridden urgency
    const calc = calculatePriorityScore(
      overrideModalComplaint.category,
      overrideModalComplaint.createdAt,
      overrideUrgency,
      overrideModalComplaint.affectedScale,
      overrideModalComplaint.safetyHazard,
      true,
      overrideUrgency
    );

    const nowIso = new Date().toISOString();
    const newTimeline = [
      ...overrideModalComplaint.timeline,
      {
        id: `t-override-${Date.now()}`,
        status: overrideModalComplaint.status,
        timestamp: nowIso,
        actor: 'Admin Dispatcher (Manual Override)',
        note: `Priority manually overridden to ${overrideUrgency} (Score: ${calc.score}). Reason: "${overrideReason.trim()}".`,
      },
    ];

    const updated: Complaint = {
      ...overrideModalComplaint,
      isPriorityOverridden: true,
      overriddenUrgency: overrideUrgency,
      priorityOverrideReason: overrideReason.trim(),
      priorityOverrideAt: nowIso,
      priorityOverrideBy: 'Admin Dispatcher',
      priorityScore: calc.score,
      priorityLabel: calc.priorityLabel,
      priorityBreakdown: {
        categoryWeight: calc.categoryWeight,
        urgencyScore: calc.urgencyScore,
        ageBonus: calc.ageDays,
        affectedScore: calc.affectedScore,
        safetyScore: calc.safetyScore,
        totalScore: calc.score,
        priorityLabel: calc.priorityLabel,
        reason: calc.reason,
      },
      timeline: newTimeline,
    };

    onUpdateComplaint(updated);
    setOverrideModalComplaint(null);
    setOverrideReason('');
    setStatusNotification(`Priority overridden for ${overrideModalComplaint.id} → ${overrideUrgency} (Score ${calc.score})`);
    setTimeout(() => setStatusNotification(''), 3500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Control Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          {currentUserSession && (
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100/80 dark:bg-blue-950/80 border border-blue-200 dark:border-blue-900 text-blue-900 dark:text-blue-300 text-xs font-semibold mb-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{t.navLoggedInAs}: <strong>{currentUserSession.fullName}</strong></span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-blue-200 dark:bg-blue-900">
                {currentUserSession.adminRole || 'Super Admin'}
              </span>
              <span className="text-slate-500 dark:text-slate-400">· {currentUserSession.department}</span>
            </div>
          )}

          <div className="flex items-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>SATI Operations & Maintenance Dispatch Control Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t.adminPortalTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {t.adminPortalSubtitle}
          </p>
        </div>

        {/* Global Admin Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {currentUserSession && onOpenAdminManagement && (
            <button
              onClick={onOpenAdminManagement}
              className="px-3.5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
              title="Manage administrator authorizations"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{t.btnManageAdmins}</span>
            </button>
          )}

          <button
            onClick={() => exportComplaintsToCSV(complaints)}
            className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download CSV report of all campus complaints"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
          <button
            onClick={onAddQuickDemoComplaint}
            className="px-3.5 py-2 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Inject a realistic demonstration complaint"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Demo Issue
          </button>
          <button
            onClick={() => {
              if (window.confirm('Load official benchmark sample complaints (C01, C02, C03, C04) for testing?')) {
                onLoadBenchmarkSamples();
              }
            }}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Load official baseline samples for testing"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Load Samples
          </button>
          {complaints.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Clear all complaint records from the system and reset all statistics to 0?')) {
                  onClearAllData();
                }
              }}
              className="px-3 py-2 bg-rose-50 dark:bg-rose-950/50 hover:bg-rose-100 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Clear all records and reset dashboard"
            >
              Clear All Data (0)
            </button>
          )}
        </div>
      </div>

      {/* Inline Feedback Banner */}
      {statusNotification && (
        <div className="p-3 bg-blue-50 dark:bg-blue-950/70 border border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300 rounded-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
          {statusNotification}
        </div>
      )}

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
            Total Issues
          </div>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono">
            {totalCount}
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1">
            Pending (Raised)
          </div>
          <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">
            {pendingCount}
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-1">
            In Progress
          </div>
          <div className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 font-mono">
            {inProgressCount}
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-1">
            Resolved
          </div>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
            {resolvedCount}
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400 mb-1">
            Critical Priority
          </div>
          <div className="text-2xl font-extrabold text-red-600 dark:text-red-400 font-mono">
            {criticalCount}
          </div>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
          <div className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-1">
            Avg Resolve Time
          </div>
          <div className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400 font-mono">
            {avgResolutionHours}h
          </div>
        </div>
      </div>

      {/* Main View Mode Selector: Smart Priority Queue vs. Complaints Table */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-xl">
          <button
            onClick={() => setAdminViewMode('queue')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
              adminViewMode === 'queue'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Zap className="w-4 h-4" />
            {t.tabSmartQueue}
            <span
              className={`px-1.5 py-0.2 rounded-full text-[11px] font-mono ${
                adminViewMode === 'queue' ? 'bg-white/20 text-white' : 'bg-slate-300 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {allUnresolvedQueue.length}
            </span>
          </button>
          <button
            onClick={() => setAdminViewMode('table')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer ${
              adminViewMode === 'table'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Building className="w-4 h-4" />
            {t.tabAllComplaints}
            <span
              className={`px-1.5 py-0.2 rounded-full text-[11px] font-mono ${
                adminViewMode === 'table' ? 'bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white' : 'bg-slate-300 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {complaints.length}
            </span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 font-mono">
          <span>Tie-Breaker:</span>
          <span className="font-semibold text-slate-700 dark:text-slate-300">Higher Score → Older Complaint First</span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. SEPARATE SMART PRIORITY QUEUE VIEW (Requirement 3, 4, 5, 6, 7, 8, 9)   */}
      {/* ========================================================================= */}
      {adminViewMode === 'queue' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Priority Queue Filter Strip */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Priority Filter Tabs: Critical, High, Medium, Low (Requirement 9) */}
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-1">
                Priority:
              </span>
              {(['all', 'Critical', 'High', 'Medium', 'Low'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setPriorityFilter(lvl)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    priorityFilter === lvl
                      ? lvl === 'Critical'
                        ? 'bg-red-600 text-white shadow-xs'
                        : lvl === 'High'
                        ? 'bg-orange-500 text-white shadow-xs'
                        : lvl === 'Medium'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : lvl === 'Low'
                        ? 'bg-slate-700 text-white shadow-xs'
                        : 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {lvl === 'all' ? 'All Unresolved' : lvl}
                  {lvl !== 'all' && (
                    <span className="ml-1.5 opacity-80 font-mono text-[10px]">
                      ({allUnresolvedQueue.filter((c) => (c.priorityLabel || c.urgency) === lvl).length})
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Queue Search */}
            <div className="relative w-full md:w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search active queue by ID, keyword..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 font-mono"
              />
            </div>
          </div>

          {/* Unresolved Queue Cards List */}
          {filteredPriorityQueue.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center shadow-xs">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
                <Clock className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                Smart Priority Queue is Empty
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
                No unresolved complaints match your filter. Resolved tickets are automatically excluded from this active queue.
              </p>
              {complaints.length === 0 && (
                <div className="flex justify-center gap-2">
                  <button
                    onClick={onAddQuickDemoComplaint}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    Add Demo Issue for Testing
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPriorityQueue.map((c, index) => {
                const priorityBadge = c.priorityLabel || c.urgency;
                const isOverridden = Boolean(c.isPriorityOverridden);

                return (
                  <div
                    key={c.id}
                    className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 shadow-xs transition-all hover:border-blue-400 dark:hover:border-blue-600 ${
                      priorityBadge === 'Critical'
                        ? 'border-red-200 dark:border-red-900/60'
                        : priorityBadge === 'High'
                        ? 'border-orange-200 dark:border-orange-900/60'
                        : 'border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {/* Header Row: Rank, ID, Priority Label, Urgency, Total Score */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Queue Rank */}
                        <span className="w-7 h-7 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-extrabold text-xs flex items-center justify-center font-mono">
                          #{index + 1}
                        </span>

                        {/* Complaint ID */}
                        <span className="font-mono font-bold text-xs bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 px-2.5 py-1 rounded border border-blue-200 dark:border-blue-900">
                          {c.id}
                        </span>

                        {/* Priority Label (Requirement 5) */}
                        <span
                          className={`text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider ${
                            priorityBadge === 'Critical'
                              ? 'bg-red-600 text-white'
                              : priorityBadge === 'High'
                              ? 'bg-orange-500 text-white'
                              : priorityBadge === 'Medium'
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-700 text-white'
                          }`}
                        >
                          {priorityBadge} Priority
                        </span>

                        {/* Urgency Badge */}
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          Urgency: {c.urgency}
                        </span>

                        {/* Override Indicator */}
                        {isOverridden && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 border border-purple-200 dark:border-purple-800 flex items-center gap-1">
                            <Sliders className="w-3 h-3" /> Overridden
                          </span>
                        )}

                        {c.safetyHazard && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-100 dark:bg-red-950 text-red-800 dark:text-red-300 border border-red-200 dark:border-red-800 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-red-600" /> Hazard
                          </span>
                        )}
                      </div>

                      {/* Total Priority Score & Age */}
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-xs text-slate-500 font-medium block">
                            Priority Score
                          </span>
                          <span className="text-xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">
                            {c.priorityScore}
                          </span>
                        </div>
                        <div className="text-right pl-3 border-l border-slate-200 dark:border-slate-800">
                          <span className="text-xs text-slate-500 font-medium block">
                            Complaint Age
                          </span>
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                            {c.pendingHours}h ago
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Middle: Title, Description, Location */}
                    <div className="py-3">
                      <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                        {c.title}
                      </h3>
                      <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-3 line-clamp-2">
                        {c.description}
                      </p>

                      {/* 5-Factor Score Breakdown Chips & Reason for Prioritization (Requirement 5) */}
                      <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
                        <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono">
                          <span className="font-semibold text-slate-700 dark:text-slate-300">
                            Calculation:
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                            Category Weight: <strong>+{c.categoryWeight}</strong>
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                            Urgency Score: <strong>+{c.priorityBreakdown?.urgencyScore ?? 2}</strong>
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                            Age Bonus: <strong>+{Math.floor(c.pendingHours / 24)}</strong>
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                            Scope: <strong>+{c.priorityBreakdown?.affectedScore ?? 0}</strong> ({c.affectedScale || 'Individual'})
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                            Safety Hazard: <strong>+{c.priorityBreakdown?.safetyScore ?? 0}</strong>
                          </span>
                        </div>

                        {/* Reason for Prioritization */}
                        <div className="text-xs text-slate-600 dark:text-slate-400">
                          <strong className="text-slate-800 dark:text-slate-200">Prioritization Reason: </strong>
                          <span>{c.priorityBreakdown?.reason || `Category weight ${c.categoryWeight} with ${c.pendingHours}h age bonus.`}</span>
                        </div>

                        {/* If Overridden: Show Mandatory Reason (Requirement 8) */}
                        {isOverridden && c.priorityOverrideReason && (
                          <div className="p-2 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-lg text-xs text-purple-900 dark:text-purple-200">
                            <strong>Admin Override Reason: </strong>
                            <span>"{c.priorityOverrideReason}"</span>
                            <span className="text-[10px] text-purple-500 block mt-0.5">
                              Overridden by {c.priorityOverrideBy || 'Admin'} on {new Date(c.priorityOverrideAt || '').toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Location & Department */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 text-xs text-slate-500">
                        <div className="flex items-center gap-1.5 truncate">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{c.location}</span>
                        </div>
                        <div className="flex items-center gap-1.5 truncate">
                          <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">Dept: {c.assignedDepartment || 'Unassigned'}</span>
                        </div>
                        <div className="flex items-center gap-1.5 truncate">
                          <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">Reporter: {c.submittedBy.isAnonymous ? 'Anonymous' : c.submittedBy.name}</span>
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions: Override Priority, Status, Assign, Details */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Manual Priority Override Trigger (Requirement 8) */}
                        <button
                          type="button"
                          onClick={() => {
                            setOverrideModalComplaint(c);
                            setOverrideUrgency(c.overriddenUrgency || c.urgency);
                            setOverrideReason(c.priorityOverrideReason || '');
                            setOverrideError('');
                          }}
                          className="px-3 py-1.5 bg-purple-50 dark:bg-purple-950/60 hover:bg-purple-100 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-900 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <Sliders className="w-3.5 h-3.5" />
                          Override Priority
                        </button>

                        {/* Quick Department Select */}
                        <select
                          value={c.assignedDepartment || ''}
                          onChange={(e) => handleQuickDeptChange(c, e.target.value)}
                          className="text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg max-w-[180px] truncate"
                        >
                          <option value="">-- Assign Dept --</option>
                          {DEPARTMENTS.map((dept) => (
                            <option key={dept} value={dept}>
                              {dept}
                            </option>
                          ))}
                        </select>

                        {/* Quick Status Select */}
                        <select
                          value={c.status}
                          onChange={(e) => handleQuickStatusChange(c, e.target.value as ComplaintStatus)}
                          className={`text-xs font-semibold px-2.5 py-1.5 rounded-lg border cursor-pointer ${
                            c.status === 'In Progress'
                              ? 'bg-amber-50 text-amber-800 border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                              : 'bg-blue-50 text-blue-800 border-blue-300 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800'
                          }`}
                        >
                          <option value="Raised">Raised</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Resolved">Resolved (Exit Queue)</option>
                        </select>
                      </div>

                      <button
                        onClick={() => onSelectComplaint(c)}
                        className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        Inspect Details →
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ALL COMPLAINTS MANAGEMENT REGISTRY (TABLE VIEW)                        */}
      {/* ========================================================================= */}
      {adminViewMode === 'table' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden animate-in fade-in duration-150">
          {/* Table Toolbar */}
          <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  All Campus Complaints Registry ({sortedTableComplaints.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Filter by category, status, priority, or department.
                </p>
              </div>

              {/* Live Search */}
              <div className="relative w-full lg:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by ID, keyword, location, or reporter..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Filter Dropdowns Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
              {/* Category Filter */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Category
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                >
                  <option value="all">All Categories</option>
                  <option value="Internet & Wi-Fi">Internet & Wi-Fi</option>
                  <option value="Hostel Issues">Hostel Issues</option>
                  <option value="Classroom Issues">Classroom Issues</option>
                  <option value="Laboratory Issues">Laboratory Issues</option>
                  <option value="Cleanliness & Sanitation">Cleanliness & Sanitation</option>
                  <option value="Water & Electricity">Water & Electricity</option>
                  <option value="Campus Infrastructure">Campus Infrastructure</option>
                  <option value="Security & Safety">Security & Safety</option>
                  <option value="Other / Describe Your Own Problem">Custom Problem</option>
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Status
                </label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                >
                  <option value="all">All Statuses</option>
                  <option value="Raised">Raised</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                </select>
              </div>

              {/* Priority Filter (Requirement 9) */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Priority Filter
                </label>
                <select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-semibold"
                >
                  <option value="all">All Priorities</option>
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              {/* Department Filter */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Department
                </label>
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs"
                >
                  <option value="all">All Departments</option>
                  <option value="unassigned">-- Unassigned --</option>
                  {DEPARTMENTS.slice(0, 6).map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {/* Sort Order */}
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                  Sort Order
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs font-semibold"
                >
                  <option value="priority">Priority Score (High-to-Low)</option>
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                </select>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                  <th className="py-3 px-4">Complaint ID</th>
                  <th className="py-3 px-4">Title & Category</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4 text-center">Score</th>
                  <th className="py-3 px-4">Priority Label</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Assigned Department</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70 font-sans">
                {sortedTableComplaints.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      No complaint records match the selected filter criteria.
                    </td>
                  </tr>
                ) : (
                  sortedTableComplaints.map((c) => {
                    const priorityBadge = c.priorityLabel || c.urgency;
                    return (
                      <tr
                        key={c.id}
                        className="hover:bg-slate-50 dark:hover:bg-slate-850/50 transition-colors"
                      >
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="font-mono font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-900">
                            {c.id}
                          </span>
                        </td>
                        <td className="py-3 px-4 max-w-xs">
                          <div className="font-semibold text-slate-900 dark:text-white line-clamp-1">
                            {c.title}
                          </div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-1">
                            <span>{c.category}</span>
                            <span>·</span>
                            <span>{c.pendingHours}h ago</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap text-slate-600 dark:text-slate-300">
                          <div className="truncate max-w-[150px]">{c.location}</div>
                        </td>
                        <td className="py-3 px-4 text-center whitespace-nowrap font-mono font-extrabold text-xs">
                          {c.priorityScore}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                              priorityBadge === 'Critical'
                                ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                                : priorityBadge === 'High'
                                ? 'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300'
                                : priorityBadge === 'Medium'
                                ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                                : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                            }`}
                          >
                            {priorityBadge}
                          </span>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <select
                            value={c.status}
                            onChange={(e) => handleQuickStatusChange(c, e.target.value as ComplaintStatus)}
                            className="text-xs font-semibold px-2 py-1 rounded-lg border cursor-pointer"
                          >
                            <option value="Raised">Raised</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                          </select>
                        </td>
                        <td className="py-3 px-4 max-w-[180px]">
                          <select
                            value={c.assignedDepartment || ''}
                            onChange={(e) => handleQuickDeptChange(c, e.target.value)}
                            className="w-full text-xs px-2 py-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg truncate"
                          >
                            <option value="">-- Unassigned --</option>
                            {DEPARTMENTS.map((dept) => (
                              <option key={dept} value={dept}>
                                {dept}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <button
                            onClick={() => onSelectComplaint(c)}
                            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                          >
                            Inspect
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MANUAL PRIORITY OVERRIDE MODAL (Requirement 8)                            */}
      {/* ========================================================================= */}
      {overrideModalComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Manual Priority Override
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setOverrideModalComplaint(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <p className="text-xs text-slate-500 mb-2">
                Complaint: <strong className="font-mono text-blue-600">{overrideModalComplaint.id}</strong> — "{overrideModalComplaint.title}"
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Current Priority Score: <strong className="font-mono">{overrideModalComplaint.priorityScore}</strong> ({overrideModalComplaint.priorityLabel || overrideModalComplaint.urgency})
              </p>
            </div>

            {overrideError && (
              <div className="p-2.5 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 rounded-xl text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                {overrideError}
              </div>
            )}

            <form onSubmit={handleConfirmPriorityOverride} className="space-y-4">
              {/* Select Override Level */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                  1. Set New Priority Level *
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['Critical', 'High', 'Medium', 'Low'] as UrgencyLevel[]).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setOverrideUrgency(lvl)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                        overrideUrgency === lvl
                          ? lvl === 'Critical'
                            ? 'bg-red-600 text-white border-red-600'
                            : lvl === 'High'
                            ? 'bg-orange-500 text-white border-orange-500'
                            : lvl === 'Medium'
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-700 text-white border-slate-700'
                          : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mandatory Reason for Override (Requirement 8) */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                  2. Mandatory Reason for Override *
                </label>
                <textarea
                  rows={3}
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="Explain why this priority is being manually overridden (e.g. On-site inspection revealed exposed 220V cables / Direct instruction from Dean office)..."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-purple-600"
                  required
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  * A written audit explanation is strictly mandatory for all manual overrides.
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setOverrideModalComplaint(null)}
                  className="px-4 py-2 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  Confirm Override
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
