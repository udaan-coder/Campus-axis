import React, { useState } from 'react';
import { Search, X, CheckCircle2, Clock, AlertTriangle, ArrowRight, ShieldCheck, MapPin, Building, Tag } from 'lucide-react';
import { Complaint } from '../types/complaint';
import { useLanguage } from '../context/LanguageContext';
import { getTranslatedCategory, getTranslatedStatus } from '../constants/translations';

interface TrackModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaints: Complaint[];
  initialComplaintId?: string;
  onSelectComplaint?: (complaint: Complaint) => void;
}

export const TrackModal: React.FC<TrackModalProps> = ({
  isOpen,
  onClose,
  complaints,
  initialComplaintId = '',
  onSelectComplaint,
}) => {
  const { t, language } = useLanguage();
  const [searchId, setSearchId] = useState(initialComplaintId);
  const [foundComplaint, setFoundComplaint] = useState<Complaint | null>(
    complaints.find((c) => c.id.toLowerCase() === initialComplaintId.toLowerCase()) || null
  );
  const [hasSearched, setHasSearched] = useState(Boolean(initialComplaintId));

  if (!isOpen) return null;

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchId.trim().toLowerCase();
    setHasSearched(true);
    if (!query) {
      setFoundComplaint(null);
      return;
    }
    const match = complaints.find(
      (c) => c.id.toLowerCase() === query || c.title.toLowerCase().includes(query)
    );
    setFoundComplaint(match || null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Search className="w-5 h-5 text-blue-600" />
              {t.navTrackIssue}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {language === 'hi' ? 'अपनी विशिष्ट शिकायत संदर्भ आईडी दर्ज करें (जैसे C01, CC-2026-0001)' : 'Enter your unique complaint reference ID (e.g. C01, CC-2026-0001)'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800/80">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                placeholder="Enter Complaint ID (e.g., C01, C03, CC-2026-0005)..."
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-slate-100 placeholder:text-slate-400 font-mono"
                autoFocus
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-colors flex items-center gap-2 shrink-0 cursor-pointer shadow-sm"
            >
              Track Now
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Suggestions */}
          <div className="flex items-center gap-2 mt-3 text-xs text-slate-500">
            <span>Try sample IDs:</span>
            {['C01', 'C02', 'C03', 'C04', 'CC-2026-0005'].map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  setSearchId(id);
                  const m = complaints.find((c) => c.id.toLowerCase() === id.toLowerCase());
                  setFoundComplaint(m || null);
                  setHasSearched(true);
                }}
                className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 rounded hover:bg-blue-50 dark:hover:bg-slate-700 transition-colors font-mono cursor-pointer"
              >
                {id}
              </button>
            ))}
          </div>
        </div>

        {/* Result Area */}
        <div className="flex-1 overflow-y-auto p-6">
          {foundComplaint ? (
            <div className="space-y-6">
              {/* Header Card */}
              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl">
                <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-1 rounded border border-blue-200 dark:border-blue-900">
                      {foundComplaint.id}
                    </span>
                    <span
                      className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                        foundComplaint.status === 'Resolved'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : foundComplaint.status === 'In Progress'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                      }`}
                    >
                      {foundComplaint.status}
                    </span>
                    {foundComplaint.isEscalated && (
                      <span className="text-xs font-semibold px-2 py-0.5 bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 rounded-full flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> Escalated
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 font-mono">
                    Priority Score: <strong className="text-slate-800 dark:text-slate-200">{foundComplaint.priorityScore}</strong> · Age: {foundComplaint.pendingHours}h
                  </div>
                </div>

                <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  {foundComplaint.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 mb-3 leading-relaxed">
                  {foundComplaint.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-3 border-t border-slate-200 dark:border-slate-800 text-slate-500">
                  <div className="flex items-center gap-1.5 truncate">
                    <Tag className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{foundComplaint.category}</span>
                  </div>
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{foundComplaint.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5 truncate">
                    <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{foundComplaint.assignedDepartment || 'Pending Assignment'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Reported by: {foundComplaint.submittedBy.isAnonymous ? 'Anonymous Student' : foundComplaint.submittedBy.name}</span>
                  </div>
                </div>
              </div>

              {/* Status Progress Stepper */}
              <div>
                <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">
                  Resolution Progress
                </h5>
                <div className="relative pl-6 space-y-6 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-200 dark:before:bg-slate-800">
                  {foundComplaint.timeline.map((event, idx) => (
                    <div key={event.id || idx} className="relative group">
                      <div
                        className={`absolute -left-6 top-1 w-6 h-6 rounded-full flex items-center justify-center text-xs ring-4 ring-white dark:ring-slate-900 ${
                          event.status === 'Resolved'
                            ? 'bg-emerald-600 text-white'
                            : event.status === 'In Progress'
                            ? 'bg-amber-500 text-white'
                            : 'bg-blue-600 text-white'
                        }`}
                      >
                        {event.status === 'Resolved' ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : (
                          <Clock className="w-3.5 h-3.5" />
                        )}
                      </div>
                      <div className="bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {event.status}
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {new Date(event.timestamp).toLocaleString('en-IN', {
                              dateStyle: 'medium',
                              timeStyle: 'short',
                            })}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-300">{event.note}</p>
                        <div className="text-[11px] text-slate-400 mt-1">By: {event.actor}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Admin Remarks if any */}
              {foundComplaint.adminRemarks && (
                <div className="p-3.5 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 rounded-xl text-xs">
                  <span className="font-bold text-blue-900 dark:text-blue-300 block mb-1">
                    Official Admin Remark:
                  </span>
                  <p className="text-blue-800 dark:text-blue-200 leading-relaxed">
                    {foundComplaint.adminRemarks}
                  </p>
                </div>
              )}

              {/* Student Feedback if resolved */}
              {foundComplaint.feedback && (
                <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 rounded-xl text-xs">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-emerald-900 dark:text-emerald-300">
                      Student Verification Rating:
                    </span>
                    <span className="text-amber-500 font-bold">
                      {'★'.repeat(foundComplaint.feedback.rating)}
                      {'☆'.repeat(5 - foundComplaint.feedback.rating)}
                    </span>
                  </div>
                  <p className="text-emerald-800 dark:text-emerald-200 italic">
                    "{foundComplaint.feedback.comment}"
                  </p>
                </div>
              )}
            </div>
          ) : hasSearched ? (
            <div className="text-center py-12">
              <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3 opacity-80" />
              <h4 className="text-base font-semibold text-slate-900 dark:text-white mb-1">
                No Complaint Found
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Could not find any active or resolved complaint matching "{searchId}". Please check the ID or roll number and try again.
              </p>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-xs">
              <Search className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              Enter a complaint ID above to view live dispatch timeline and handler updates.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            SATI Vidisha Complaint Tracking Node
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
