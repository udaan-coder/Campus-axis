import React, { useState } from 'react';
import {
  ArrowRight,
  ShieldCheck,
  Zap,
  Sparkles,
  Search,
  CheckCircle2,
  Clock,
  Layers,
  EyeOff,
  AlertTriangle,
  Building2,
  BookOpen,
  MapPin,
  ChevronRight,
  TrendingUp,
  Cpu,
  HelpCircle,
} from 'lucide-react';
import { Complaint, ComplaintCategory } from '../types/complaint';
import { SATI_CAMPUS_HERO_IMAGE, CATEGORY_WEIGHTS } from '../constants/complaintData';
import { useLanguage } from '../context/LanguageContext';
import { getTranslatedCategory } from '../constants/translations';

interface LandingPageProps {
  complaints: Complaint[];
  onNavigateToStudent: () => void;
  onNavigateToAdmin: () => void;
  onNavigateToAnalytics: () => void;
  onOpenTrackModalWithId: (id: string) => void;
  onOpenStudentAuth?: (mode?: 'login' | 'register') => void;
  onOpenAdminLogin?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  complaints,
  onNavigateToStudent,
  onNavigateToAdmin,
  onNavigateToAnalytics,
  onOpenTrackModalWithId,
  onOpenStudentAuth,
  onOpenAdminLogin,
}) => {
  const { t, language } = useLanguage();
  const [heroSearchId, setHeroSearchId] = useState('');

  // Interactive Priority Simulator State
  const [simCategory, setSimCategory] = useState<ComplaintCategory>('Internet & Wi-Fi');
  const [simHours, setSimHours] = useState(48);

  const simWeight = CATEGORY_WEIGHTS[simCategory] ?? 2;
  const simAgeBonus = Math.floor(simHours / 24);
  const simScore = simWeight + simAgeBonus;

  // Live Stats calculations
  const totalCount = complaints.length;
  const resolvedCount = complaints.filter((c) => c.status === 'Resolved').length;
  const inProgressCount = complaints.filter((c) => c.status === 'In Progress').length;
  const pendingCount = complaints.filter((c) => c.status === 'Raised').length;
  const resolutionRate = totalCount > 0 ? Math.round((resolvedCount / totalCount) * 100) : 0;

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearchId.trim()) {
      onOpenTrackModalWithId(heroSearchId.trim());
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* 1. HERO SECTION WITH AUTHENTIC SATI VIDISHA PHOTOGRAPH */}
      <section className="relative overflow-hidden min-h-[640px] flex items-center justify-center py-20 px-4 sm:px-6 lg:px-8">
        {/* Background authentic photograph of SATI Vidisha campus */}
        <div className="absolute inset-0 z-0">
          <img
            src={SATI_CAMPUS_HERO_IMAGE}
            alt="Samrat Ashok Technological Institute SATI Vidisha Campus"
            className="w-full h-full object-cover object-center transform scale-105 filter brightness-95"
          />
          {/* Deep Navy / Royal Blue transparent gradient overlay for high-contrast accessibility */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/92 via-blue-950/85 to-indigo-950/90" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-blue-600/20 via-transparent to-black/60" />
        </div>

        {/* Hero Content Container */}
        <div className="relative z-10 max-w-5xl mx-auto text-center">
          {/* Institutional Trust Kicker */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-blue-200 text-xs font-semibold mb-6 shadow-sm">
            <Building2 className="w-3.5 h-3.5 text-blue-400" />
            <span>{t.heroBadge}</span>
          </div>

          {/* Main Hero Heading */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15] mb-6 drop-shadow-md max-w-4xl mx-auto">
            {t.heroHeadingLine1} {t.heroHeadingLine2}{' '}
            <span className="bg-gradient-to-r from-blue-300 via-sky-200 to-indigo-200 bg-clip-text text-transparent">
              {t.heroHeadingLine3}
            </span>
          </h1>

          {/* Tagline & Subtitle */}
          <p className="text-base sm:text-lg text-slate-200 max-w-2xl mx-auto mb-8 font-normal leading-relaxed drop-shadow-xs">
            {t.heroSubtitle}
          </p>

          {/* Primary & Secondary CTAs + Hero Tracker */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 mb-10">
            <button
              onClick={onNavigateToStudent}
              className="w-full sm:w-auto px-7 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm sm:text-base shadow-lg shadow-blue-600/30 transition-all hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
            >
              {t.heroCtaReport}
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onNavigateToAdmin}
              className="w-full sm:w-auto px-7 py-3.5 bg-white/15 hover:bg-white/25 text-white border border-white/30 backdrop-blur-md rounded-xl font-bold text-sm sm:text-base transition-all hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
            >
              {t.heroCtaExplore}
              <ShieldCheck className="w-4 h-4 text-sky-300" />
            </button>
          </div>

          {/* Hero Quick Track Search Box (Glassmorphic) */}
          <div className="max-w-xl mx-auto p-2 sm:p-2.5 bg-white/15 backdrop-blur-xl border border-white/25 rounded-2xl shadow-2xl">
            <form onSubmit={handleHeroSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-300 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={heroSearchId}
                  onChange={(e) => setHeroSearchId(e.target.value)}
                  placeholder={language === 'hi' ? 'शिकायत आईडी से ट्रैक करें (जैसे CC-2026-0001)...' : 'Have an Issue ID? Track (e.g. CC-2026-0001)...'}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900/60 border border-white/20 rounded-xl text-xs sm:text-sm text-white placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-400 font-mono"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-blue-500 hover:bg-blue-400 text-white rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shrink-0 shadow-sm"
              >
                {t.btnTrack}
              </button>
            </form>
          </div>

          {/* Quick Pill Notice */}
          <div className="mt-4 text-xs text-blue-200/90 font-mono">
            {language === 'hi' ? 'एक परिसर। हर समस्या। एक स्मार्ट समाधान।' : 'Tagline: One Campus. Every Issue. One Smart Solution.'}
          </div>
        </div>
      </section>

      {/* 2. LIVE CAMPUS STATISTICS STRIP */}
      <section className="border-y border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="p-3">
            <div className="text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-mono">
              {totalCount}
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
              {t.statsTotalComplaints}
            </div>
          </div>
          <div className="p-3">
            <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
              {resolutionRate}%
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
              {t.statsResolutionRate}
            </div>
          </div>
          <div className="p-3">
            <div className="text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-mono">
              {inProgressCount + pendingCount}
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
              {t.statsPendingComplaints}
            </div>
          </div>
          <div className="p-3">
            <div className="text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono">
              {resolvedCount}
            </div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">
              {t.statsResolvedComplaints}
            </div>
          </div>
        </div>
      </section>

      {/* 3. OFFICIAL SMART PRIORITY ENGINE EXPLAINER & SIMULATOR */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
            Official Hackathon Formula Implementation
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 mb-3">
            Smart Complaint Priority Engine
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Complaints are prioritized mathematically so urgent infrastructure problems and long-standing unattended grievances never get buried.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Formula Breakdown Card */}
          <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Cpu className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  The Priority Formula
                </h3>
              </div>

              <div className="p-4 bg-slate-900 text-white rounded-xl font-mono text-sm sm:text-base font-bold text-center mb-5 shadow-inner">
                Priority Score = Category Weight + floor(Pending Hours / 24)
              </div>

              <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 mb-6">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-white">Official Baseline Weights:</strong> Wi-Fi (2), Hostel (2), Classroom (1), Laboratory (3).
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-white">Hourly Aging Bonus:</strong> Adds +1 priority point for every full 24 hours the complaint remains unresolved.
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-white">Deterministic Tie-Breaking:</strong>
                    <ol className="list-decimal pl-4 pt-1 space-y-0.5">
                      <li>Higher priority score ranks first.</li>
                      <li>Older complaint (earlier submission timestamp) ranks first when scores are equal.</li>
                    </ol>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-900 dark:text-white">Resolved Queue Filtering:</strong> Only unresolved complaints appear in the high-priority queue.
                  </div>
                </div>
              </div>
            </div>

            {/* Official 4 Benchmark Samples */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                Official Benchmark Samples Verification:
              </span>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                <div className="p-1.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  C01 Wi-Fi (48h): <strong>2 + 2 = 4</strong>
                </div>
                <div className="p-1.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  C02 Hostel (8h): <strong>2 + 0 = 2</strong>
                </div>
                <div className="p-1.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  C03 Classroom (72h): <strong>1 + 3 = 4</strong>
                </div>
                <div className="p-1.5 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400">
                  C04 Lab (24h): <strong>Resolved (Queue Excluded)</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Calculator Simulator */}
          <div className="lg:col-span-6 bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 flex flex-col justify-between shadow-xl">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-sky-400" />
                  <h3 className="text-base font-bold text-white">Interactive Score Simulator</h3>
                </div>
                <span className="text-[11px] bg-blue-500/30 text-sky-200 px-2.5 py-1 rounded-full border border-sky-400/30">
                  Live Test
                </span>
              </div>
              <p className="text-xs text-blue-200 mb-6">
                Select a category and adjust the pending hours to watch the priority score recalculate dynamically in real time:
              </p>

              {/* Category picker */}
              <div className="mb-4">
                <label className="block text-xs font-semibold text-blue-200 mb-1">
                  Select Category (Category Weight):
                </label>
                <select
                  value={simCategory}
                  onChange={(e) => setSimCategory(e.target.value as ComplaintCategory)}
                  className="w-full px-3 py-2 bg-slate-900/80 border border-blue-400/40 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-400"
                >
                  <option value="Internet & Wi-Fi">Internet & Wi-Fi (Weight: 2)</option>
                  <option value="Hostel Issues">Hostel Issues (Weight: 2)</option>
                  <option value="Classroom Issues">Classroom Issues (Weight: 1)</option>
                  <option value="Laboratory Issues">Laboratory Issues (Weight: 3)</option>
                  <option value="Water & Electricity">Water & Electricity (Weight: 3)</option>
                  <option value="Security & Safety">Security & Safety (Weight: 4)</option>
                  <option value="Cleanliness & Sanitation">Cleanliness & Sanitation (Weight: 2)</option>
                  <option value="Medical & Health Facilities">Medical & Health Facilities (Weight: 4)</option>
                  <option value="Other / Describe Your Own Problem">Custom Complaint (Weight: 2)</option>
                </select>
              </div>

              {/* Hours Slider */}
              <div className="mb-6">
                <div className="flex justify-between text-xs text-blue-200 mb-1">
                  <span>Pending Hours:</span>
                  <span className="font-mono font-bold text-white text-sm">{simHours} hours ({simAgeBonus} full days)</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={168}
                  step={1}
                  value={simHours}
                  onChange={(e) => setSimHours(Number(e.target.value))}
                  className="w-full accent-sky-400 h-2 bg-blue-950 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-blue-300/80 mt-1">
                  <span>0 hrs (New)</span>
                  <span>48 hrs (+2)</span>
                  <span>96 hrs (+4)</span>
                  <span>168 hrs (1 week)</span>
                </div>
              </div>

              {/* Dynamic Result Display */}
              <div className="p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 text-center">
                <div className="text-xs text-sky-200 uppercase tracking-wider mb-1">
                  Computed Priority Score
                </div>
                <div className="text-4xl font-extrabold text-white font-mono my-1">
                  {simScore}
                </div>
                <div className="text-xs text-blue-200 font-mono">
                  {simWeight} (weight) + floor({simHours}/24 = {simAgeBonus}) = <strong className="text-white">{simScore}</strong>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/15 flex items-center justify-between text-xs text-blue-200">
              <span>Try official C01 (Wi-Fi, 48h) = 4</span>
              <button
                type="button"
                onClick={() => {
                  setSimCategory('Internet & Wi-Fi');
                  setSimHours(48);
                }}
                className="text-sky-300 font-bold hover:underline cursor-pointer"
              >
                Load C01 Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. HOW IT WORKS SECTION */}
      <section className="py-16 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              Simple & Transparent Workflow
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 mb-2">
              How CampusAxis Resolves Every Issue
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              From filing to on-site inspection and verified resolution in four systematic steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 relative">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 font-bold font-mono flex items-center justify-center text-base mb-4">
                01
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Submit with Evidence
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Choose from 15 campus categories or write a custom problem. Attach photos, select precise SATI building/block, and toggle anonymous reporting if sensitive.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 relative">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-bold font-mono flex items-center justify-center text-base mb-4">
                02
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Smart Priority Routing
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                The mathematical priority engine calculates urgency based on severity and hourly aging, automatically routing to the responsible college department.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 relative">
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-600 dark:text-amber-400 font-bold font-mono flex items-center justify-center text-base mb-4">
                03
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Live Timeline Tracking
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Students and admins track real-time progression (Raised → In Progress → Resolved) with officer remarks, escalation flags, and dispatch notes.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 relative">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-600 dark:text-emerald-400 font-bold font-mono flex items-center justify-center text-base mb-4">
                04
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                Student Verification
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Once resolved, students rate the fix (1-5 stars). If the problem persists, students can 1-click reopen the ticket for immediate re-inspection.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. 15 CATEGORIES & CUSTOM COMPLAINTS HIGHLIGHT */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
            All-Encompassing Coverage
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 mb-2">
            Every Campus Problem Has a Home
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Never limited to just Wi-Fi or hostels. CampusAxis supports 15 core campus domains plus a full custom complaint system.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-8">
          {[
            { name: 'Internet & Wi-Fi', icon: '📶', desc: 'Connectivity & Speed' },
            { name: 'Classroom Issues', icon: '🏫', desc: 'Benches, Fans & Boards' },
            { name: 'Hostel Issues', icon: '🛏️', desc: 'Rooms, Mess & Geysers' },
            { name: 'Laboratory Issues', icon: '🔬', desc: 'Equipment & Software' },
            { name: 'Library Issues', icon: '📚', desc: 'Books & Reading Hall' },
            { name: 'Canteen & Food', icon: '🍱', desc: 'Hygiene & Meal Quality' },
            { name: 'Cleanliness & Sanitation', icon: '🧹', desc: 'Washrooms & Waste' },
            { name: 'Water & Electricity', icon: '⚡', desc: 'Outages, RO & Plumbs' },
            { name: 'Campus Infrastructure', icon: '🏗️', desc: 'Roads, Tiles & Stairs' },
            { name: 'Administration', icon: '📋', desc: 'Certificates & Office' },
            { name: 'Security & Safety', icon: '🛡️', desc: 'Lighting, Guards, CCTV' },
            { name: 'Sports & Recreation', icon: '⚽', desc: 'Grounds & Equipment' },
            { name: 'Transport & Parking', icon: '🚌', desc: 'Buses & Vehicle Stands' },
            { name: 'Medical & Health', icon: '🏥', desc: 'Dispensary & First-aid' },
            { name: 'Custom Problem', icon: '✨', desc: 'Describe Any Issue' },
          ].map((cat, i) => (
            <div
              key={i}
              className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl hover:border-blue-400 dark:hover:border-blue-600 transition-colors"
            >
              <div className="text-2xl mb-1.5">{cat.icon}</div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                {getTranslatedCategory(cat.name, language)}
              </h4>
              <p className="text-[11px] text-slate-500 truncate">{cat.desc}</p>
            </div>
          ))}
        </div>

        {/* Custom Complaint Feature Spotlight Card */}
        <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-900 dark:to-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-2xl">
            <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              Exclusive Hackathon Feature
            </span>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1 mb-2">
              "Other / Describe Your Own Problem" Custom Complaint Engine
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Students are never restricted to predefined options. Choose "Other", provide a dedicated problem title, elaborate in a full-length description box, and submit with photos. College administrators can review and assign appropriate custom departments later.
            </p>
          </div>
          <button
            onClick={onNavigateToStudent}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shrink-0 transition-colors cursor-pointer shadow-sm flex items-center gap-2"
          >
            Try Custom Complaint Form
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 6. SATI VIDISHA VISUAL IDENTITY & ABOUT US */}
      <section className="py-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 relative rounded-2xl overflow-hidden shadow-xl border border-slate-200 dark:border-slate-800">
            <img
              src={SATI_CAMPUS_HERO_IMAGE}
              alt="Samrat Ashok Technological Institute Campus Entrance Vidisha"
              className="w-full h-72 sm:h-80 object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-4">
              <div className="text-white text-xs font-semibold">
                Main Building & Lawns · SATI Vidisha (M.P.)
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              Campus Heritage & Governance
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 mb-3">
              Samrat Ashok Technological Institute
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
              Established in 1960 by the Maharaja Jiwaji Rao Education Society, SATI Vidisha is a premier autonomous engineering college in Madhya Pradesh. Spanning an expansive green campus with academic blocks, specialized research laboratories, and student residences, maintaining campus infrastructure at peak performance is essential.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
              <strong>CampusAxis</strong> bridges student voices directly with college administration, empowering rapid reporting, mathematical prioritization, and accountability across every department.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Location</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">Vidisha, M.P. 464001</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Affiliation</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">RGPV Bhopal / Autonomous</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Portal Role</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">Campus Improvement Hub</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. FOOTER */}
      <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
                <Building2 className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                CampusAxis <span className="text-xs text-blue-400 font-normal">| SATI Vidisha</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Smart Campus Complaint & Resolution Management Platform. Dedicated to creating an accountable, responsive, and world-class educational environment for SATI students and faculty.
            </p>
            <div className="text-xs text-slate-400 font-mono">
              Tagline: One Campus. Every Issue. One Smart Solution.
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onNavigateToStudent}
                  className="hover:text-blue-400 transition-colors cursor-pointer"
                >
                  Student Dashboard & Submit
                </button>
              </li>
              <li>
                <button
                  onClick={onNavigateToAdmin}
                  className="hover:text-blue-400 transition-colors cursor-pointer"
                >
                  Admin Dispatch Hub
                </button>
              </li>
              <li>
                <button
                  onClick={onNavigateToAnalytics}
                  className="hover:text-blue-400 transition-colors cursor-pointer"
                >
                  Campus Analytics & Trends
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenTrackModalWithId('')}
                  className="hover:text-blue-400 transition-colors cursor-pointer"
                >
                  Track Complaint by ID
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              College Contact
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Samrat Ashok Technological Institute (SATI)<br />
              Civil Lines, Vidisha, Madhya Pradesh - 464001<br />
              Student Support Cell: complaint-cell@satiengg.in<br />
              Emergency Campus Security: Ext. 101 / 108
            </p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <div>
            © {new Date().getFullYear()} CampusAxis. Built for Samrat Ashok Technological Institute, Vidisha.
          </div>
          <div className="flex items-center gap-4">
            <span>Official Hackathon Solution</span>
            <span>·</span>
            <span>Local Storage Persistent</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
